# B2C Commerce Event Types Reference

_Find the event you want to subscribe to. Each row links to the page that documents the headers, payload, and example for that event._

The B2C Commerce eventing framework currently supports replication events and a shopper registered event. Use this table to find the event you want, then go to the linked page for its full payload reference.

### Shared references

The following pages apply to multiple event types.

- [Common HTTP Headers](https://help.salesforce.com/s/articleView?id=cc.b2c_event_common_headers.htm&type=5) — the standard `x-sf-cc-*` headers included with every event.
- [Replication Group IDs](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_groups.htm&type=5) — the organization, site, and repository group identifiers used in replication event payloads.
- [Replication Error States](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_error_states.htm&type=5) — the `errorState` values reported by failed process-level replication events.

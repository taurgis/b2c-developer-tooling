# FAQ and Identity Federation Troubleshooting

_Find answers to frequently asked Identify Federation questions for B2C Commerce._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

### Where can I find login flow details for different SSO and Identity Federation scenarios?

For a detailed overview of the login flow with Salesforce Identity, see [b2c_account_manager_sso_workflow.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_workflow.htm&type=5).

### Why don't I see Account Manager as a Connected App in my Core Organization?

When you don't see Account Manager as a Connected App in your Core Organization, link your account once. This initial attempt won't succeed, but it triggers the necessary process. After this, Account Manager appears as a Connected App in your Salesforce Core organization, and you can proceed with the installation.

### What happens when a user is assigned to multiple organizations?

If you are assigned to multiple organizations, the settings of your primary organization determine whether Salesforce Identity or Account Manager is used for authentication.

### Do I have to create users still in Account Manager when I have turned on Salesforce Identity?

If Just-in-Time User provisioning is configured in Account Manager, creating users in Account Manager is not required. Otherwise, you must create users in Account Manager. See: [Just-in-time User Provisioning](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_just_in_time_user_provisioning.htm).

### What happens when my user account in Salesforce has a different email address than my user account in Account Manager?

Linking an Account Manager account to a Salesforce account updates the Account Manager username to match the Salesforce account's email address.

### Can you unlink a user from Salesforce Identity?

Unlink a user from Salesforce Identity on the user list page in the Account Manager UI. Clicking the reset link in the user table unlinks the account and sends an activation email to the user.

### What happens when you turn off Salesforce Identity again?

Reset users in Account Manager. The Account Manager Admins reset users' accounts. When a user account is reset, the user receives an activation email with instructions to reactivate their accounts. Upon activation, users log in directly to the Account Manager.

### If an AM Org setting has Identity Federation Enforced and your customer identity provider (IDP) (for example, Ping) is down, how can you switch from enforced to disabled to log in to B2C Commerce?

If your AM Org setting has Identity Federation Enforced and your customer IDP (for example, Ping) is down, you have two options to switch from enforced to disabled.

1. An invited User with the Access Administration role to this Org can change the settings, provided their Primary Org is not using the impacted IDP.
2. Alternatively, you can contact Salesforce support to change the Identity Federation setting.
   
   After switching, reset all users so that they can either link their account to the new setting or log in with Account Manager credentials.

### What happens when the user email is changed in Salesforce Identity?

The change is also reflected in Account Manager during the next login. This ensures that both systems remain synchronized with the correct email address.

### Can you change the "Salesforce My Domain Subdomain Name"?

Yes. You can change the "Salesforce My Domain Subdomain Name," but a reset of the Salesforce Identity integration is required. To do this:

1. Disable Identity Federation for the organization.
2. Save the page.
3. Re-enable Salesforce Identity Federation.
4. Set the new "Salesforce My Domain Subdomain Name.”
5. Reset the users to link their accounts to the new subdomain or log in with Account Manager credentials.

### Why can't I access WebDav, cartridge upload, pipeline debugger, script debugger or protected storefront after I linked my account with Salesforce Identity?

WebDav, cartridge upload, pipeline debugger, script debugger, or a protected storefront do not support SSO/Federation.These external clients can use Access keys as a substitute for login. Access keys expire after a year. If entered incorrectly six times, you can’t use that access key in that authentication scope. Business Manager generates the API key, and it is valid only for that specific Business Manager instance. After you link your account with Salesforce Identity, generate Access Keys in Business Manager. Click App Launcher _(image: App Launcher)_, and then select **User Profile > Manage Access Keys > Generate Access Keys**. See: [Generate Access Keys in Business Manager](https://documentation.b2c.commercecloud.salesforce.com/DOC1/index.jsp?topic=/com.demandware.dochelp/content/b2c_commerce/topics/admin/b2c_access_keys_for_business_manager.html).

You use these Access Keys as the password to access WebDav, cartridge upload, pipeline debugger, script debugger, or a protected storefront. See [Use Access Keys for WebDAV File, UX Studio Agent, User Login, Open Commerce API (OCAPI), and Protected Storefront Access](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_use_webdav_file_access.htm&type=5)

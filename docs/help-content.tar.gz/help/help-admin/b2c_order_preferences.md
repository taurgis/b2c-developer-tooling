# Order Preferences for B2C Commerce

_Select how orders are processed with Salesforce B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

Some order preferences can be imported and exported.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Order**.
2. Configure order export settings.

   These settings don’t apply to a Salesforce Order Management or legacy Order Management integration.
   
   1. Enter the delay in minutes, after which an order can be considered for export.
   
      The default is 30 minutes.
   2. To delay the exporting of an order once the order has been opened for editing, enter the amount of time in minutes.
   
      The default is 30 minutes.
   3. Enter the version of the XML schema (`order.xsd`) to use for order export.
   
      Select the most recent version of B2C Commerce or remain on a specific version, if necessary.
3. Enable `Order IP Logging` to store the customer IP addresses during order creation.

   First determine if you’re legally required to inform the customer about storing this type of information.
4. Configure order data settings.

   1. Enter the number of days B2C Commerce stores orders (`Order Retention`).
   
      Orders older than the specified number of days are automatically removed from B2C Commerce. To retain orders, leave this setting blank.
   2. Enter the number of days B2C Commerce stores failed orders (`Failed Order Retention`).
   
      Failed orders older than the specified number of days are automatically removed from B2C Commerce. To retain failed orders (unless the `Order Retention` preference is set), leave this setting blank.
   3. Select whether to preserve orders that haven’t yet been exported (Retain Non-Exported Orders)
   
      If set to Yes, an order in status NEW, OPEN, or COMPLETED is purged. However, the order is purged only if the order export status is EXPORTED when the purge job is executed. Orders in status CREATED, FAILED, CANCELLED, or REPLACED are purged regardless of the export status. This setting in only relevant if 'Order Retention' is enabled.
5. Enter the number of days from 1 through 365, after which B2C Commerce masks order payment information (`Payment Information Retention`).

   Order payment instruments older than the specified number of days are automatically masked. Masking these instruments makes the original credit card and bank account numbers unrecoverable. This masking is permanent and can't be undone if you change the number of days at a later time.
6. Enter the number of minutes after an order hasn’t been placed when the order is eligible for automatic failing (via a job).

   Leave this blank if orders are never to be auto-failed.
7. Specify if access to orders from the storefront is limited.
8. Specify whether to validate storefront order searches against the session customer. Set to Yes unless you have a specific reason to disable this validation.

   Yes or No
9. Specify if customer numbers generate for orders placed by unregistered customers.

   If set to Yes, a customer number generates for orders placed by unregistered buyers, no matter how the order is created: via script API, Open Commerce API (OCAPI), or pipelets (CreateOrder or CreateOrder2). If set to No, and if the Script API or OCAPI creates the order, a customer number isn’t generated. When pipelets create the order (CreateOrder or CreateOrder2), the corresponding pipelet configuration parameter specifies whether a customer number generates for guest orders.
10. Configure order calculation rounding.

   Select **Item Price Rounding** or **Item-Level Rounding**. This setting applies for net and gross sites, and the B2C Commerce Script API and OCAPI.
   
   Also enable the promotion site preference.
11. Specify whether to manage this site’s orders in Order Management. Configure and enable the Order Management integration.

   This setting applies to both Salesforce Order Management and the legacy Order Management product.
12. Specify how inventory and coupon redemptions are handled. If inventory can’t be reserved or coupons can’t be redeemed, the respective order history entries are written.

   1. Specify whether to turn failed orders into valid orders, even if there is no inventory available for a reservation, known as overselling.
   2. Specify whether to turn canceled orders into valid orders, even if there’s no inventory available for a reservation, known as overselling.
   3. Specify whether to turn failed orders into valid orders, even if not all coupons can be redeemed. Unsuccessful coupon redemptions result in having coupons used more often than configured.
   4. Specify whether to turn canceled orders into valid orders, even if not all coupons can be redeemed. Unsuccessful coupon redemptions result in having coupons used more often than configured.
13. Click **Apply**.

## Related Content

- [Order Preference Import and Export](https://help.salesforce.com/s/articleView?id=cc.b2c_order_preferences_import_export.htm&type=5)
  Import and export some order preferences. This topic applies to B2C Commerce.

- [Limit Storefront Order Access](https://help.salesforce.com/s/articleView?id=cc.b2c_limit_order_access_settings.htm&type=5)
  Unauthorized access to storefront orders happens when someone accesses an order through a storefront session using a different customer ID than the one used to create it. This makes it possible for unauthorized users to view the order’s details.

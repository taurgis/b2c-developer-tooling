# Customer Object Import and Export for Payments with B2C Commerce

_For Payments with B2C Commerce, use the Customer Object (customer.xsd) to import and export site-specific data about payment customers. See Customer Object Import and Export for Customer object details._

### Export

The Customer object export includes a PaymentsCustomer complex type that maps theses elements:

- Account ID–The Stripe merchant account ID
- Live–Is the account live or a sandbox
- Customer ID–The Stripe ID
- Creation Date–The record creation date

This mapping is customer data that tells the system where to find payment data. The mapping isn’t customer payment data. If present in the database, PaymentsCustomer information is exported regardless of the Salesforce Payments feature toggle status.

### Import

The customer import handles the PaymentsCustomer mappings based on the standard import modes.

- MERGE
   
   - Adds missing PaymentsCustomer records, and updates existing information
   - Result
      
      - All imported PaymentsCustomer records are available
      - Previously created PaymentsCustomer records are available
      - Missing information isn’t changed
- UPDATE
   
   - Updates existing PaymentsCustomer records. Missing records aren't added
   - Result
      
      - All existing PaymentsCustomers records are available
      - Previously created PaymentsCustomer records are available
      - Missing information isn’t changed
- REPLACE
   
   - Removes all PaymentsCustomer records for the customer
   - Recreates all PaymentsCustomer records from the import file
- DELETE
   
   - Removes all PaymentsCustomer records for the customer
   - Deletes the customer

The import logs a warning if the merchant account isn’t available.

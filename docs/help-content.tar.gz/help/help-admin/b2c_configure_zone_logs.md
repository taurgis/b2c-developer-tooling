# Configure Logpush and Logpull for an eCDN Zone

_Stream eCDN request, security, and Page Shield logs to your own storage or observability platform (Amazon S3, Google Cloud Storage, Azure Blob Storage, Datadog, or Splunk), or download recent logs on demand - all from the Logs tab on the Configure Zone screen in Business Manager._

Looking for the Crypto, Security Rules, Speed, Customization, or Under Attack Mode controls on the same screen? See the Configure an eCDN Zone in Business Manager guide.

1. In Business Manager, click the App Launcher, then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure, and select **Configure Zone** from the actions menu.
3. Click the **Logs** tab.

   _(image: Logs tab showing Logpush and Logpull sections)_
   
   The Logs tab is split into two sections:
   
   - **Logpush** - Continuously stream eCDN logs to a customer-owned destination.
   - **Logpull** - Download recent eCDN request logs on demand. Logpull retains logs for 7 days.

Logpush jobs continuously deliver eCDN logs to a customer-owned destination on a schedule. Each zone supports up to 2 active Logpush jobs, one per dataset.

**Supported Destinations and Datasets**

**Destinations:**

- **Amazon S3** - Push logs as gzip-compressed batches to an S3 bucket.
- **Google Cloud Storage** - Push logs to a GCS bucket.
- **Azure Blob Storage** - Push logs to an Azure storage container.
- **Datadog** - Stream logs directly to a Datadog site.
- **Splunk** - Stream logs to a Splunk HEC (HTTP Event Collector) endpoint.

**Datasets:**

- **HTTP Requests** - Edge HTTP request log records.
- **Firewall Events** - Security events evaluated by WAF, rate limiting, and managed rules.
- **Page Shield Events** - Page Shield script and connection events.

**Create a Logpush Job**

The New Logpush Job wizard walks through destination setup and job configuration in two steps.

_(image: New Logpush Job wizard Destination Details screen showing destination dropdown with options for Datadog, Splunk, Amazon S3, Google Cloud Storage, and Azure Blob Storage)_

1. In the **Logpush** section, click **New Logpush Job**. The New Logpush Job wizard opens.
2. **Step 1 - Destination Details:**
   
   1. Choose a **Destination**.
   2. Choose a **Dataset**.
   3. Fill in the destination-specific fields (see the per-destination tables below).
   4. Click **Next**.
3. **Step 2 - Configure Logpush Job:**
   
   1. Enter a **Job Name**.
   2. Choose a **Timestamp Format** (rfc3339, unix, or unixnano).
   3. Choose **All Logs** to push every record, or **Filtered Logs** to build a filter expression.
   4. Under **Allowed Directives**, choose which fields to include - All, or a specific subset.
   5. Click **Save**.

When the job saves successfully, a toast confirms the change and the job appears in the Logpush table on the Logs tab.

**Amazon S3 Destination**

Use Amazon S3 to push gzip-compressed log batches to an S3 bucket you own.

_(image: New Logpush Job Amazon S3 Destination Details showing Bucket, Region dropdown, Path, SSE-S3 encryption checkbox, and AWS Resource Policy JSON section)_

**Required fields:**

- **Bucket** - Name of your S3 bucket.
- **Region** - AWS region of the bucket (for example, US East (N. Virginia), Europe (Frankfurt), Asia Pacific (Tokyo)).

**Optional fields:**

- **Path** - Optional prefix inside the bucket where log files land.
- **My policy requires AWS SSE-S3 AES256 Server Side Encryption** - Select when your bucket policy requires SSE-S3 encryption on writes.

**AWS Resource Policy:** After you fill in Bucket and Region, the screen displays an AWS Resource Policy JSON snippet. Copy it and attach it to your bucket so eCDN's Cloudflare Logpush principal can write to it.

**Prove Bucket Ownership:** Before the job is activated, eCDN drops a one-time challenge file into your bucket. You must read its contents and paste them back to confirm you own the bucket.

_(image: Prove Bucket Ownership dialog showing challenge filename ownership-challenge-c6c1dd02.txt, Ownership Challenge Token input field, and Resend Challenge link)_

1. Open the bucket in your AWS console. A new file named ownership-challenge-<id>.txt appears at the bucket root (or under the configured path).
2. Open the challenge file and copy its contents.
3. Paste the token into **Ownership Challenge Token** in the Prove Bucket Ownership dialog and click **Confirm**.
4. If the token cannot be found yet, click **Resend Challenge** to request a new file.

**Google Cloud Storage Destination**

Use Google Cloud Storage to push gzip-compressed log batches to a GCS bucket.

**Required fields:**

- **Bucket** - Name of your GCS bucket.

**Optional fields:**

- **Path** - Optional prefix inside the bucket.

After saving the destination details, follow the in-product instructions to grant the Cloudflare Logpush service account write permission on the bucket and complete the ownership challenge.

**Azure Blob Storage Destination**

Use Azure Blob Storage to push gzip-compressed log batches to a storage container.

**Required fields:**

- **SAS URL** - Container-level Shared Access Signature URL with write permission.

**Optional fields:**

- **Path** - Optional prefix inside the container.

The SAS URL must include `sp=w` (or equivalent write rights) and must not expire before you intend to retire the job.

**Datadog Destination**

Use Datadog to stream logs directly to a Datadog ingestion endpoint.

**Required fields:**

- **Datadog Site** - The Datadog site that owns your account (for example, `datadoghq.com`, `datadoghq.eu`, `us3.datadoghq.com`).
- **API Key** - A Datadog API key with `logs_write` permission.

**Splunk Destination**

Use Splunk to stream logs to a Splunk HEC (HTTP Event Collector) endpoint.

**Required fields:**

- **HEC URL** - The HEC ingestion URL (`https://<your-splunk>:8088/services/collector/raw`).
- **HEC Token** - The HEC token with permission to write to the destination index.
- **Channel ID** - A unique GUID identifying this channel. Click **Generate UUID** to create a new one.
- **Source Type** - The Splunk source type to assign to records (for example, `cloudflare:json`).

**Optional fields:**

- **Insecure Skip Verify** - Select to skip TLS certificate validation. Use only for non-production endpoints.

**Configure the Job (Step 2)**

After Destination Details is complete, the wizard moves to Configure Logpush Job.

_(image: Configure Logpush Job screen showing Job Name field, Timestamp Format dropdown set to rfc3339, Matching Logs radio buttons for All Logs and Filtered Logs with Filter Logs section displaying Field, Operator, and Value dropdowns)_

**Settings:**

- **Job Name** - Free-form label that appears in the Logpush table and in the destination's path and metadata.
- **Timestamp Format** - `rfc3339` (default ISO-8601 string), `unix` (epoch seconds), or `unixnano` (epoch nanoseconds).
- **Matching Logs** - All Logs pushes every record. Filtered Logs builds a filter expression first.
- **Allowed Directives** - Whitelist of fields to include in each record. Choose All, or pick a subset.

**Filter Logs (Filtered Logs only):** When you select **Filtered Logs**, a Filter Logs builder appears. Build the expression row by row by choosing a Field, an Operator (equals, does not equal, contains, does not contain, matches, does not match, starts with, does not start with, ends with, does not end with, is in, is not in), and a Value. Click **And** or **Or** to add another row. Click **Edit Expression** to switch to a raw-JSON view of the expression, then click **Use Expression Builder** to return to row-based editing.

**Manage Existing Logpush Jobs**

The Logpush table on the Logs tab lists every job configured for the zone, with a header counter such as Logpush (2) and You have used 2 out of 2 Logpush jobs.

**Columns:**

- **Dataset** - The dataset being pushed (HTTP Requests, Firewall Events, or Page Shield Events).
- **Destination** - A short summary of the destination - provider logo, bucket or site, and any encryption flag.
- **Status** - Pushing when delivery is healthy, Pending when the destination has not yet been validated, or an error state.
- **Enabled** - Toggle the job on or off without deleting it.
- **Actions** - Per-row actions menu (Edit and Delete).

To pause delivery without losing the configuration, switch the Enabled toggle off. The job remains in the table and counts toward the 2-job limit.

**Edit and Delete actions:**

- **Edit** - Open the wizard to change destination, dataset, filter, or directives. A confirmation appears before destination-changing edits.
- **Delete** - Permanently remove the job. A confirmation appears before delete.

To get alerted when a Logpush job fails, set up a notification rule in [Configure Notifications for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_notifications.htm&type=5).

**Logpull**

Use the Logpull section to download recent eCDN request logs on demand. Logs are available for the past 7 days only.

1. In the **Logpull** section, select one or more dates. Use **Select All Dates** to pick the full week.
2. For each selected date, choose an hour from the **Time** dropdown.
3. Click **Request Logs**.

The download link is delivered when the request is processed.

**I Don't See These Tabs or Settings**

If you don't see the Logs tab or the Logpush section described in this guide, ask your admin or your Salesforce representative to enable the new Configure Zone screen for your instance.

# Using Hooks Securely in B2C Commerce

_In Salesforce B2C Commerce, you can use hooks as a powerful tool to extend default functionality. Like all powerful tools, however, hooks are dangerous if not used properly._

Hooks in Open Commerce API (OCAPI) and Commerce Script can functionally change the platform operation of OCAPI and platform method calls. Be cautious when using hooks because unprivileged users can make privileged OCAPI or method calls. Also, because of the design placement of OCAPI hooks, a developer can inadvertently modify API calls to accept no authentication or to bypass expected authorization entirely. Use caution when chaining any calls on the platform.

# Replicate Content Assets with Granular Replication

_Replicate specific content assets from staging to production._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Note:** This functionality dosen't apply to Page Designer content assets.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Content > Content Assets**.
2. Enter the content asset Name or ID.
3. Select the asset.
4. In the Content Asset section, update the attributes.
5. To publish the content asset to production via granular replication, click **Publish**.

_(image: Granular Replication)_ _(image: Granular Replication Asset Listings Page)_ _(image: Granular Replication Asset Details Page)_

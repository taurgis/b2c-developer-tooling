# Embedded CDN Overview

_Salesforce B2C Commerce provides digital customers an embedded content delivery network (eCDN) designed to accelerate site speed access and content delivery. The eCDN provides low response times for consumers using proxy servers. The use of proxy servers provides digital content._

B2C Commerce customers are part of a growing worldwide content delivery network built for scale. When you streamline connections between shoppers and retailers, every B2C Commerce site renders fast and efficiently from whatever device a shopper is using.

When configuring the eCDN, keep the following in mind: Configure subdomains of the same zone on the same B2C Commerce instance, or on different instances of different realms of the same retailer. For example, configure *www.shop.com* on the Production instance, *test.shop.com* on the Development instance, and *eu.shop.com* on the Production instance of the EU realm. The embedded CDN, which includes the eCDN console in Business Manager, is available on all Primary Instance Group (PIG) instance types: Development, Staging, and Production. The embedded CDN is also available on Secondary Instance Group (SIG) instances, including On-Demand Sandboxes (ODS). The eCDN for your custom hostnames (subdomains) requires configuration before you can route traffic to B2C Commerce. Make sure to enable Enforce HTTPS for all storefronts. The eCDN uses various cookies to maximize network resources, manage traffic, and protect sites from malicious traffic. For more information about these cookies, see [Understanding the Cloudflare Cookies](https://support.cloudflare.com/hc/en-us/articles/200170156-Understanding-the-Cloudflare-Cookies).

The eCDN also supports Web Application Firewall (WAF) and HTTP Strict Transport Security (HSTS).

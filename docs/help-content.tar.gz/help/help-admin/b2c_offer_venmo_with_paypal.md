# Using Venmo with PayPal for B2C Commerce

_Salesforce Payments supports Venmo as an express and multi-step checkout method. With Venmo, you can offer your shoppers a digital wallet payment option that they link to a credit card, debit card, bank transfer, or Venmo funds bank. Using Venmo on your Salesforce Reference Architecture (SFRA) storefront requires a PayPal integration with Salesforce Payments. This feature applies to B2C Commerce._

### Venmo Activation

Venmo is available only to US-based merchants and shoppers using US currency. Use Venmo with any payments zone that accepts US-based shoppers and US currency. If the payments zone accepts non-US-based shoppers and non-US currency, Venmo isn't offered as a payment service option to those shoppers.

If PayPal is already active for a payments zone, Venmo is selected by default for your selected PayPal checkout method (express or multi-step). If you don’t want to offer Venmo as a payment option, deselect it in the payments zone’s checkout configuration.

### Buyer Experience

The Venmo buyer experience is different for mobile and desktop shoppers.

Desktop–When a shopper selects Venmo as the payment option, they’re presented with a QR code. The buyer scans the QR code and uses their Venmo app to authorize and complete the payment. The shopper completes the transaction in the Venmo app and returns to the order confirmation page on your storefront.

Mobile–When a shopper selects Venmo as the payment option, the Venmo app opens on their mobile device. The shopper completes the payment in the Venmo app and returns to the order confirmation page on your storefront. Shoppers on mobile devices must use Safari on iOS or Chrome on Android and have the Venmo app installed.

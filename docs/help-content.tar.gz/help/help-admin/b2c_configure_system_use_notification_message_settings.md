# Add a System Use Notification Message in B2C Commerce

_Create a system use notification message that displays when your users log in. You can also require them to acknowledge this message before continuing to log in._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security** and select the Misc tab.
2. To erase the record of known good hosts, click **Clear** for the Clear Secure File Transfer Protocol (SFTP) Known Good Hosts File setting.
3. To show a System Use Notification Message on the Business Manager's login page, select **Enable System Use Notification Message**.
4. Select the language that you want to use for the message.

   You can specify one message per supported locale. The System Use Notification Message lets the user select a locale and see its associated message.
5. Enter the notification message in the System Use Notification Message field.

   The message communicates your organization's terms of use.
6. To require users to acknowledge the message before logging in, select** Enforce Acknowledgment** setting.
7. Click **Apply**.

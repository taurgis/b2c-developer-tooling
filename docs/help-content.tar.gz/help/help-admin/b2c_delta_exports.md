# Delta Exports in B2C Commerce

_Export data for certain business entities as deltas rather than as full datasets. This topic applies to B2C Commerce._

Delta exports are available for catalog data exported to Order Management. Each delta export includes all changes since B2C Commerce generated the previous export data file, including object deletions. Changes that occur during an export are included in the following export. To export the data to multiple consumers, specify multiple WebDAV paths.

To enable this feature, contact Salesforce Support to activate its feature switch.

> **Note:** The Delta Exports feature requires the Change Log feature to be active, which can cause a slight (<5%) database performance penalty. This penalty affects update and delete transactions on any entity types that you can select for delta exports (not only the types selected).

> **Note:** To include changes occurring in production via replication, activate the Change Log Replication feature as well. Activate all three feature switches in staging and production.

> **Note:** Use delta exports with catalog data sent to Order Management. Salesforce Support configures the connector to receive the delta catalog data.

### Available Business Entity Types

Delta exports are available only for the following business entity types:

- For the following global stageable types, export deltas for a specific container:
   
   - Catalogs (configure Order Management to accept catalog delta exports)
   - Shared Libraries
   - Price Books
   - Global Metadata
- For the following site-specific stageable types, export deltas for a specific site:
   
   - Stores
   - Campaigns and Promotions
   - Coupons
- Also export deltas for the following transactional types:
   
   - Customer Lists
   - Custom Objects

### Limitations

Note the following limitations of delta exports:

- The initial run of a delta export job only includes changes that occurred since you activated the change log. It isn’t a full data export.
- Delta export data is always in the standard B2C Commerce export format. B2C Commerce names exported data files xxxxxx.zip, where xxxxxx is a 6-digit number that starts at 000001 and increments for each successful run of the export job. A corresponding metadata file called xxxxxx.meta is also produced. The metadata file isn’t needed.
- You can only configure delta exports for entity types and containers (for example, products that belong to a particular catalog). You can’t configure them for a subset of a type (for example, products with certain characteristics).
- Changes occurring in production via replication aren’t tracked unless the Change Log Replication feature switch is also activated. Activate all three feature switches in both staging and production for this to work.
- When you configure delta exports for a specific container, deleting that container isn’t considered in the delta. For example, if you’re exporting deltas for the contents of a certain price book, and you delete that price book, then the next delta export file doesn’t include any data about that price book or its contents. Delta export data does include other entity deletions.
- Delta export data depends on the change log. Because the default retention time for the change log is 7 days, configure delta exports to occur at least one time every 7 days. If more than 7 days elapse between delta exports, then you miss any changes older than 7 days.
- The system doesn’t track consumption of the exported data. To know whether the data has been read, implement your own checks on the consumer side.

### Delta Export Job Details

To open the Delta Exports page, click App Launcher _(image: App Launcher)_, and then selecting **Administration > Site Development > Delta Exports** shows a list of all existing delta export jobs, with the following information:

- Profile: The number of entities included in the export data.
- Consumers: A list of all consumers receiving the export data.
- Enabled/Next Run: If the job is enabled, the date and time of the next scheduled run. If it isn’t enabled, "No."
- Last Run: The date and time of the most recent run.

Clicking the name of a job opens the Details form for that job. Edit any fields other than the name of the job. The form includes the following tabs:

- General: The consumers and entities assigned to the job.
- Schedule: The job schedule and status, as well the **Enabled** checkbox.
- History: A list of the 20 most recent runs of the job. Any runs that were skipped (because there were no changes since the previous run) aren’t included. To open the standard Job History page, click **Full History**.
- Consumer: A link to the WebDAV folder that contains data files for the consumer. A separate tab appears for each consumer of the job.
- Status: Recent log messages for the job.

## Configure Delta Exports in Business Manager in B2C Commerce

_Configure delta exports in Business Manager to export changed entities as deltas rather than as full datasets. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Delta Exports**. The page shows a list of all existing configured delta exports.
2. To open a new job Details form, click **New**. The form includes General, Schedule, History, and Status tabs.
3. Enter a name for the job in the **Name** text field and click **Create**. The name is used to form the WebDAV paths for the export files, so you can’t use any special characters.
4. Enter one or more consumer names in the **Consumers** text field, separated with commas. B2C Commerce creates one export data file for each consumer. These names are used to form the WebDAV paths for the export files, so you can’t use any special characters. This field is limited to 22 characters, including commas.
5. By default, when you change or delete a variation product, the delta export data includes only that variation product. To include the base product and and all other variation products of it as well, check the **Export Full Base Products** box. This setting only affects product entities.
6. Select one or more entity types to include in the delta export and click **Apply**. The form gains a tab for each consumer.
7. Select the **Schedule** tab.
8. Set a start date and time using the **From** and **at** controls.
9. Set a recurrence frequency using the **Every** controls. The delta export job must run at least one time every 7 days, or it misses older changes. If the job triggers and contains no data (because the associated entities haven’t changed since the previous run), then that run is skipped.
10. Check the **Enabled** box.
11. Click **Apply** to set the job schedule. Click **Run Now** to immediately queue the job to run one time.

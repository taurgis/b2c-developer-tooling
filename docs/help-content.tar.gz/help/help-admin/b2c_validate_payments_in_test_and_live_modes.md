# Validate Stripe Payments for B2C Commerce

_Set up and validate test payments in a test or live Stripe merchant account for your B2C Commerce instance. Use a Stripe merchant account associated with your B2C Commerce instance to create test payments._

- Test mode: Doesn’t use actual authorizations or captures. Uses test cards and bank accounts.
- Live mode: Uses actual authorizations and captures for credit cards and bank accounts. Uses only valid credit cards and bank accounts.

|  |
| --- |
| Available in: **B2C Commerce** |

Associate a Stripe merchant account with your B2C Commerce instance and onboard the account. See [Associate a Stripe Merchant Account with B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_associate_stripe_merchant_account.htm&type=5) and [Onboard Your Stripe Merchant Account for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_onboard_a_stripe_merchant_account.htm&type=5).

1. From Business Manager, go to the Storefront.
2. Add items to your cart.
3. Checkout using multi-step checkout, Pay Now, or Buy Now (Google Pay for Chrome or Android and Apple Pay for Safari or IOS).

View the order from the storefront or from the Stripe Dashboard to confirm that Salesforce Payments processed the payment using the Stripe processor. A Stripe payment intent ID is listed for the order.

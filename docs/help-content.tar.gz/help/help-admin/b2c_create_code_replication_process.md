# Create a Code Replication Process in B2C Commerce

_Trigger a code replication process manually, schedule it to run at a specified time, or create a job to run it._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Replication > Code Replication**. A list of existing code replication processes appears.
2. Click **New**.
3. The system generates a Process ID. Enter a different ID.
4. From the dropdown list, select a target instance.
5. (Optional) Enter a description.
6. From the dropdown list, select an activation type.

   | Option | Description |
   | --- | --- |
   | Manual | The process runs when you manually trigger it. |
   | Automatic | The process runs once at a time that you specify. Selecting this option displays date and time fields. The default value is the next midnight. |
   | Job Step | The process is available to run as part of a job. |
7. From the dropdown list, select a notification email trigger. Enter multiple target email addresses separated by commas.

   | Option | Description |
   | --- | --- |
   | -None- | No emails are sent. |
   | When Process Ends | Sends an email to the specified addresses when the process ends, whether it succeeds or fails. If it hangs, then no email is sent. |
   | When Process Fails | Sends an email to the specified addresses when the process fails. If the process succeeds or hangs, then no email is sent. |
   | Periodically | Enter a time period in minutes. While the process is running, emails are sent to the specified addresses at that interval until the process finishes. An email is also sent when the process succeeds or fails. |
8. Click **Next**.
9. From the dropdown list, select a replication type.
10. Click **Next** and review the process details. After you create the process, it can’t be changed.
11. Click **Create** or **Schedule** to create the process. If you selected Manual activation, click **Start** to create the process and immediately run it.

   After the code replication process has begun, it can't be deleted.

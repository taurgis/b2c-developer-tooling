# Generate a Shortcode and Create an API Client ID

_To use the Salesforce Commerce API, you need:_

A shortcode. (see, [Configuration Values)](https://developer.salesforce.com/docs/commerce/commerce-api/guide/commerce-api-configuration-values.html) An API client ID and authorization token for the CDN Zones API. (see, [CDN Zones-Content Delivery Network)](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=Summary) When you obtain the API authorization token, make sure that the `<tenant_id>` matches the instance.

- For the eCDN development process, use `<realm>_dev`
- For the eCDN staging process, use `<realm>_stg`.
- For the eCDN production process, use `<realm>_prd`

When you complete the shortcode and API authorization, you use the returned values to call the various endpoints required throughout the process.

- `{shortcode}`
- `{organizationId} - f_ecom_<realm>_stg`

# Remove the Subdomain from the Legacy Zone.

_Make sure the old certificate doesn't show in your website, when you remove the subdomain from the legacy zone._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Click the trash icon for the legacy zone.
3. Click **Remove Subdomain**
4. On the Crypto tab, locate the legacy zone certificate and click the **X** icon.
5. In the confirmation message, click **Delete**.

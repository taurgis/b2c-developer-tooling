# Access Alerts for Your B2C Commerce Site

_Find all tasks and notifications in the Alerts section of your Business Manager homepage. See all tasks and notifications for your site in the Alerts module. Alerts can be shown in the Business Manager homepage or header, or sent directly to Slack channels._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click the bell icon in the upper-right corner and select **Show All**.
2. To search for alerts, select a module and a priority.
3. To quickly access the required module for an alert, click the alert text.
4. To check for an alert's validity, click **Select Action** and select **Check Again**.
5. To dismiss an alert, click **Select Action** and click **Dismiss**.

   A dismissed alert can reappear if the required condition isn’t met.

To configure how and where alerts show, [b2c_configure_alerts_for_your_site.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_alerts_for_your_site.htm&type=5). Individual users can customize their own alerts by [Editing Alert Notifications](https://help.salesforce.com/s/articleView?id=cc.b2c_edit_alert_settings.htm&type=5).

## Related Content

- [Configure B2C Commerce Alerts in Business Manager and Slack](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_alerts_for_your_site.htm&type=5)
  Set up notifications for your organization in Business Manager and Slack. Configure updates, such as security vulnerabilities, campaign and promotion updates, or site alerts, to appear on your Business Manager homepage. You can also send updates directly to your Slack workspaces.

- [Connect a Slack Workspace to Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_connect_slack_to_business_manager.htm&type=5)
  Send alerts and notifications directly to Slack channels, when you connect your workspaces to Business Manager.

- [Edit Alert Settings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_edit_alert_settings.htm&type=5)
  An individual user can change the priority of an alert or prevent it from appearing on their homepage or header. This only impacts the notifications for that user.

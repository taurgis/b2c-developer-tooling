# Sales Metrics

_All users can view live sales metrics, such as the number of orders and baskets created._

### Orders

The Orders metric is the number of orders created across all sites per minute. The report doesn’t update for failed or canceled orders.

Use cases:

- Understand normal order rate patterns to discover when there are irregularities.
- To monitor sale events, track Order Rates in real time during a sale event.
- Correlate the sales metrics with performance metrics to understand any unexpected order rate drops.

### Basket Creations

The Basket Creations metric is the number of baskets created across all sites per minute.

Use cases:

- To monitor sale events, track real-time basket creation. This metric indicates general user behavior and helps track conversions.
- Compare basket creations with storefront requests and session rates. If there's a 1:1 relationship between these measures, it often means that there’s a bug in the code that creates empty baskets per request or session.

### Basket Updates

The Basket Updates metric is the number of basket updates, which include products added or removed, across all sites per minute.

Use cases:

- To monitor sale events, track real-time basket update rates. This metric indicates general user behavior and helps track conversions.
- Correlate requests and basket metrics to get insight into the ratio of users adding products to their cart.

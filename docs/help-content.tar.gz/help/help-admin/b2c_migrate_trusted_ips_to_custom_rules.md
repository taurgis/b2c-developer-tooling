# About the Trusted IP Migration to web application firewall (WAF) Custom Rules

_Learn how Salesforce automatically migrates your legacy Trusted IP configurations to WAF Custom Rules and Managed IP Address Lists, and how to verify your migrated configuration._

### What Is Changing

The legacy Trusted IP configuration — previously managed via the Firewall tab in the zone settings slider — is being replaced by two components in the new Realm Security Rules tab:

- **Managed IP Address Lists:** Named lists of trusted IP addresses or CIDR ranges, scoped at the account (realm) level or zone level.
- **Custom Firewall Rules with skip actions:** Rules that reference your IP address lists and specify which security checks to bypass for traffic from trusted sources.

This change is part of the broader migration of eCDN zone configuration settings to the new LWC-based Configure Zones interface in Business Manager.

### What Salesforce Does Automatically

Salesforce automatically migrates your existing Trusted IP configurations to the new format. You do not need to recreate your trusted IP lists manually. After migration:

- Your existing account-level Trusted IP groups become account-level Managed IP Address Lists with associated Custom Firewall Rules in the Realm Security Rules tab.
- Your existing zone-level Trusted IP groups become zone-level Managed IP Address Lists with associated Custom Firewall Rules.
- List names are derived from the notes field of your legacy access rules. The system converts the label to a lowercase slug, replacing non-alphanumeric characters with underscores, and prepends `customer_`. For example:
   
   - A group labeled `TrustedVPN` becomes `customer_trustedvpn`
   - A group labeled `Support-Team VPN` becomes `customer_support_team_vpn`
   - A group with no label becomes `customer_` with no suffix
- Migration is idempotent. If the migration process runs more than once, existing migrated rules are detected and not duplicated. You do not need to take any action to prevent double migration.

> **Tip:** After migration, verify that your lists and rules appear correctly in the Realm Security Rules tab in Business Manager. See [Realm Security Rules for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_realm_security_rules.htm&type=5).

> **Important:** A Cloudflare account-level Skip rule does not bypass zone-level rules. To preserve the original behavior of Trusted IPs (which globally bypassed all checks), Salesforce creates the Skip rule at every existing zone in your realm. If you create a new zone after the migration, you must add the Trusted IP Skip rule to that zone manually. Confirm the Managed IP List is referenced in a Skip rule on the new zone before relying on Trusted IPs for traffic to that zone.

### How Behavior Changes

The core purpose — making sure that traffic from trusted IP addresses is not blocked — is preserved. The mechanisms that implement it are more targeted in the new model.

### DDoS Layer 7 Override Details

When an account has account-level (realm-level) trusted IP lists configured, Salesforce automatically applies DDoS Layer 7 overrides on all eligible zones. These overrides are separate from the skip rule applied to custom firewall rules, WAF rules, and rate limiting rules. They are set to `sensitivity_level: off` and `action: log` to prevent false-positive challenges on legitimate high-volume traffic from trusted sources.

The following Cloudflare DDoS managed rules are automatically overridden:

| Rule ID | Description |
| --- | --- |
| `0b1e17bd25c74e38834f19043486aee1` | Unusual headers/URI path signature #1 |
| `466d6c2e8ba74459a2670e91e269dfd6` | Unusual headers/URI path signature #56 |
| `12b9aecf1f6245b29d7e842bf35a42a0` | Unusual headers/URI path signature #57 |
| `6e3ccc23900c428e8ec0fb8a3a679c52` | Requests from known bad sources |
| `d38bbe6dc925461ca4e47e4cecd68c61` | High request rate to search endpoints |
| `0a07c24f3cd44a57a5c19b73d2f294d7` | Requests trying to impersonate browsers |

> **Important:** DDoS Layer 7 overrides apply to all eligible zone types when an account has account-level trusted IPs — including Proxy, Legacy, Default Domain, BM, and Shopper Commerce API (SCAPI) zones. This is broader than zone-level skip rules, which do not apply to BM and SCAPI zones.

### Zone Type Eligibility

The following zone types support Realm Security Rules (same as legacy Trusted IP support):

- Proxy zones
- Legacy zones (custom vanity domains)
- Default Domain zones

### Feature Switch

Realm Security Rules are controlled by a feature switch in Business Manager. When the **Enable eCDN Trusted IP Migration** feature switch is enabled, the Security Rules tab with the Managed IP Address Lists and Custom Firewall Rules functionality becomes available in the Configure Zones interface. Contact your Salesforce account team if this tab is not visible in your organization.

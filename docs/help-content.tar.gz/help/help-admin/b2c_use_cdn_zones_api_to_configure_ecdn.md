# Use the CDN Zones API to Configure eCDN

_To set up development, staging, or production zones, your development team uses the CDN Zones APIs to upload customer certificates to test an Shopper Commerce API (SCAPI) implementation and configure vanity host names for development, staging, and production instances on eCDN._

If you use the CDN-API, you can see the zones that you create in Business Manager. (Available in the 24.4 release) Business Manager supports set up and management of eCDN for development, staging, and production. See [Create a Zone in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_zone.htm).

Use the CDN Zones component of the [Salesforce Commerce API](https://developer.salesforce.com/docs/commerce/commerce-api/overview) to configure and manage development, staging, and production eCDN zones.

> **Note:** Since the introduction of [Selective Origin Shielding](https://help.salesforce.com/s/articleView?id=commerce.rn_b2c_selective_origin_shielding_w9698195_21_8_je.htm&type=5) and [Origin Shielding](https://help.salesforce.com/s/articleView?id=000391803&type=1), all traffic through eCDN enforces origin shielding. The same applies to all configured instances.

## Related Content

- [Generate a Shortcode and Create an API Client ID](https://help.salesforce.com/s/articleView?id=cc.b2c_generate_a_shortcode_and_api_client_id.htm&type=5)
  To use the Salesforce Commerce API, you need:

- [Create an eCDN Zone and Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_create_an_ecdn_zone_and_certificate.htm&type=5)
  When a custom SSL certificate isn’t installed to your development, staging, or production instance POD, or a custom SSL certificate installed to the POD doesn't cover the hostname, create an eCDN zone, and upload the certificate for each domain name.

- [Migrate Site Traffic for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_site_traffic.htm&type=5)
  Configure traffic migration to move traffic over to eCDN

- [Post-Migration Tasks for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_post_migration_process.htm&type=5)
  Post-migration tasks validate your eCDN traffic flow and setup. To complete the post-migration process, coordinate with B2C Commerce Engineering. B2C Commerce Engineering creates and activates a staging Business Manager zone to handle your Business Manager traffic that goes through only your Business Manager host name, for example, `staging-<realm>-<customer>.demandware.net.`Business Manager supports eCDN for staging instances.

- [eCDN Maintenance](https://help.salesforce.com/s/articleView?id=cc.b2c_maintenance_and_configuration.htm&type=5)
  Use either Business Manager or the CDN zones API to manage the zones created to support eCDN on your development, staging, and production instance.

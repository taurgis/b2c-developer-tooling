# Manage Sequence Numbers in B2C Commerce

_Salesforce B2C Commerce uses sequence numbers as unique identifiers for automatically generated object instances._

|  |
| --- |
| Available in: **B2C Commerce** |

For example, when creating an order, B2C Commerce generates an order sequence number to identify the order. Use b2C Commerce to configure sequence numbers for single sites and entire orgs with many sites. Order Numbers are associated with Shipment and Invoice Numbers. If you configure Order Numbers to be site-specific, then Invoice and Shipment Numbers are also site-specific by default.

For some organizations, it's crucial to manage sequence numbers across the entire organization. It’s especially important if external third-party organization-wide applications manage customer and order data.

> **Note:** Generated sequence numbers are guaranteed to be unique within each object type, but aren’t guaranteed to be sequential. A generated number can be higher or lower than a previously created number. As a result, sorting objects by generated sequence numbers is not guaranteed to sort them in their order of creation.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Sequence Numbers**. Specify the global sequence number scheme (organizational) for the following:

   - Order Number
   - Invoice Number
   - Shipment Number
   - Customer Number
   - Gift Certificate Merchant ID
2. Click App Launcher _(image: App Launcher)_, and then select ** Merchant Tools > *site* > Site Preferences > Sequence Numbers**. Specify site-specific sequence number schemes to use instead of the global sequence number schemes.

   1. Configure Order Number as follows, and click **Apply:**
   
      Unique per Organization (recommended): Manage the number scheme in Global Preferences.
      
      Unique per Site: Specify the site-specific numbering schemes for the following: Order Number Invoice Number Shipment Number Gift Certificate Merchant ID
   2. Configure Gift Certificate Merchant ID as follows, and click **Apply:**
   
      Unique per Organization (recommended): Manage the number scheme in Global Preferences.
      
      Unique per Site: Specify the site-specific numbering schemes for the Gift Certificate Merchant ID.
3. Click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Customer Lists > site**. Specify the customer-list level sequence numbers.

   Select how you want sequence numbers to behave:
   
   - Unique per Organization: (Recommended) The customer sequence numbers are unique across the organization and share configuration.
   - Unique per Customer List: You can format customer numbers differently per customer list. This isn't recommended, because it can cause problems later if you decide to combine customer lists.
4. In all three modules, you define sequence numbers as follows:

   1. Define the starting point.
   2. Format of all sequence numbers to make sure they start at an appropriate value.
   3. To reflect your company's needs, define special formatting.
   4. Change the format using the following formula:
   
      ```
      <prefix>{0,number,00000000}<suffix>
      ```
      
      Where:
      
      | Parameter | Description |
      | --- | --- |
      | <prefix> | Is any static string or number with which you want all order numbers to begin. |
      | {0 | represents the start number created by the system that gets formatted with the format pattern. |
      | number | Interpreted as a keyword that tells the system to format the number as a numeric value. |
      | 0 | Specifies the number of numerical digits to include in the number. |
      | suffix | Any static string or number with which you want all order numbers to end. |
      
      For example:
      
      DW-{0,number,00000000}-05 translates to **DW-00000007-05,** where 00000007 is the next order number to be generated.
      
      XX-{0,number,00000000}-AA-{0,number,00000000}-ZZ results in a generated number like **XX-00000001-AA-00000001-ZZ.**

# XLS to XML Workbooks for Bulk Data Imports in B2C Commerce

_We've prepared some XLS to XML workbook resources to help you optimize your users’ experience with bulk data imports. This topic applies to B2C Commerce._

> **Note:** The workbooks are not Salesforce B2C Commerce supported. Any changes to the files are the responsibility of the customer.

Click a link to download a workbook.

- [How to Use Data Import Workbooks](http://salesforce.vidyard.com/watch/RUaWpozMtsz5KU9yGf5WYw): This video walks you through how to use the XLS to XML workbooks for data attribute bulk import into B2C Commerce Business Manager.
- [B2C Commerce Products and Catalogs Data Import Workbook](https://resources.docs.salesforce.com/rel1/doc/en-us/static/misc/SFCC_B2C_Products_Catalogs.xlsm): Use this XLS to XML workbook to update attributes for products, categories, recommendations, images, pricebooks, and inventory lists in bulk.
- [B2C Commerce Content Data Import Workbook](https://resources.docs.salesforce.com/rel1/doc/en-us/static/misc/SFCC_B2C_Content.xlsm): Use this XLS to XML workbook to update library folders, content assets, and content asset SEO metadata in bulk.
- [B2C Commerce Customer Groups Data Import Workbook](https://resources.docs.salesforce.com/rel1/doc/en-us/static/misc/SFCC_B2C_Customers.xlsm): Use this XLS to XML workbook to update static and dynamic customer groups in bulk.
- [B2C Commerce Onsite Search Configuration Bulk Update Workbook](https://resources.docs.salesforce.com/rel1/doc/en-us/static/misc/201904_SFCC_B2C_Search_Configurations_v2.xlsm): Use this XLS to XML workbook to update synonym groups, hypernyms, common phrases, compound words, category name exclusions, keyword groups, search suggestions, search-driven redirects, and sorting rule assignments in bulk.
- [B2C Commerce Online Marketing Bulk Update Workbook](https://resources.docs.salesforce.com/rel1/doc/en-us/static/misc/SFCC_B2C_Online_Marketing.xlsm): Use this XLS to XML workbook to update product promotions, order promotions, multiple coupon code groups, content slots and configurations, and stores in bulk.
- [B2C Commerce SEO Bulk Update Workbook](https://resources.docs.salesforce.com/rel1/doc/en-us/static/misc/SFCC_B2C_SEO.xlsm): Use this XLS to XML workbook to update product metadata, category metadata, content asset metadata, and URL redirects in bulk.

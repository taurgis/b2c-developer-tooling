# Enable the Search Information Tool for Storefront Toolkit in B2C Commerce

_To enable the Search Information tool, your site must correctly implement the `<isobject>` tag in the storefront Internet Store Markup Language (ISML) templates. This topic applies to B2C Commerce._

### Search Results Window

In order for the Search Information tool to display the Search Results window, the ISML template that loops over search results in your site must include the `isobject` tag configured as `<isobject object="object" view="searchhit">`, for example `<isobject object="${LoopProductHit}" view="searchhit">`. When view = “searchhit” the object passed should be of type `ProductHit`. This tag is also required to collect Analytics for the object.

The SiteGenesis and Salesforce Reference Architecture (SFRA) reference applications implement the `isobject` tag as required for the Search Results window. For other sites, implement the `isobject` tag as described to see the Search Results window.

### Product Search Model Window

In order for the Search Information tool to display the Product Search Model window, the search model must include an isobject tag configured as `<isobject object="object" view="none">`, for example `<isobject object="${ProductSearchModel}" view="none">`.

The SiteGenesis and SFRA reference applications don't implement the `isobject` tag as required for the Product Search Model window. For sites based on SiteGenesis or SFRA, and all other sites, implement the `isobject` tag as described to see the Product Search Model window.

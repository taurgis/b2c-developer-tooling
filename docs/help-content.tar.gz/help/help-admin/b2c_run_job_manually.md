# Run a Job Manually

_Execute a job manually as needed._

|  |
| --- |
| Available in: **B2C Commerce** |

- For jobs created in the new job framework:

   1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Jobs**.
   2. Select the job, and click **Run**.
- For legacy jobs:

   1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Jobs (deprecated)**.
   2. Select the job, and click **Run**.

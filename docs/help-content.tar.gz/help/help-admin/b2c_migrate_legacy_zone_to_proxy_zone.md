# Migrate a Legacy Zone to a Proxy Zone

_Migrate legacy zones to proxy zones using B2C Commerce Business Manager or the CDN-API. Proxy zones employ standard eCDN configuration, the latest security features, and prevent common hierarchy assignment issues. Migrating a legacy system to a proxy zone involves several key steps that provide a smooth transition and maintain system integrity. This migration is essential for moving to Hyperforce, as legacy zones aren’t supported._

## Related Content

- [Migrate to a Proxy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_migrate_to_proxy_zone.htm&type=5)
  To enhance security, improve load balancing, and comply with regulatory requirements, migrate legacy zones to proxy zones.

- [Configure Proxy Zone Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_configure_proxy_zone_settings.htm&type=5)
  Configure Proxy Zone Settings for Legacy Zone Migration.

- [Create a Custom Hostname with a Custom Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_create_custom_hostname_with_custom_cert.htm&type=5)
  When you migrate a legacy zone to a proxy zone, a certificate is automatically created with the validation method set to "http". If you need a different validation method, delete the generated certificate and add a custom one. Create the custom certificate in Business Manager or use the `addCertificateForZone`API.

- [Update Auth DNS](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_update_auth_dns.htm&type=5)
  Update your storefront DNS records. To get the DNS CNAME record value, use the `getZonesInfo` name property.

- [Remove the Subdomain from the Legacy Zone.](https://help.salesforce.com/s/articleView?id=cc.b2c_remove_subdomain_from_legacy.htm&type=5)
  Make sure the old certificate doesn't show in your website, when you remove the subdomain from the legacy zone.

- [Validate a New Certificate.](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_validate_new_certificate.htm&type=5)
  Validate the new certificate using the managed or self-managed process.

- [Delete the Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_delete_legacy_zone.htm&type=5)
  After you move all subdomains to the proxy zone, delete the legacy zone using the remove zone option.

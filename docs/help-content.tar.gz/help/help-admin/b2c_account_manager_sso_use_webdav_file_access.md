# Use Access Keys for WebDAV File, UX Studio Agent, User Login, Open Commerce API (OCAPI), and Protected Storefront Access

_For organizations using unified authentication, B2C Commerce offers an alternative form of authentication when logging into to Business Manager via external applications._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

WebDAV File Access, UX Studio Agent, User Login, OCAPI, and Protected Storefront Access keys can act as a substitute for your Unified Authentication password. Access keys expire after a year. If entered incorrectly six times, you can’t use that access key or your password to log in to that authentication scope.

**Create Access Key for Logins**

1. Click your username in the upper right corner of Business Manager.
2. Click Manage Access Keys. Enable, disable, or delete access keys. If an access key is expired or disabled, you can’t use that access key or your password to log in.
3. Generate an access key.
4. Select a scope for your key that determines what you can use the key to log into.
5. To copy your access key, click Download.

   You must copy the key now. After you close this screen, you can’t access this key again. We recommend that you keep the key in a safe place for future use.

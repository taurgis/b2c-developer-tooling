# User Authentication and Authorization in B2C Commerce

_As an administrator, you configure security controls in Business Manager. You must perform authentication to determine if the Business Manager user is who they claim to be. You can also perform authorization to determine if the user has permission to perform the specific action they’re attempting._

## Related Content

- [User Authentication for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_user_authentication.htm&type=5)
  Always use unified authentication in Salesforce B2C Commerce if you’re an administrator. Traditionally, we always used local user authentication, but a local user can perform only a local login into the Business Manager instance on which their credentials were created. After a site migrates to unified authentication, the site requires unified authentication on Account Manager, where a user can perform a global login into any Business Manager instance in their organization.

- [User Authorization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_user_authorization.htm&type=5)
  Salesforce B2C Commerce uses role-based access control to perform authorization. A user is assigned one or more roles, with each role consisting of a set of permissions. User authorization is configured in Business Manager using custom roles and permissions. The process primarily works the same way regardless of whether you use local or unified authentication.

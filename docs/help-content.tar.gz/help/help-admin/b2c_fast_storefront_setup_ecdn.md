# Storefront Fast Setup – eCDN Step

_The Storefront Next Fast Setup workflow in Business Manager automatically provisions an eCDN Default Domain zone as part of storefront creation via the `SetupEcdnForStorefront` job step._

### What the SetupEcdnForStorefront job step does

When you create a new storefront using the Fast Setup workflow, the `SetupEcdnForStorefront` job step runs automatically. It provisions an eCDN Default Domain zone for the storefront and registers the custom hostnames in the shared Cloudflare zones for the realm.

The job step performs the following actions:

1. Calls `POST /{organizationId}/configure-ecdn/ods` with the `originHostname` (ingress FQDN of the ODS instance) to kick off shared zone provisioning (storefront and BM zones) in the realm's Cloudflare account.
2. Calls `POST /{organizationId}/ods/hostnames` with `instance` and `bmHostname` to register the custom hostnames in the shared zones. The response returns the `storefrontHostname` and `bmOrigin` used to update Route53.

To verify shared zone creation before proceeding with custom hostname provisioning, use: `GET /{organizationId}/configure-ecdn/ods/status?zoneOnly=true`.

Required API scope and role: `edge.orchestration.rw` scope and `COMMERCECLOUD_APP` role (AM JWT).

### What gets provisioned

- eCDN storefront hostname: `<instance>.sbx.my.commercecloud.salesforce.com`
- eCDN Business Manager hostname: `<instance>.dx.commercecloud.salesforce.com` (routed through shared BM zone)
- Salesforce-managed wildcard certificates for both hostnames
- The Default Zone appears in Business Manager under **Administration > Sites > Embedded CDN Settings** after provisioning completes.

### Troubleshooting

**Error: `CDN-API default-domain/hostnames call failed`**

This error typically means the realm hasn't been provisioned for ODS eCDN — the shared zones haven't been created yet. To resolve:

1. Confirm that `configure-ecdn/ods` was called first to provision the shared zones for the realm.
2. Use `GET /{organizationId}/configure-ecdn/ods/status?zoneOnly=true` to check shared zone creation status.
3. If the shared zones aren't created, contact Salesforce Support.

**Storefront creation takes longer than expected**

eCDN zone provisioning and hostname verification can take up to 30 minutes. After that time, check the Embedded CDN Settings page in Business Manager for the Default Zone status. If provisioning hasn't completed, contact Salesforce Support.

**Pilot customers with vanity domains**

For 26.5 pilot customers using vanity hostnames on ODS, the automatic fast setup path may not apply. See the ODS Instance Migration Path guidance in [Create a Zone in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_zone.htm).

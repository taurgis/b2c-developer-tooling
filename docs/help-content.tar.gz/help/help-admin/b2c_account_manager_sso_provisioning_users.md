# Provisioning Users in Account Manager

_The current version of single sign-on (SSO) doesn’t yet support deletion of user accounts between B2C Commerce Account Manager and Salesforce Identity. An Account Manager admin creates a profile and assigns access for each user to applications like Business Manager or Control Center._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

When Just in time user provisioning is enabled in Account Manager, a user is automatically provisioned as part of SSO. After a User is provisioned, the Account Manager admin assigns roles to the user. The role assignment allows the user to access B2C Commerce Applications.

Until automatic deletion is available, the link between an Account Manager user and a Salesforce Identity profile persists. A deleted user in Salesforce Identity isn’t able to log in to Account Manager. An admin must reset the account in Account Manager to unlink accounts from Salesforce Identity.

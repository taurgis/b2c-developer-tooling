# Encryption and Cryptography in B2C Commerce

_Salesforce B2C Commerce extends Salesforce-maintained cryptography libraries that enable you to safely encrypt, sign, and generate cryptographically strong tokens and secure random identifiers. Salesforce maintains industry standard compliance frameworks as noted on the B2C Commerce page on Salesforce’s Trust Compliance website._

As a best practice, implement cryptography whenever you store, process, or transmit sensitive data. For cardholder data, specifically Primary Account Number (PAN), use tokenization. Use APIs exposed in the B2C Commerce API to make this happen while maintaining compliance.

Here are the most commonly used classes within the `dw.crypto` API.

- Cipher: Access point to encryption and decryption with various algorithms
- Encoding: A service for different character encoding
- Secure Random: A cryptographically-secure random token generator implementation

To maintain industry standard compliance frameworks and avoid vulnerabilities, don’t implement custom encryption and cryptography methods. Use industry-accepted and tested cryptographic methods with strong keys. To protect PCI and other sensitive information, the B2C Commerce dw.crypto undergoes regular reviews. It also allows for maintenance and protection of keys via Business Manager, where necessary. To benefit from Salesforce’s PCI Data Security Standard (DSS) Attestation of Compliance encryption requirements, the B2C Commerce platform-provided encryption methodologies must be used to protect Primary Account Numbers (PANs or credit card numbers).

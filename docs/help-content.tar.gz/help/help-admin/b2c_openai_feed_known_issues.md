# Known Issues

_Known issues and limitations for the OpenAI product feed integration._

The following issues are known.

### UI and User Experience

- **Autosave**: Field mapping changes may autosave. If you navigate away before changes are saved, your overrides may not persist.
- **Error toasts**: Error messages may appear as toasts that dismiss automatically. Note any error text before it disappears.

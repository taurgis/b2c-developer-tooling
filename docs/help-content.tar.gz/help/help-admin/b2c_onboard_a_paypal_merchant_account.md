# Onboard Your PayPal Merchant Account for B2C Commerce

_After you associate a PayPal Merchant account with your B2C Commerce instance, onboard the account. The PayPal onboarding process collects business information such as names, addresses, and bank accounts. The steps vary based on the merchant account country._

|  |
| --- |
| Available in: **B2C Commerce** |

Modify or add information from PayPal. Access the PayPal from Business Manager or from the Stripe site with your merchant account's user permissions.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
2. Click the PayPal merchant account that you want to onboard.
3. In the Manage Account Setup section, click **Manage Account at PayPal.com**.

   The system redirects you to the PayPal site. To complete the onboarding process, follow the instructions on the PayPal site. When the onboarding process is complete, youʼre returned to Business Manager.

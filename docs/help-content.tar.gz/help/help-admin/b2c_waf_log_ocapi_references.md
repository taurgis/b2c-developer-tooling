# eCDN-web application firewall (WAF) Log OCAPI References

_Request eCDN-WAF log files from Open Commerce API (OCAPI). Each realm supports up to 24 pending log request downloads.A minimum period of five minutes is now enforced for retrieving WAF logs._

The current time is 11 am. To retrieve a 60-minute increment log file, set the start time at 09:55 pm and the end time at 10:55 pm. The setting is for a 60-minute increment and the end time isn’t within 5 minutes of the current time (2 pm). This prevents setting the end time for log requests within 5 minutes of the current time.

## Related Content

- [Request eCDN-web application firewall (WAF) Logs with an Open Commerce API (OCAPI) Call](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_ocapi_call.htm&type=5)
  Use an OCAPI call to request the eCDN-WAF log. A minimum period of five minutes is now enforced for retrieving WAF logs.

- [JSON Log Output](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_ocapi_json_log_outputs.htm&type=5)
  All Open Commerce API (OCAPI) calls return all fields shown in the JavaScript Object Notation (JSON) log output.

- [Log Field Information for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_ocapi_log_fields.htm&type=5)
  The JSON request format provides category, field, and descriptions for the log output.

# Delete an Account in B2C Commerce

_You can delete an account only if you are an account administrator and the account is within one of your organizations. When you disable an account, the user can't log in to services using their credentials. When you delete an account, Account Manager still stores the user in the database for security-related reasons._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** To improve security, if a user is logged in and you delete their account, the user session is automatically invalidated.

To delete an account:

1. Log into Account Manager.
2. Click **Users**.

   The Users page opens, showing a list of accounts.
3. Click **Delete** next to the user whose account you want to delete.

   A dialog box opens, asking you to confirm that you want to delete the user's account. If you click **Cancel**, the delete operation is canceled, and the user's account isn't deleted.
4. Click **OK**.

   The account is now deleted. If the account is linked to a Salesforce account Account Manager cancels that link.

> **Note:** - Users in the **Deleted **state for more than 180 days are automatically purged.
> - After login, Adminstrators see a warning banner when users organization are in a **Deleted** state for more than 90 days.
> - When the Deleted Users Only filter is selected in the User List page, a warning tooltip displays next to users with a deleted status that exceeds 90 days. The tooltip message states the number of days until Account Manager purges the user.
> - Undelete users before they are automatically purged. See [Undelete an Account](https://documentation.b2c.commercecloud.salesforce.com/DOC1/topic/com.demandware.dochelp/content/b2c_commerce/topics/account_manager/b2c_account_manager_undelete_account.html?cp=0_11_16).

# Code Upload in B2C Commerce

_Upload custom code, also known as cartridges, to an instance using UX Studio, or with a file transfer mechanism such as WebDAV over Transport Layer Security (TLS). It’s important that you secure code uploads. Follow these best practices._

- Use two-factor authentication to upload code to the staging instance. The first factor depends on whether a user or API client performs the code upload. For users, the first factor is a username and password. For API clients, the first factor is an authorization token, minted by Account Manager.
   
   > **Note:** The API client must present its client-id/client-secret to receive the authorization token. The second factor is always a client certificate.
- Initially upload code into an inactive version on the staging instance.

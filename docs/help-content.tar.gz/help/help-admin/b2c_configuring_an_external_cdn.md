# Configure an External CDN or Third-Party Proxy

_Use your own content delivery network (CDN) with Salesforce B2C Commerce's embedded CDN to deliver static and dynamic content to your customers. Deploy your CDN (or a reverse proxy) in front of B2C Commerce to improve performance and security, or to provide extra functionality using your CDN._

|  |
| --- |
| Available in: **B2C Commerce** |

Customer CDN settings are instance-specific. They aren’t transferred to other instances with the Data Replication process.

Layer your CDN in front of the B2C Commerce platform. Specify the URL prefix used to create the URLs pointing to your CDN.

> **Important:** If you are leveraging only the embedded CDN that is included in B2C Commerce, don't change the following settings.

> **Note:** When fronting wildcard custom hostnames with an external CDN, make sure TXT‑based validation is supported and records are propagated. See [Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > SEO& Discoverability > Customer CDN Settings**.

   The Customer Content Delivery Network Settings page opens.
2. In the Dynamic Content section, enter the Client IP Header Name.

   The CDN uses the Client IP Header value to transfer the client's IP address to enable client IP-based services, such as geo-location. B2C Commerce uses this setting to retrieve the client IP address from a request header instead of the network connection source address. If the request header isn't provided, B2C Commerce uses the connection source address. If a CDN terminates client requests, B2C Commerce continues to use the client IP header name functionality.
   
   > **Note:** B2C Commerce prohibits use of the following header names, regardless of capitalization or if you replace the dashes with underscores:
   > 
   > - `cf-connecting-ip`
   > - `true-client-ip`
   > - `x-forwarded-for`
3. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > SEO& Discoverability > Aliases** and configure the site name.
4. Click **Save** (at the top right).

> **Note:** It's possible for the eCDN security feature to incorrectly identify a third-party proxy as an offending IP address or server. If this occurs, the eCDN blocks the third-party server, impacting more users than intended. To prevent this, use one of these options:
> 
> - Use the [CDN Zones API custom rules](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-custom-rules.html) (per zone) to selectively skip web application firewall (WAF), other custom rules, rate limits, or security levels for specified third-party IP addresses.
> - Add your stacked proxy to the firewall allowlist using the CDN Zones API custom rules. See [Add Stacked Proxy to the Firewall Allowlist](https://help.salesforce.com/s/articleView?id=cc.b2c_add_stacked_proxy_to_firewall_allowlist.htm&type=5). This method isn't recommended.
> - Verify third-party requests with [Secret Headers](https://help.salesforce.com/s/articleView?id=cc.b2c_verify_third_party_requests.htm&type=5)

After defining the Client IP Header Name and site aliases, complete the configuration by configuring your DNS and your external third-party proxy.

To configure a third-party proxy on top of the B2C Commerce platform:

1. On the third-party proxy:
   
   1. Enter the B2C Commerce instance as the origin server, for example, `your-domain.cdn.cloudflare.net`
   2. Pass the host header (for example, www.customer.com) back to the eCDN.
      
      > **Note:** Don’t send the entire B2C Commerce instance (www.customer.com.cdn.cloudflare.net) back to the eCDN.
   3. Configure the client IP header name as specified.
   4. Make sure that responses are only cached in the CDN if the origin sends a cache header.
2. On the DNS, point the DNS entry for your site to your `CDN CNAME`.

## Related Content

- [Add Stacked Proxy to the Firewall Allowlist](https://help.salesforce.com/s/articleView?id=cc.b2c_add_stacked_proxy_to_firewall_allowlist.htm&type=5)
  Use the CDN Zones API custom rules to selectively skip the web application firewall (WAF), other custom rules, rate limits, or security levels for third-party IP addresses that you specify.

- [Verify Third-Party Requests with Secret Headers](https://help.salesforce.com/s/articleView?id=cc.b2c_verify_third_party_requests.htm&type=5)
  Use secret headers as an alternative to maintaining the firewall allowlist for verified third-party servers. A secret header is an extra HTTP header typically attached at the CDN level.

# Playbooks and Additional Resources

_Looking for information that helps you address a specific area or insight when planning your next project? Well, look no further! We offer B2C Commerce Playbooks, Platform Adoption Playbooks, and additional resources that provide best practices for implementing, administering, and developing your ecommerce sites. This topic applies to B2C Commerce._

### B2C Commerce Playbooks

These B2C Commerce Playbooks cover a wide range of topics and help you use data and fact finding as your starting point for improving the shopper experience.

- [Improve Average Order Value (AOV)](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/B2CCommerceIncreaseAverageOrderValuePlaybook.pdf)
   
   Learn about using average order value (AOV) as a metric to evaluate sales trends and measure merchandising and promotion strategies.
- [Buy Online Pick up In Store (BOPIS) ](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/SalesforceB2CCommerce-BOPISImplementationPlaybook-April2020.pdf)
   
   Enable functionality that gives a shopper the ability to buy on line and pick up at a local store.
- [Improve the Checkout Experience](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/B2CCommerceCloudPlaybookImproveCheckoutExperience.pdf)
   
   Understand strategies and tools to help you review and optimize the checkout experience.
- [Improve Conversion Rate](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/B2CCommerceConversionRatePlaybook.pdf)
   
   Understand how to analyze conversion trends and determine strategies to increase this key metric.
- [Improve Product Discovery](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/B2CCommerceImproveProductDiscoveryPlaybook.pdf)
   
   Learn about strategies that drive conversion and revenue, helping site visitors find what they’re looking for.
- [Increase Site Traffic](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/B2CCommerceImproveTrafficPlaybook.pdf)
   
   Learn key plays to drive qualified traffic and optimize site speed.

### Platform Adoption Playbooks

Platform Adoption Playbooks help you understand the merchandising and marketing building blocks in Business Manager, including overviews of basic settings and functionality, tips, and best practices.

- [A/B Testing](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_AB_Testing_Platform_Adoption_Playbook.pdf)
   
   Test site experiences to optimize results.
- [Campaigns](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Campaigns_Platform_Adoption_Playbook.pdf)
   
   Use campaigns to create unique shopping experiences for different customer segments.
- [Content Slots](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Content_Slots_Platform_Adoption_Playbook.pdf)
   
   Walk through the basics of how to use content slots for promotional and personalized messaging on your site.
- [Coupon Codes](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Coupon_Codes_Platform_Adoption_Playbook.pdf)
   
   Provide discounts by using coupon codes.
- [Customer Groups](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Customer_Groups_Platform_Adoption_Playbook.pdf)
   
   Tailor the site experience for different sets of customers.
- [Promotions](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Promotions_Platform_Adoption_Playbook.pdf)
   
   Create discounts to incentivize purchases and grow revenue.
- [Search Engine Optimization (SEO)](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/seo_platform_adoption_playbook.pdf)
   
   Optimize SEO to make sure that search engines find your products.
- [Site Search](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Site_Search_Platform_Adoption_Playbook.pdf)
   
   Increase revenue by providing relevant search results.
- [Sorting Rules](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Sorting_Rules_Platform_Adoption_Playbook.pdf)
   
   Put products in a varied sequence using manual merchandising, active data, and Artificial Intelligence.
- [Source Codes](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Source_Codes_Platform_Adoption_Playbook.pdf)
   
   Use source codes to trigger unique shopping experiences based on traffic source.

### Retail Operations Canvas

The Retail Operations Canvas visually captures the key operational steps involved in establishing a successful retail enterprise. Leverage these resources to map a holistic, customer-focused perspective on your organization’s operational activities.

- [Retail Operations Canvas User Guide](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Retail_Operations_Canvas_User_Guide_EN.pdf)
   
   Learn about using this tool to guide retail operations and team planning.
- [Retail Operations Canvas Template](https://org62.my.salesforce.com/sfc/p/#000000000062/a/0M000000YDxW/QzzKAWMqtEnXf2lbNtUmq2_ACImLPJe0Ec1W30j3JEk)
   
   Use this retail operations template to highlight gaps, interfaces, and opportunities for growth.

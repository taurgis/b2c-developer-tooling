# Log Center Search

_Use Log Center to search logs with custom searches. You configure a search with query filters from categories such as period, message severity, issue type, key words, specific text, and other attributes._

When you start Log Center, you see the search page for your tenant Realm. The page lists the results of the last completed search.

Logs are available to view from one minute to the past 14 days. Log Center’s high volume processing, supports daily log volume and data retention limits. For PIGs, log volume is set using a tenant tier structure. For SIGs, the log volume default is 1 million per day with a maximum limit of 2 million per day. Request log volume increases for both PIG and SIG environments.

## Related Content

- [Keyword Search in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_keyword_search_in_log_center.htm&type=5)
  Use keyword search to find the logs that contain certain terms. When you enter text or an ID in the text message, the search looks several places. It looks in the text message, activity ID, category name, thread name, and message stack trace. When you click the Search icon, the results appear in a list. The severity panel to the left shows the number of issues per severity that contain the text or ID. If the severity is selected as a filter on the left side, the keyword/ID search is restricted to a particular severity.

- [Configure and Run a Log Center Search](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_and_run_log_center_search.htm&type=5)
  Search for messages from system and custom code.

- [Save a Search Rule](https://help.salesforce.com/s/articleView?id=cc.b2c_save_a_search_rule.htm&type=5)
  Save search filter settings to use when needed. For example, use a search rule to set up recurring notifications.

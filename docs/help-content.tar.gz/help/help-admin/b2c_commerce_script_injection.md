# Commerce Script Injection in B2C Commerce

_Server script injection, or remote code execution, is a class of attack where maliciously crafted input is run in a privileged code execution context. This class of attack enables an attacker to control the code executed on the server._

Script injection is possible when a script interprets part or all of an unsafe or untrusted data input as code, or a snippet of code, and runs it. The most common error that results in code injection vulnerability is to call the global method `eval( string )` with an argument tainted with untrusted data. The `eval` method executes the passed string as a script expression. This method is deprecated. Avoid using it to prevent security risks.

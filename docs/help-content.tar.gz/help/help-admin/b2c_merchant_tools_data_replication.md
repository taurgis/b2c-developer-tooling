# Merchant Tools Data Replication in B2C Commerce

_These tables map Business Manager Merchant Tools modules to data replication tasks. This topic applies to B2C Commerce._

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Libraries | Content Library | Site |
| Library Folder | Content Library | Site |
| Content Assets | Content Library | Site |
| Import & Export | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Customers | N/A | N/A |
| Customer Groups | Customer Groups | Site |
| Snapshots | N/A | N/A |
| Batch Processes | N/A | N/A |
| Import & Export | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Custom Object Editor | Custom Object Types Custom Objects | Custom Object Types: Global Custom Objects: Global and Site |
| Batch Processes | N/A | N/A |
| Import & Export | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| URL Rules | SEO | Site |
| URL Redirects | SEO | Site |
| Dynamic Mapping | SEO | Site |
| Static Mapping | SEO | Site |
| Robots | System Preferences | Site |
| Aliases | N/A | N/A |
| Customer CDN Settings |  |  |
| Sitemaps | N/A | N/A |
| URL Request Analyzer | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Products | Catalogs | Global |
| Product Sets | Catalogs | Global |
| Catalogs | Catalogs | Global |
| Catalogs (Beta) | Catalogs | Global |
| Product Options | Catalogs | Global |
| Variation Attributes | Catalogs | Global |
| Recommendations (explicit) | Catalogs | Global |
| Price Books | Price Books | Global |
| Inventory Lists | N/A | N/A |
| Catalog Feeds | N/A | N/A |
| Batch Processes | N/A | N/A |
| Import & Export | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Orders | N/A | N/A |
| Taxation | Taxation | Site |
| Payment Processors | Payment | Site |
| Payment Methods | Payment | Site |
| Shipping Methods | Shipping Methods | Site |
| Import & Export | N/A | N/A |
| Customer Service Center | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Search Indexes | Search Indexes | Site |
| Search Index Rebuild Schedule | N/A | N/A |
| Search Index Query Testing | N/A | N/A |
| Search Dictionaries | Search Indexes | Site |
| Searchable Attributes | Search Indexes | Site |
| Search Driven Redirects | Search Indexes | Site |
| Stop Word Dictionary | Search Indexes | Site |
| Category Name Exclusions | Search Indexes | Site |
| Synonym Dictionary | Search Indexes | Site |
| Hypernym Dictionary | Search Indexes | Site |
| Compound Word Dictionary | Search Indexes | Site |
| Common Phrase Dictionary | Search Indexes | Site |
| Search Suggestions | Search Indexes | Site |
| Stemming Exceptions | Search Indexes | Site |
| Sorting Rules | Search Indexes | Site |
| Storefront Sorting Options | Search Indexes | Site |
| Search Preferences | Preferences | Site |
| Import & Export | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Campaigns | Campaigns | Site |
| A/B Tests | A/B Tests A/B Tests and Experiences | Site |
| Promotions | Campaigns | Site |
| Content Slots | Content Slots | Site |
| Coupons | Coupons | Site |
| Source Code Groups | Source Codes | Site |
| Active Data (feed definitions only) | Active Data Feeds | Site |
| Stores | Stores | Site |
| Gift Certificates | N/A | N/A |
| Import & Export | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| All reports | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Locking | Preferences | Site |
| Baskets | Preferences | Site |
| A/B Tests |  | Site |
| Locales | Preferences | Site |
| Currencies | Sites | Global |
| Source Codes |  |  |
| Gift Certificates | N/A | N/A |
| Search Preferences | Preferences | Site |
| Sequence Numbers | Preferences | Site |
| Order | Preferences | Site |
| Coupons |  |  |
| Promotions |  |  |
| Storefront Toolkit |  |  |
| Storefront URLs |  |  |
| Custom Preferences |  |  |
| Pinterest Commerce |  |  |
| Privacy |  |  |
| Customer Service Center Preferences |  |  |
| Apple Pay |  |  |

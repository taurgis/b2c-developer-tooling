# WebDAV Client Permissions

_WebDav client permissions let you configure which API clients can access your WebDAV files. These permissions also give you fine-grained control over which directories each client can access._

To configure these permissions in Business Manager, create a JSON configuration document that conforms to the format described in the following example.

### Configuring WebDAV Client Permissions in Business Manager

To configure WebDAV client permissions:

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > WebDAV Client Permissions**.
2. In the large text field, edit the JSON document configuration as described in the following example.
3. Click **Save**.

### JSON Document Format

The following example shows the format of the JSON configuration document:

```
{  
   "clients":[  
      {  
         "client_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
         "permissions":[  
            {  
               "path":"/impex/src/foo",
               "operations":[  
                  "read_write"
               ]
            },
            {  
               "path":"/impex/src/logs",
               "operations":[  
                  "read"
               ]
            },
            {  
               "path":"/catalogs",
               "operations":[  
                  "read"
               ]
            }
         ]
      },
      {  
         "client_id":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaab",
         "permissions":[  
            {  
               "path":"/impex/",
               "operations":[  
                  "read_write"
               ]
            }
         ]
      }
   ]
}
```

### Configuration Document

Use this document to configure WebDAV client permissions for multiple client applications in the context of your organization.

| Property | Type | Constraints | Description |
| --- | --- | --- | --- |
| `clients` | [ [-->Client](b2c_web_dav_client_permissions.xml#b2c_web_dav_client_permissions/client)] | N/A | Array of client-specific permission documents |

### Client Document

Use this document to define WebDAV permissions for a client application.

| Property | Type | Constraints | Description |
| --- | --- | --- | --- |
| `client_id` | String | mandatory=true, nullable=false | The client ID indicating the API client for which the permissions are configured |
| `permissions` | [ [Permissions](b2c_web_dav_client_permissions.xml#b2c_web_dav_client_permissions/permissions)] | mandatory=true, nullable=false | Array of directory-based permissions documents  Multiple permissions paths can't intersect each other; for example, the following two paths intersect and are therefore invalid: `/impex/src` and `/impex/src/foo` |

### Permissions Document

Use this document to configure WebDAV permissions.

| Property | Type | Constraints | Description |
| --- | --- | --- | --- |
| `path` | String | mandatory=true, nullable=false. The `path` must begin with `/impex`, `/catalogs`, `/dynamic`, `/libraries`, `/logs`, `/static`, or `/securitylogs` | Directory for which the WebDav permission is granted, including all subdirectories File-specific permissions aren't permittedFiles in the `/securitylogs` path can be granted only read permissions, not read_write permissions. |
| `operation` | [String] | mandatory=true, nullable=false, minItems=1 | Array of operations granted on this directory (Possible values are `read` and `read_write`) Read-only WebDAV commands are `GET`, `OPTIONS`, `PROPFIND`  Read-write WebDAV commands are COPY, `MOVE`, `DELETE`, `MKCOL`, `PUT`, `POST`, `PROPPATCH`, `ZIP`, and `UNZIP`  To use the `COPY` command, the client needs `read` permissions for the source directory and `read_write` permissions for the target directory To use the `MOVE` command, the client needs `read_write` permissions for both the source and target directories |

### Staging

Replicate WebDAV client permissions to Production instances using the Global > WebDAV Client Permission option within the replication tasks (click App Launcher _(image: App Launcher)_, and then select **Administration > Replication > Data Replication**).

### Import/Export

To export WebDAV client permissions, select Global Data > WebDAV Client Permissions in the import/export tree (click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Site Import & Export**). The configuration file location within the generated .zip file is `webdav/client_permissions.json`.

### Change History

Auditing turns on if Change History is enabled and Sites & Preferences is being audited. Change entries are tracked as organization type within the sites scope.

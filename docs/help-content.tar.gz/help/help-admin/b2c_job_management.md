# Managing Jobs

_After you create jobs, use Business Manager to manage them. This topic applies to B2C Commerce._

## Related Content

- [View Job History](https://help.salesforce.com/s/articleView?id=cc.b2c_view_job_history.htm&type=5)
  View the job history page to see information about jobs, including status, end time, and duration.

- [Monitor Job Statistics](https://help.salesforce.com/s/articleView?id=cc.b2c_monitor_job_stats.htm&type=5)
  Monitor the duration and number of executions for jobs. Filter and sort the statistics.

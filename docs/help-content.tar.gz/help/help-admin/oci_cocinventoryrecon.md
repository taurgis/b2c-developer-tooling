# Capturing Offline Orders and Inventory Reconciliation

_During Omnichannel Inventory service interruptions, Continuous Order Capture queues B2C Commerce orders to maintain business continuity. The system accepts orders based on the last known inventory data. To avoid overselling, B2C Commerce automatically decrements the Available-To-Order (ATO) value immediately after each order is created. The system marks these orders as Reservation Missing until Omnichannel Inventory recovers. After the connection is restored, the system automatically reconciles the inventory and creates reconciliation reports._

### Automatic Reconciliation

After the Omnichannel Inventory connection for B2C Commerce is restored, a background job automatically reconciles inventory for orders in the Reservation Missing state. This job processes orders in batches. It typically takes 10–20 minutes for reconciliation to complete. Business Manager alerts automatically notify you of the current state and the reconciliation outcome.

After the job attempts a reservation, if the attempt is successful, the job clears the Reservation Missing state with one of these reconciliation outcomes:

- Completely Reserved: All items are reserved.
- Partially Reserved: Only some items are reserved.
- Nothing Reserved: No inventory is available for any items.
- Omnichannel Inventory Remains offline: The service is still unavailable. The order remains in the Reservation Missing state and the system retries to change the state in the next cycle.

> **Note:** If you’ve configured Salesforce Order Management, after the reservation attempts, orders are automatically pushed to Order Management. These transactions also appear in the reconciliation reports in the Business Manager. See [Continuous Order Capture with Salesforce Order Management.](https://help.salesforce.com/s/articleView?id=cc.oci_cocsomb2c.htm&type=5)

### Reconciliation Reports

The system generates reconciliations reports at `[SHARED_DIR_IMPEX]/src/continuous_order_capture/` to help you audit offline activity:

- Offline: All the orders captured during the outage.
- Reserved: Orders with successfully secured inventory for all items.
- Oversold: Orders with partial or failed reservation attempt.

Here’s the directory structure:

```
continuous_order_capture/
├── work/                          # Temporary work files (transient)
│   ├── offline_<site>_<timestamp>_<orderNo>.json
│   ├── reserved_<site>_<timestamp>_<orderNo>.json
│   └── oversold_<site>_<timestamp>_<orderNo>.json
├── <yyyyMMdd>_offline_<site>.json # Daily merged offline orders
├── <yyyyMMdd>_reserved_<site>.json# Daily merged reserved orders
└── <yyyyMMdd>_oversold_<site>.json# Daily merged oversold orders
```

The file naming convention is:

| File Type | Convention | Examples |
| --- | --- | --- |
| Work files for individual offline, reserved, and oversold orders | {prefix}_{site}_{yyyyMMdd}_{HHmmss}_{orderNo}.json | offline_MySite_20260202_120000_0000012345.json |
| reserved_MySite_20260202_120000_0000012345.json |  |  |
| oversold_MySite_20260202_120000_0000012345.json |  |  |
| Daily merged offline, reserved, and oversold files by site | {yyyyMMdd}_{prefix}_{site}.json | 20260202_offline_MySite.json |
| 20260202_reserved_MySite.json |  |  |
| 20260202_oversold_MySite.json |  |  |

While B2C Commerce counts down Available-to-Order (ATO) based on the last known inventory data, other sales channels can also deplete stock managed in Omnichannel Inventory, potentially resulting in some overselling. Either cancel the orders that you aren’t able to fulfill or offer replacement items. If you’re able to fulfill the orders, use the Omnichannel Inventory REST APIs to manually update reservations.

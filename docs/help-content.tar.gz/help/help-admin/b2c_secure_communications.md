# Secure Communications in B2C Commerce

_Secure communications are crucial to prevent attackers from reading or changing sensitive information, for example, credit cards, personally identifiable information (PII), and credentials. Within Salesforce B2C Commerce, you can secure these interactions using the following secure protocols._

| Interaction | Between... | Via... |
| --- | --- | --- |
| Storefront | Shoppers and your storefront. | Transport Layer Security (TLS) |
| Business Manager | Users and Business Manager.This interaction is always secured by the site and doesn’t require a separate configuration. | TLS |
| Web Services | Your instance and an external web service. | Simple Object Access Protocol (SOAP) over TLS, HTTPS, Secure File Transfer Protocol (SFTP) |
| File Upload | Your instance and an external system. | WebDAV over TLS (recommended), HTTPS, SFTP |

## Related Content

- [HTTPS / TLS in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_http_tls.htm&type=5)
  In HTTPS, the communication protocol is encrypted using transport layer security (TLS) or its predecessor, secure sockets layer (SSL). The protocol is also often referred to as HTTP over TLS, or HTTP over SSL.

- [Web Services in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_web_services.htm&type=5)
  Salesforce B2C Commerce provides a web services framework that helps you manage calls to web services and analyze service performance. You need custom code to interact with a web service. We recommend that you use secure protocols as web service types, such as HTTPS, Secure File Transfer Protocol (SFTP), and Simple Object Access Protocol (SOAP) over Transport Layer Security (TLS). A web service can also use a service credential, such as username and password, to perform HTTP basic authentication.

- [Data Upload in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_upload.htm&type=5)
  Data upload refers to transferring data files from an external system to your instance’s file system. Upload data such as import files, images, and snapshots manually or programmatically. Use Business Manager to transfer data manually. As always, any interaction with Business Manager occurs over HTTPS. Custom code performs data transfer programmatically. In this case, while several file transfer protocols are supported, use only the secure protocols: WebDAV over Transport Layer Security (TLS) (recommended), HTTPS, or Secure File Transfer Protocol (SFTP).

- [Code Upload in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_code_upload.htm&type=5)
  Upload custom code, also known as cartridges, to an instance using UX Studio, or with a file transfer mechanism such as WebDAV over Transport Layer Security (TLS). It’s important that you secure code uploads. Follow these best practices.

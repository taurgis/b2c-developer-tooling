# Archiving in B2C Commerce

_You can't automatically roll back instances impacted by data import. Therefore, it’s a good practice to create an archive of your existing site that you can roll back to if the import fails. This topic applies to B2C Commerce._

Salesforce recommends that you keep import feeds for a specified period and regularly export and archive data that only exists in the Business Manager. Exported data is also useful if users make a mistake in Business Manager and change or eliminate data inappropriately.

B2C Commerce scripts can archive import feeds and remove out-of-date files. Alternatively, archive feeds on your backend system.

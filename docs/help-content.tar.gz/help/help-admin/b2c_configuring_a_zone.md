# Configure an eCDN Zone in Business Manager

_Configure SSL/TLS, certificates, security rules, performance, custom pages, request logs, and Under Attack Mode for an eCDN zone by using the Configure Zone screen in Business Manager._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Note:** Before you configure a zone, the zone must be created and verified. See Create a Zone for details.

Zone settings are organized into four categories:

| Category | Description |
| --- | --- |
| Crypto | Contains settings related to security and cryptography, such as SSL/TLS and certificates. |
| Firewall | Contains settings related to trusted IP list. |
| Speed | Contains settings related to the speed of your ecommerce site, such as Early Hints, HTTP/3, HTTP/2 to Origin and polish to reduce size of images. |
| Customize | Contains settings related to the creation of custom HTML pages used for errors from the embedded CDN. |

> **Important:** **Under Attack Mode** is available as a toggle in the top right corner of all tabs in the Configure Zones interface. Enable Under Attack Mode only as a last resort during an active DDoS attack. When enabled, Cloudflare slows down visits to the targeted storefront and presents a Completely Automated Public Turing test to tell Computers and Humans Apart (CAPTCHA) challenge to every unique visitor before allowing access to the site.

The new Configure Zone screens covered in this guide are listed here:

| Tab or Control | Purpose |
| --- | --- |
| Crypto tab | SSL/TLS, certificates, and HTTP Strict Transport Security (HSTS). |
| Security Rules tab - web application firewall (WAF) Rules section | WAF managed rulesets for the zone. |
| Speed tab | Performance optimizations. |
| Customization tab | Custom error and challenge pages. |
| Logs tab - Logpull section | Download recent request logs. |
| Under Attack Mode toggle (zone header) | Emergency interstitial challenge for all visitors. |

## Configure Zone tab layout in Business Manager

_(image: Configure Zone screen showing the zone header and tab layout, including Crypto, Security Rules, Analytics, Speed, Host Header Override Rules, Page Shield Policies, Customization, and Logs.)_

> **Note:** If a tab doesn't fit on screen, it appears under a **More** dropdown on the right.

> **Note:** Looking for Realm Security Rules or Managed IP Address Lists? See [Trusted IP Configuration Migration](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_trusted_ips_to_custom_rules.htm&type=5).

> **Note:** If you don't see the tabs or toggle described in this guide, ask your admin or Salesforce representative to enable the new Configure Zone screen for your instance.

To open the Configure Zone screen:

> **Note:** In the zone actions menu, **Configure Zone** and **Configure Routing Rules** are separate workflows. This topic covers only **Configure Zone** tab settings.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.

   > **Note:** If there's no embedded CDN enabled for your instance, the following message appears: `The embedded CDN has not been enabled`.
   
   The Embedded CDN Settings page lists zones and their available actions.
2. Find the zone you want to configure.
3. Open the zone's actions menu on the right side of the zone row, and select **Configure Zone**.

   The Configure Zone screen opens for the selected zone.
   
   ### Configure Zone option in zone actions menu
   
   _(image: Embedded CDN Settings page showing a zone row actions menu with Configure Zone and Configure Routing Rules options.)_
4. (Optional) To enable **Under Attack Mode**, turn on the toggle in the zone header and, in the confirmation dialog, click **Enable**.

   Under Attack Mode shows an interstitial challenge to every visitor before allowing access to your storefront. Use it only as a last resort during an active DDoS attack.
   
   To turn it off, switch the toggle off. No confirmation is required.
   
   ### Under Attack Mode toggle in zone header
   
   _(image: Configure Zone header showing the Under Attack Mode toggle at the top right above zone tabs.)_
5. In the slider, click **Crypto**.

   1. Add a certificate to a zone or add a certificate to a proxy zone.
   2. (Optional) Set a Transport Layer Security (TLS) level. This setting enables the TLS 1.3 protocol. If the requesting browser does not support TLS 1.3, it typically falls back to using the TLS 1.2 protocol.
   3. (Optional) Configure HSTS. This option appears only after you enable the HSTS feature switch.
6. In the slider, click **Firewall**.

   1. Specify a Security Level.
   
      > **Important:** A threat score is no longer required. All security levels are now always protected. Switch to under-attack mode when you detect a DDoS attack. This mode slows down visits to the a targeted website and conducts additional checks to identify malicious visitors. Under Attack mode presents a CAPTCHA to every unique user before they're allowed to see the storefront. During an attempted DDoS attack, use this mode only as a last resort to stop the attack.
      
      | Security Level | Description |
      | --- | --- |
      | Low | Always Protected |
      | Medium | Always Protected |
      | High | Always Protected |
      | Under Attack | Always Protected, Enabled (Under attack mode) |
      
      The Security Level uses the IP reputation of a visitor to decide whether to present a challenge. When challenged, a visitor solves a CAPTCHA before logging in. An internal algorithm calculates the IP reputation.
   2. Adjust the Security Level for your domain in the Firewall app.
   3. (Optional) In the Firewall section, click **Add Group**.
   
      The Add Group window opens.
      
      The Add Group button enables you to define a *trusted IP list group*. An trusted IP list group specifies a set of IP addresses that the eCDN never blocks.
      
      Configuring trusted IP list groups is useful when you have an external CDN deployed in front of the eCDN. Adding IP addresses of your external CDN to the trusted IP list ensures against misinterpreting numerous requests from small sets of IP addresses as a Denial of Service (DoS) attack.
   4. Select a value in the Scope field.
   
      | Scope Value | Description |
      | --- | --- |
      | Global | The eCDN applies the trusted IP list to all zones in your organization. |
      | Zone | The eCDN applies the trusted IP list only to the current zone. |
   5. In the Group Name field, enter a name for the trusted IP listing.
   6. In the Records field, enter one or more IP address records.
   
      Specify one record per line. A record consists of a single IPv4 address or a range of IPv4 addresses in CIDR (Classless Inter-Domain Routing) format. If you use CIDR format, the embedded CDN accepts only /16 and /24 subnets.
   7. To validate and save your trusted IP list group, click **Validate**.
7. In the slider, click **Speed**.

   1. (Optional) In the Optimization section, select any of the following settings to improve site performance. Below is a table that describes each setting:
   
      | Speed Setting | Action |
      | --- | --- |
      | Early Hints | Early Hints makes the most of the time while the server prepares a response. With this approach instructions are sent to the browser to start loading resources while the origin server is busy. Sending these hints before the full response is ready helps the browser load the webpage faster for the end user. To take advantage of 103 Early Hints, enable the `Link` HTTP header in the `addHttpHeader` method within the `dw.system.Response class`. To enable this header, use the `addHttpHeader` method to set Link headers for your responses. Typically `rel=preload` and `rel=preconnect` are used with the primary need to support `rel=preload )with as=... Values image, style, script) and rel=preconnect` Link headers. response.addHttpHeader("Link", "</path/to/resource>; rel=preload; as=image"); response.addHttpHeader("Link", "<https://example.com>; rel=preconnect"); This ensures that the HTTP response includes the necessary Link headers, and then enabling Early Hints functionality in the eCDN settings in BM UI. Sending these hints to a browser before the full response is ready helps the browser load the webpage faster for the end user. For reference see [MDN Web Docs - Link](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Link) |
      | HTTP/3 | HTTP/3 uses QUIC, which is a secure-by-default transport protocol. HTTP/3 improves page load times in a similar way to HTTP/2. However, the QUIC transport protocol solves TCP’s head-of-line blocking problem, meaning that performance over lossy networks can be better. |
      | HTTP/2 Origin | Leverages HTTP/2 protocol between eCDN and the origin, meaning performance can be better between the two. This setting takes effect only when your origin supports HTTP/2. |
      | Brotli | Support for the WebP image format when using image modification for a zone. The WebP image format can be used with supported clients for added performance benefits. Using Brotli for serving static text-based web assets (HTML, CSS, JS, JSON) provides better performance, smaller payloads and faster delivery times. This enhancement allows for easier and more intuitive management of compression settings. |
      
      These speed settings usually improve site performance, but the degree to which it depends on various unique aspects of the site’s configuration. Test each speed setting one at a time to accurately measure the performance improvement of each feature.
      
      _(image: Speed Setting Options)_
   2. (Optional) In the Polish Level section, select one of the following options:
   
      | Polish Level Option | Action |
      | --- | --- |
      | Polish Level Off | No images modification occurs. |
      | Polish Level Basic | This option reduces image file size without impacting visual quality and removes metadata for PNG, GIF, and JPEG files. It also results in lossless compression of PNG and GIF files. |
      | Polish Level Basic+JPEG | In addition to the actions for the basic level, the eCDN reduces JPEG image file size using lossy compression, which can reduce visual quality. The eCDN converts large JPEG images to progressive images (site visitors see an increasingly detailed image as the file downloads). This functionality applies only to images served through the eCDN (that is, images served by the B2C Commerce instance and Dynamic Imaging Service [DIS}). Images retrieved from third-party sites are not modified. |
      
      The polish level applies to all images served from hostnames within the zone. It isn't possible to use different polish levels for different images or a device type-specific polish level. Test a new Polish Level with a zone without production traffic before you enable it for a zone with production traffic.
   3. (Optional) In the Polish Level section, check **WebP** to enable WebP image support.
   
      The eCDN supports the `WebP` image format, which can be used with supported clients for added performance benefits.
      
      If you choose the Polish Level Basic setting (GIF, PNG)
      
      - WebP is rarely used because in this mode, WebP is only adequate for PNG images, and can't improve compression for JPEG images.
      
      If you choose the Polish Level Basic + JPEG
      
      - Although on average, WebP compresses better than JPEG there are exceptions and in some cases JPEG compresses better than WebP. eCDN attempts to detect these cases and keep the JPEG format.
      - eCDN doesn't convert from JPEG to WebP when the conversion makes the file bigger, or reduces image quality by more than it can save in file size.
      - The eCDN converts large JPEG images to progressive images. Shoppers see an increasingly detailed image as the file downloads.
8. In the slider, click **Customize**.

   1. In the Custom Pages: 500 Class Errors section, enter the URL for an HTML page you want shown when the embedded CDN generates a 500 class error.
   
      The HTML page embeds the 500 error class token (for example, `<p>::CLOUDFLARE_ERROR_500S_BOX::</p>`). The token is case-sensitive and must match exactly.
   2. In the Custom Pages: 1000 Class Errors section, enter the URL for an HTML page you want shown when the embedded CDN generates a 1000 class error.
   
      The HTML page embeds the 1000 error class token (for example, `<p>::CLOUDFLARE_ERROR_1000S_BOX::</p>`). 1000-class errors include Cloudflare 100x conditions such as DNS resolution failures and security challenge failures. The token is case-sensitive and must match exactly.
9. To inform eCDN that this page is ready for all subdomains in the zone, click **Publish**.

   To set a new eCDN custom error page, use the B2C Commerce instance to make the page template available under a publicly accessible URL. During the publishing step, the eCDN downloads the error page template and stores it in the infrastructure.
   
   > **Note:** Repeat the publishing step whenever the template changes.

## Related Content

- [Configure Crypto Settings for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_crypto_settings.htm&type=5)
  Configure SSL/TLS and cryptography settings for an eCDN zone, including Transport Layer Security (TLS) version and HTTP Strict Transport Security (HSTS), using the Configure Zones interface in Business Manager.

- [Configure WAF Settings for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_waf_settings.htm&type=5)
  Configure Web Application Firewall (WAF) managed rulesets for an eCDN zone by using the Security Rules tab in Configure Zones in Business Manager.

- [Configure Firewall Settings for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_firewall_settings.htm&type=5)
  Configure firewall settings for an eCDN zone using the Configure Zones interface in Business Manager.

- [Realm Security Rules for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_realm_security_rules.htm&type=5)
  Realm Security Rules let you define Managed IP Address Lists and Custom Firewall Rules that control how trusted IP traffic is handled across your eCDN zones. These rules replace the legacy Trusted IP configuration.

- [Analytics for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_analytics.htm&type=5)
  View HTTP and security traffic metrics for an eCDN zone, including the Traffic Analysis timeline chart and top statistics, using the Configure Zones interface in Business Manager.

- [Configure Speed Settings for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_speed_settings.htm&type=5)
  Optimize zone performance by enabling speed settings such as Early Hints, HTTP/3, and image compression via the Configure Zones interface in Business Manager.

- [Configure Host Header Override Rules for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_host_header_override_rules.htm&type=5)
  Create rules that override the HTTP Host header sent to your origin server for an eCDN zone, using the Configure Zones interface in Business Manager.

- [Configure Page Shield Policies for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_page_shield_policies.htm&type=5)
  Configure Page Shield policies that detect and identify supply chain attacks affecting your storefront, using the Configure Zones interface in Business Manager.

- [Configure Custom Error Pages for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_custom_error_pages.htm&type=5)
  Set custom HTML error pages for 500-class and 1000-class errors generated by the embedded CDN for a zone.

- [Configure Notifications for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_notifications.htm&type=5)
  Get notified when eCDN events that matter to you happen, such as a Logpush job failure on a PCI-bound zone, a security incident, or a configuration change, without having to watch dashboards. The Notifications tab on the Configure Zone screen lets you configure webhook destinations (such as a Slack incoming webhook or your own HTTPS endpoint) and wire them up to one or more zones.

- [Configure Logpush and Logpull for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_logs.htm&type=5)
  Stream eCDN request, security, and Page Shield logs to your own storage or observability platform (Amazon S3, Google Cloud Storage, Azure Blob Storage, Datadog, or Splunk), or download recent logs on demand - all from the Logs tab on the Configure Zone screen in Business Manager.

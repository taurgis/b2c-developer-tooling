# Create a Rate Limiting Rule for an eCDN Zone

_Configure a rate limiting rule to specify rate limits for requests that match a particular expression and then perform an action when requests reach those rate limits. Rate limiting rules improve storefront availability, target specific traffic patterns and combat threats, such as bots._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure, and select **Configure Zone** from the dropdown menu.

   _(image: Configure Zone dropdown menu for a Proxy Zone in Business Manager)_
3. From the Security Rules tab, click **New Rate Limiting Rule**. You can also switch to a different zone from this tab. To switch zones, select another name from the Zone dropdown.

   _(image: New Rate Limiting Rule page in Business Manager Embedded CDN Settings)_
4. Enter a rule name. For example, "Rate limit requests from user_agent_x."

   _(image: New Rate Limiting Rule in Business Manager)_
5. (Optional) If you want the rule to be active when you save it, select **Enable Rule Upon Saving**. If you’re not ready to activate the rule yet, you can create it first. When you’re ready, return to the Security Rules tab and enable your rule from the list.
6. Use the visual dropdown interface to enter the rule expression: select a field, operator, and value. To add conditional logic, use the **And** or **Or** buttons. You can also manually enter the expression by clicking **Edit Expression**.
7. To set the rate limit, specify the number of requests per period.
8. (Optional) To define the request criteria that you want to rate limit, select **Use Custom Counting Expression**. This parameter defines when to increment the rate counter, which tracks the number of requests per period. When the rate counter exceeds the defined requests per period limit, the rule executes its action.

   1. If the counting expression isn’t provided, the counting expression is the same as the rule expression.
   2. The counting expression supports the option to rate limit based on HTTP response code, which isn’t possible using only the rule expression. For more examples of when to use a custom counting expression, see [Rate Limiting Rules FAQ](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-rate-limiting-rules.html#rate-limiting-rules-faq) in the *B2C Commerce API Developer Guide*.
9. Matching Characteristics supports IP and IP with NAT support. The characteristics determine how to group incoming requests. Requests with the same values for the defined characteristics are grouped together and share a rate counter.

   1. For example, say that you use IP as the rule’s characteristics. If the rate of requests coming from a single IP address exceeds the defined limit, then further requests from that IP address are rate limited. Requests that come from other IP addresses do not share the same rate counter. In other words, the request rate of one IP address doesn’t affect the request rate of other IP addresses.
10. Select an action for the rule. For example, Block or Log. For more information, see [Rule Actions](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-custom-rules.html#rule-actions) in the *B2C Commerce API Developer Guide*.
11. To define how the action applies, select either **Action for selected duration** or **Throttle requests over the maximum configured rate**.

   1. Action for selected duration: After you meet the rate limiting criteria, apply the action to further requests matching the rule expression for the period specified by the duration.
   2. Throttle requests over the maximum configured rate: Throttle requests that exceed the configured maximum rate. The chosen action applies to those excess requests, while requests within the limit are still allowed.
12. If your rule uses Action for selected duration, select a duration from the dropdown menu.
13. Save the rule.

After you create the rule, it appears in the list of Rate Limiting Rules on the Security Rules tab. From the list, you can turn the rule on or off (if you selected Enable Rule Upon Saving, your rule is on by default). The Rate Limiting Rules list also shows the number of requests that matched each rule in the past 24 hours. Click this number to view detailed traffic analytics. See [Analyze HTTP and Security Traffic for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_analyze_eCDN_traffic.htm&type=5)

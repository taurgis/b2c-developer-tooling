# Add a Custom Preference Programmatically in B2C Commerce

_Get and set custom preferences programmatically using the Salesforce B2C Commerce APIs and via the Business Manager extension mechanism._

To configure a new custom preference:

1. Define the preference group and definition in the Business Manager user interface.
2. Embed the preference in your custom application using the `GetPreferenceSet` pipelet and access its values from the returned `PreferenceSet` object.
3. Extend the `bm_extensions.xml` file of the *cartridge *directory of the custom cartridge to define a preference editor for the new preferences.
   
   Use the Business Manager extension descriptor to assign the necessary permissions to configure the custom preferences.

### Setting Preference Values

Business Manager extensions reside in a cartridge. The cartridge has a pipeline and the pipeline has two sub pipelines, one for site actions and one for admin actions. The pipelines each have one script node. The script node uses the XML file `bm_extensions.xml` to create the extensions.

> **Note:** You can create a controller to replace the pipeline provided by default in the cartridge, but there is no reason to because you still use the XML file. Business Manager extensions, like jobs, use pipelines.

Use the Business Manager extension mechanism to set the values of the defined preferences for a particular site. Use the `CustomPreferences` pipeline with the `View` start node. To configure the pipeline, pass the following parameters:

- PrefGroupName: (mandatory) ID of the preference group whose values you configure through this preference editor.
- Domain: (optional) name of a domain for which the values are configured. By default, this preference editor configures the preferences of the site where you deploy it.
- instType: (optional) initial instance type selected when this preference editor starts.

### Example

The following is an example snippet of a `bm_extensions.xml` file that deploys a preference editor for the preference group with the `ID CreditCardPreferences` into Business Manager: **Merchant Tools >  *site*  > Site Preferences > Custom Preferences > site preferences**.

```
<menuaction id="credit_card_prefs" menupath="site-prefs" position="500" site="true>
    <name xml:lang="x-default">Credit Card Preferences</name>
    <short_description xml:lang="x-default">
        Credit Card preferences
    </short_description>
    <description xml:lang="x-default">
        Configure the Credit Card preferences
    </description>
    <parameters>
        <parameter name="PrefGroupName" value="CreditCardPreferences"/>
    </parameters>
    <icon>icons/pref_ico.gif</icon>
    <exec pipeline="CustomPreferences" node="View"/>
    <permissions>
        <permission>SLD_MANAGE_SITES</permission>
    </permissions>
</menuaction>
```

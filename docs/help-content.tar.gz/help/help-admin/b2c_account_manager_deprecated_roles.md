# Removal of Deprecated Roles in Account Manager

_Avoid assigning deprecated roles to users in B2C Commerce. These roles no longer provide access to B2C services, and Salesforce plans to remove them starting in Account Manager 3.9 (June 2026). Removing a deprecated role from a user doesn’t result in loss of functionality or access._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Starting in Account Manager 3.9, Account Manager gradually unassigns deprecated roles from all users. The unassignment process is scheduled over several months, after which Account Manager plans to remove the roles entirely.

These roles were previously announced as deprecated in [Account Manager 1.46.0](https://help.salesforce.com/s/articleView?id=commerce.account_manager_rn_deprecated_roles.htm). Starting in Account Manager 3.7, Account Manager labels deprecated roles accordingly on the User Details page. When assigning roles to a user, don’t select those marked DEPRECATED.

- Appdynamics User
- CQuotient Configurator Administrator
   
   - This role isn’t required for access to Einstein. Einstein only requires an Account Manager account to log in. Control permissions within the Configurator app itself.
- Documentation User
- Business Manager Partner
- Order Management Admin
   
   - This role applied to the legacy Commerce Cloud Order Management product, which was retired on July 31, 2022.
- Order Management User
   
   - This role applied to the legacy Commerce Cloud Order Management product, which was retired on July 31, 2022.
- Shopper Login and API Access Service (SLAS) Organization Admin (for API client)
   
   - This role is assignable only to API clients, not to users, and gives no extra access. The active role for users, SLAS Organization Administrator, isn’t deprecated.
- SLAS Trusted Agent Read Only
- SLAS Trusted Agent Read Write
- XChange User
- statuspage.io User

For custom implementations and automation scripts, we encourage removing deprecated role assignments proactively to ensure a smooth transition. However, auditing the usage of deprecated roles isn’t required.

# Product List Object Import/Export in B2C Commerce

_Use the productlist.xsd schema file to import and export product lists. This topic applies to B2C Commerce._

*Granularity:* selected product list

The import/export directory for product lists is customer.

The productlist.xsd supports the following elements:

- Optional *mode* in *product-list* element
- Optional child element *items* in *product-list* element
- Optional child element *list-id* in *product-list *element
- Optional *type* attribute in *registrant* element
- Optional child element *type* in *event* element
- *address-id* attribute in *shipping-address *and *post-event-shipping-address *elements

### Import Product Lists

Some reasons to import product lists are as follows:

- To import data (for example, wish lists) from a legacy platform.
- To feed gift registries created offline (in-store with a scanner) to allow gift purchase by people who don't have convenient access to a store.
- To update registries as customers purchase items on/offline.

Product list import supports the DELETE, UPDATE, REPLACE, and MERGE modes. Product list import skips anonymous product lists (without an owner). The child element *address-id* of the *Address* element is sufficient for import - address values aren’t updated, but an existing address that matches the *address-id* is sufficient to create the assignment to the list.

- The product list has a *list-id* configured:
   
   - The import updates existing product lists in the MERGE and UPDATE modes.
   - The import recreates existing product lists in the REPLACE mode.
   - Existing product lists aren't imported in the REPLACE and MERGE modes with the configured ID.
- The product list doesn't have a *list-id* configured:
   
   - The import creates product lists in the REPLACE and MERGE modes with a random ID.

### Export Product Lists

The product list export includes custom attributes for product list items and the customer email address.

### Business Manager Location

**Customers > Import & Export**

### Pipelets

ImportProductLists

*Granularity:* passed product lists.

# Generic Mapping in B2C Commerce

_Use the generic mapping capability to map keys to values, with the mapping stored in a high-performance data store. Generic mapping supports large datasets, with high performance for lookup. This topic applies to B2C Commerce._

For example, map SKUs from a backend system to B2C Commerce SKUs using B2C Commerce script. This technique makes sure that interaction with the backend system is transparent and doesn't require adding B2C Commerce SKUs to the third-party system.

To use generic mapping, B2C Commerce customers can access in-memory key value pairs that complement product data in the database.

### Steps to Use Generic Mapping

Generally, follow these steps to use Generic Mapping:

1. Create the mapping.
2. Upload the mapping to the B2C Commerce server
3. Create a job that uses the ImportKeyValueMapping job step.
4. Use B2C Commerce script to read values from the mapping.

### Create the Mapping

Create a .csv (comma-separated value) file to store the mapping. Follow these guidelines:

- Put each key and associated value on one line
- Separate keys and values with a comma.
- Make sure that .csv files for import into maps have a fixed number of entries per row.

The format for each line of the .csv file is:

(<key>[,<key2>,…],<value1>[,<value2>,<value3>,...])

The first row of the .csv file defines the property names for the key value entries. The key value entries start in row 2. The generic mapping contains one less entry than the number of rows in the .csv file. When you call MappingMgr.get(mapping, key), you get a new map with the property names as keys.

If the import encounters malformed records, it fails with a logged exception.

Before importing a mapping, upload it to a place accessible by the application server. For example, use a Business Manager upload page or FTP. Import mappings explicitly on each instance. Mappings are global (not site-specific).

Mapping files are limited to 20 MB, which is equivalent to 1M records of 20 bytes and a maximum of 20 mappings.

### Uploading the Mapping

Uploading the mapping makes it accessible.

Upload the .csv file using Business Manager at this location: **Administration > Site Development > Import & Export**

Select your .csv file when uploading. Alternatively, you can upload the .csv file to the Impex directory using WebDAV or httpClient.

### Create a Job

Create a job that uses the ImportKeyValueMapping job step. This job step transforms .csv files into in-memory key-value mapping and notifies all application servers in a cluster that there’s a new mapping. The ImportKeyValueMapping job step supports Replace, Delete, and Merge import modes.

### Read Values from the Mapping

The dw.util.MappingMgr class, with the following methods, enables you to access mapping data.

- get(String mappingName, MappingKey key): gets a collection of string values of a mapping by name and multiple key values
- getFirst(String mappingName, MappingKey key) gets the first element of a collection of string values of a mapping by name and key
- getMappingNames(): gets a collection of string values for a specific mapping and a mapping key
- keyIterator(String mappingName): key iterator over known mapping keys by mapping name

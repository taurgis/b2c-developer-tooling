# Bulk Migration or Creation of Account Manager Users

_An open source tool, Salesforce Commerce Cloud (SFCC)-CI CLI (https://github.com/SalesforceCommerceCloud/sfcc-ci) provides user management bulk actions in B2C Commerce Business Manager and Account Manager._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

The CLI makes it easier to consolidate users from multiple Business Manager instances to one Account Manager instance. While not automated, this CLI alleviates the heavy lifting. See [Command Line Interface](https://github.com/SalesforceCommerceCloud/sfcc-ci).

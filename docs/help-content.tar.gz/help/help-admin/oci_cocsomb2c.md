# Continuous Order Capture for Omnichannel Inventory with Salesforce Order Management

_B2C Commerce Continuous Order Capture holds orders in a Reservation Missing state to prevent incomplete data from reaching Salesforce Order Management. After the Omnichannel Inventory service recovers, the system automatically reconciles the inventory and clears this Reservation Missing state. All orders are then pushed to Salesforce Order Management, even if they’re flagged as oversold due to partial or failed reservations._

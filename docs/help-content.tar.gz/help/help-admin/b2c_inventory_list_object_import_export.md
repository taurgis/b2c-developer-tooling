# Inventory List Object Import and Export in B2C Commerce

_Use the inventory.xsd schema file to import or export inventory lists. This topic applies to B2C Commerce._

For development purposes, the site import process includes inventory lists, enabling you to export a site and then import it on another instance without losing inventory-related information. When you export an Inventory file, it's first sorted in ascending alphabetical order based on productID.

| Object Information | Details |
| --- | --- |
| Schema file | inventory.xsd |
| Business Manager import location | ***site* > Merchant Tools > Products and Catalogs > Import & Export** |
| Granularity | Selected inventory lists. |
| Pipelets | ImportInventoryLists ExportInventoryLists |

B2C Commerce imports or exports Inventory List records and their associated Product Inventory Records using an XML file. The structure of the XML file follows the semantics of the XML `inventory.xsd` schema definition.

The following code example shows a typical import file:

```
<?xml version="1.0" encoding="UTF-8" ?>
<inventory xmlns="http://www.demandware.com/xml/impex/inventory/2007-05-31"> #Specifies the inventory.xsd file that defines the schema.
    <inventory-list>
        <records>
            <record product-id="ProductWithAllocation"> #Sets the stock level at 10 for product "ProductWithAllocation".
                <allocation>10</allocation>
                <perpetual>false</perpetual>
            </record>
            <record product-id="ProductWithBackorderAllocation"> #Sets stock level and backorder allocation to 10 for product "ProductWithBackorderAllocation".
                <allocation>10</allocation>
                <perpetual>false</perpetual>
                <preorder-backorder-handling>backorder</preorder-backorder-handling>
                <preorder-backorder-allocation>10</preorder-backorder-allocation>
            </record>
            <record product-id="ProductWithPerpetualFlag">
                <perpetual>true</perpetual>
            </record>
        </records>
    </inventory-list>
```

Inventory list export contains these attributes:

- allocation
- allocation-timestamp
- perpetual
- preorder-backorder-handling
- preorder-backorder-allocation
- in-stock-date
- in-stock-datetime
- ats (available to sell)
- on-order
- turnover

## Inventory List and Product Inventory Records in B2C Commerce

_The `inventory.xsd` file defines how to structure the XML file that transmits inventory data to B2C Commerce._

The following code block defines the Inventory List record. The inventory.xml file can contain 0 or more inventory lists.

```
<xsd:complexType name="complexType.Header">
<xsd:sequence>
<xsd:element name="default-instock" type="xsd:boolean" minOccurs="1" maxOccurs="1" /> #Always include a value for the default product availability flag.
    <xsd:element name="description" 
        type="simpleType.Generic.String.4000" minOccurs="0" maxOccurs="1" /> #Optional description field of up to 4000 characters.
</xsd:sequence>
<xsd:attribute name="list-id" type="simpleType.Generic.NonEmptyString.256" use="required" /> #Required list ID of up to 256 characters.
   <xsd:attribute name="mode" type="simpleType.ImportMode" use="optional" /> #Optional import mode.
</xsd:complexType>
<xsd:complexType name="complexType.InventoryRecords"> #The list can contain 0 or more inventory records.
    <xsd:sequence>
        <xsd:element name="record" type="complexType.InventoryRecord" 
            minOccurs="0" maxOccurs="unbounded" />
    </xsd:sequence>
</xsd:complexType>
```

The following code block defines the associated Product Inventory Records. The allocation, perpetual, preorder-backorder-handling, preorder-backorder-allocation, in-stock-date, ats (available to sell), on-order, turnover, and custom-attribute fields of an inventory record are optional. However, product IDs are required.

```
    <xsd:complexType name="complexType.InventoryRecord">
        <xsd:sequence>
     <xsd:complexType name="complexType.InventoryRecord"> #Optional fields
        <xsd:sequence>
            <xsd:element name="allocation" type="simpleType.Allocation" minOccurs="0" maxOccurs="1" />
            <xsd:element name="allocation-timestamp" type="xsd:dateTime" minOccurs="0" maxOccurs="1" />
            <xsd:element name="perpetual" type="xsd:boolean" minOccurs="0" maxOccurs="1" />
            <xsd:element name="preorder-backorder-handling" type="simpleType.InventoryRecord.PreorderBackorderHandling" minOccurs="0" maxOccurs="1" />
            <xsd:element name="preorder-backorder-allocation" type="simpleType.Allocation" minOccurs="0" maxOccurs="1" />
            <xsd:element name="in-stock-date" type="xsd:date" minOccurs="0" maxOccurs="1" />
            <xsd:element name="ats" type="simpleType.Allocation" minOccurs="0" maxOccurs="1" />
            <xsd:element name="on-order" type="simpleType.Allocation" minOccurs="0" maxOccurs="1" />
            <xsd:element name="turn-over" type="simpleType.Allocation" minOccurs="0" maxOccurs="1" />
            <xsd:element name="custom-attributes" type="sharedType.CustomAttributes" minOccurs="0" maxOccurs="1" />
        </xsd:sequence>
        <xsd:attribute name="product-id" type="simpleType.Generic.NonEmptyString.100" use="required" /> #Required field
        <xsd:attribute name="mode" type="simpleType.ImportMode" use="optional" />
    </xsd:complexType>
        <xsd:attribute name="product-id" 
                type="simpleType.Generic.NonEmptyString.256" use="required" /> #Required field
    </xsd:complexType>
        <xsd:simpleType name="simpleType.Allocation"> #Allocation contains a decimal value greater than or equal to "0.0".
        <xsd:restriction base="xsd:decimal">
            <xsd:minInclusive value="0.0" />
        </xsd:restriction>
    </xsd:simpleType>
    <xsd:simpleType name="simpleType.ImportMode"> #ImportMode defaults to "delete".
        <xsd:restriction base="xsd:string">
            <xsd:enumeration value="delete" />
        </xsd:restriction>
    </xsd:simpleType>
    <xsd:simpleType name="simpleType.InventoryRecord.PreorderBackorderHandling"> #Preorder backorder handling field must equal "none", "preorder", or "backorder".
        <xsd:restriction base="xsd:string">
            <xsd:enumeration value="none" />
            <xsd:enumeration value="preorder" />
            <xsd:enumeration value="backorder" />
        </xsd:restriction>
    </xsd:simpleType>
    <xsd:simpleType name="simpleType.Generic.String"> #Defines the basis for the next three definitions.
        <xsd:restriction base="xsd:string" />
    </xsd:simpleType>
    <xsd:simpleType name="simpleType.Generic.String.256"> #Optional string with a maximum length of 256 characters.
        <xsd:restriction base="simpleType.Generic.String">
            <xsd:minLength value="0" />
            <xsd:maxLength value="256" />
        </xsd:restriction>
    </xsd:simpleType>
    <xsd:simpleType name="simpleType.Generic.String.4000"> #Optional string with a maximum length of 4000 characters.
        <xsd:restriction base="simpleType.Generic.String">
            <xsd:minLength value="0" />
            <xsd:maxLength value="4000" />
        </xsd:restriction>
    </xsd:simpleType>
    <xsd:simpleType name="simpleType.Generic.NonEmptyString.256"> #Non-empty string with a maximum length of 256 characters.
        <xsd:restriction base="simpleType.Generic.String">
            <xsd:minLength value="1" />
            <xsd:maxLength value="256" />
            <xsd:pattern value="\S(.*\S)*" />
        </xsd:restriction>
    </xsd:simpleType>
</xsd:schema>
```

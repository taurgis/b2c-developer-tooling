# Add Stacked Proxy to the Firewall Allowlist

_Use the CDN Zones API custom rules to selectively skip the web application firewall (WAF), other custom rules, rate limits, or security levels for third-party IP addresses that you specify._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Important:** This method isn't recommended as it bypasses all DDoS and WAF components. To selectively skip WAF, other custom rules, or rate limits for specific third-party addresses, use [eCDN Custom Rules](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-custom-rules.html).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select**Administrator > Site > Embedded CDN Settings**.
2. For your zone, click **Settings**.
3. On the Firewall tab, add or edit the trusted IP allowlist to include the third-party proxy IP address.

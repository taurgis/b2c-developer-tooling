# Set Up Anomaly Detectors in Log Center

_Identify unusual log patterns and optionally send alerts when anomalies meet your alert threshold. Log Center continuously analyzes incoming log data and compares the data with learned baseline behavior. When data deviates from the baseline and meets your thresholds, Log Center flags the anomaly. This topic applies to B2C Commerce._

1. In Business Manager, open [Log Center](https://logcenter-us.visibility.commercecloud.salesforce.com/logcenter/dashboard).
2. On the Anomaly Detection tab (1), click **Anomaly Detector Configurations**.

   _(image: Anomaly Detection page in Log Center)_
3. Configure the anomaly detecter.

   1. Click the **Anomaly Detector Configurations** plus icon.
   
      _(image: New anomaly detection configuration)_
   2. Enter a name and description.
   3. Select the realm where the detector runs.
   4. To specify how often Log Center checks for anomalies, set the detection time interval.
   
      
   5. To control how easily the detector flags anomalies, set the detection sensitivity scale. For strong detection with fewer unnecessary alerts, start with a value from 5 through 8. Lower values detect only larger deviations. Higher values can detect subtler patterns, but can require more tuning.
4. To start detection, select **Enable real-time anomaly detection**. To stop the detector, deselect this option.
5. (Optional) To receive anomaly notifications, select **Enable Alerting** and then set the threshold, interval, and email address. When an anomaly meets the criteria, Log Center sends an email notification to the recipients.
6. (Optional) To focus detection on relevant logs, configure filters. Save your changes.

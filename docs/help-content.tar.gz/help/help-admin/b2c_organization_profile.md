# Define Your Organization Profile

_Before adding users to B2C Commerce, define your organization and all its storefronts at the highest level, including setting the default language for all storefronts._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Organization Profile**.
2. Define general information.

   You can't edit the ID because it's the basis for B2C Commerce and your pre-configured store URL. It's the unique key that identifies the account, and the information you use to log in to Business Manager to administer your site.
   
   The product list views and all other catalog information show in the default language you select here, unless you select another language from the dropdown menu.
3. Click **Apply**.

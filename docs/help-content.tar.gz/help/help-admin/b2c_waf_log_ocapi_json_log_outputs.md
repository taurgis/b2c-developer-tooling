# JSON Log Output

_All Open Commerce API (OCAPI) calls return all fields shown in the JavaScript Object Notation (JSON) log output._

| Log Output |
| --- |
| {"CacheStatus":["unknown", "hit", "miss”,"dynamic"] "ClientCountry":"us", "ClientDeviceType":"mobile", "ClientIP":"1.1.1.1" "Client IP class:'badHost', "ClientRequestHost":"www.customer.com", "ClientRequestMethod":"GET", "ClientRequestURI":"/dw/image/v2/xxxx_PRD/on/demandware.st atic/-/template/default/uniqueid/productimages/aaaaaa.jpg?sw=470", "ClientRequestUserAgent":"Mozilla/5.0 (Linux; Android 7.1.1; XT1650 Build/NCLS26.118-23-13-6-5) AppleWebKit/537.36 (KHTML, like Gecko Chrome/66.0.3359.158 Mobile Safari/537.36", "EdgeResponseStatus":xxx, "EdgeStartTimestamp":1528631882657999872, "FirewallMatchesActions":["simulate", “challenge”, "drop"], "FirewallMatchesSources":["firewallRules", “waf”, “rateLimit”], "FirewallMatchesRuleIDs":["4861c39f2cf84aa985d5d813576d08b8"], "RayID":"xxxxxxxxxx", |

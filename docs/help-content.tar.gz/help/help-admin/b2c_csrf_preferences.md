# cross-site request forgery (CSRF) Preferences for B2C Commerce

_To protect pages from CSRF attacks, Business Manager injects tokens into requests and logs failed validations. Use the log entries to troubleshoot failed requests._

## Related Content

- [cross-site request forgery (CSRF) Protection in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_csrf_protection_in_business_manager.htm&type=5)
  A CSRF attack is a technique used by malicious attackers to force a victim to make a protected request to Business Manager ― a request that can severely disrupt your eCommerce business. This topic applies to B2C Commerce.

- [Create cross-site request forgery (CSRF) Allowlists for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_csfr_allowlist_settings.htm&type=5)
  Configure how your site handles CSRF allowlists.

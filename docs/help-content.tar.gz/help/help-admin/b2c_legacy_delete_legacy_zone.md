# Delete the Legacy Zone

_After you move all subdomains to the proxy zone, delete the legacy zone using the remove zone option._

|  |
| --- |
| Available in: **B2C Commerce** |

There are two validation options.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. On the Crypto tab, select the legacy zone and click **Remove Zone**.

   Perform the migration on each instance (Dev/Stg/Prod) and then **delete the Legacy zone from the Production instance after it has been successfully migrated on all instances**.

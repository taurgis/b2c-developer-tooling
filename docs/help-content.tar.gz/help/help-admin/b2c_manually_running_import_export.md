# Manually Run Import/Export in B2C Commerce

_Manually run import and export processes. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Import a feed.

   1. Create a file for import with the format defined in the B2C Commerce schema file for the type of object you want to import.
   2. Select the Import/Export page for the type of object you want to import. See the [Import/Export Object Cheatsheet](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_object_cheatsheet.htm&type=5) for the specific path in Business Manager to use.
   3. In the Import and Export Files section, click **Upload**. Upload files into the cartridge in the correct location before you can import them. The Upload Import Files page appears.
   4. In the Upload Files field, click **Browse** to navigate to the file and click **Upload**. If the file uploads successfully, it appears in the Manage Import Files section of the page.
   5. Navigate back to the original Business Manager path and for the object you want to import, click **Import**.
   6. In the [Object] Import- Select File section, click the button for the file to import and click **Next**. Business Manager validates the file and shows an analysis of the file. Check the analysis to confirm that Business Manager recognized the expected information before continuing the import.
   7. Click **Next **to continue the import. The Catalog Import -Start Import page appears.
   8. In the Import Mode section, select the import mode.
2. Export a feed.

   1. Select the Import/Export page for the type of object you want to export. See the [Import/Export Object Cheatsheet](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_object_cheatsheet.htm&type=5) for the specific path in Business Manager to use.
   2. In the section for the object you want to export, click **Export**, select the object to export, and click **Next**.
   3. Continue through the export wizard. Specify a name for the export file and click **Finish**.
   4. Return to the Import and Export Files section and click **Download**.
   5. Click the file name of the file and select the **Save** option to save the file to your file system.

# Administration Data Replication in B2C Commerce

_These tables map Business Manager Administration modules to data replication tasks. This topic applies to B2C Commerce._

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Organization Profile | N/A | N/A |
| Users | N/A | N/A |
| Roles & Permissions | N/A | N/A |
| WebDAV Client Permissions | WebDAV Client Permissions | Global |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Manage Sites | Sites | Global |
| Customer Lists | Customer Lists | Global |
| Content Libraries | Content Library (site-specific) Libraries (shared) | Content Library: Site Libraries: Global |
| Batch Processes | N/A | N/A |
| Embedded CDN Settings |  |  |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Development Setup | N/A | N/A |
| Code Deployment | N/A (see [Code Replication](https://help.salesforce.com/s/articleView?id=cc.b2c_code_replication.htm&type=5)) | N/A |
| System Object Types | N/A | N/A |
| Custom Object Types | Custom Object Types | Global |
| Custom Error Pages | N/A | N/A |
| Custom Maintenance Pages | N/A | N/A |
| Deprecated API Usage | N/A | N/A |
| Import & Export | N/A | N/A |
| Site Import & Export | N/A | N/A |
| Open Commerce API Settings | OCAPI Settings | Global |
| Customer Service Center Settings | CSC Settings | Global |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Locales | Preferences | Global |
| Instance Time Zone | Preferences | Global |
| Change History |  |  |
| OAuth2 Providers | OAuth Providers | Global |
| SecurityConfigure the global security preference Enforce HTTPS separately for each instance. The Preferences replication task does not replicate this setting. | Preferences | Global |
| Store Locator Data | Geolocations | Global |
| Page Meta Tags | Preferences | Global |
| Feature Switches |  |  |
| Order Search | Preferences | Site |
| Sequence Numbers | Preferences | Global |
| Products |  |  |
| Retention Settings |  |  |
| Import & Export | N/A | N/A |
| Global Timeouts |  |  |
| Custom Preferences | Preferences | Global |
| B2C Commerce Einstein Data Privacy Agreement | N/A | N/A |
| Analytics | N/A | N/A |

| Business Manager Module | Replication Task | Scope |
| --- | --- | --- |
| Job Schedules | N/A | N/A |
| Job History | N/A | N/A |
| Job Schedules (deprecated) | N/A | N/A |
| Job History (deprecated) | N/A | N/A |
| Job Statistics | N/A | N/A |
| Import & Export | N/A | N/A |
| GMV Reports | N/A | N/A |
| Custom Log Settings | N/A | N/A |
| Code Profiler | N/A | N/A |
| Pipeline Profiler | N/A | N/A |
| Quota Status | N/A | N/A |
| Change History | N/A | N/A |
| Encryption Keys | N/A | N/A |
| Private Keys and Certificates | N/A | N/A |
| Services |  |  |
| Service Status | N/A | N/A |
| IP Address Geolocation Data | N/A | N/A |
| Predictive Intelligence |  |  |

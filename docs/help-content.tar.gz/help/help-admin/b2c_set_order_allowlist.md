# Set the Order Allowlist

_To improve the security and manageability of order access within your storefront, Salesforce recommends enabling the AllowList feature within the Limit Storefront Order Access setting. This feature is useful if you haven’t yet implemented any restrictions on Storefront Order Access. After activating this feature, specify which controllers are permitted to access order information and execute order-related functions._

> **Note:** Starting with the B2C Commerce 24.8 release, B2C Commerce blocks the allowlist fully implemented controllers not listed on the allow list from storefront order access.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > Ordering > Orders > Order Preferences > Order Action Settings**.
2. From the Limit Storefront Order Access dropdown, select **Allow List**.
3. In the text field, enter the storefront controllers that you want to have access. List each controller separated by a comma. Only the controllers specified in this allow list can access customer orders.
4. Click **Apply**.

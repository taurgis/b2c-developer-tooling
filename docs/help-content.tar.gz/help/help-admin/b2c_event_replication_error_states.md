# Replication Error States

_Failed process-level replication events (`sf.cc.replication.failed`) include an `errorState` field with a machine-readable code that identifies the failure. Use this page to look up what an error state means._

### Notes

- These values are machine-readable codes, not localized text. Use them as-is when building automation logic in your connector.
- Granular replication events use a separate `failureStatus` field instead of `errorState`. See [Granular Replication Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_granular.htm&type=5).

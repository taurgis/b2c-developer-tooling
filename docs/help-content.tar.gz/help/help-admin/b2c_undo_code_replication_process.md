# Undo a Code Replication Process in B2C Commerce

_When you undo a code replication, the target instance reverts to the previously active code version. Only run an undo process after a code replication process of type Activation or Transfer & Activation._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Replication > Code Replication**. A list of existing code replication processes appears.
2. To undo a replication process without entering a description or configuring an email notification, click **Undo** next to that process. If you want to add a description or send an email notification, continue following these steps.

   Only undo the most recent Code Activation or Code Transfer & Activation process for the target instance.
3. The system generates a process ID. Enter a different ID.
4. From the dropdown list, select a target instance.
5. (Optional) Enter a description.
6. From the Activation Type dropdown list, select **Manual**.
7. From the dropdown list, select a notification email trigger. Enter multiple target email addresses separated by commas.

   | Option | Description |
   | --- | --- |
   | -None- | No emails are sent. |
   | When Process Ends | Sends an email to the specified addresses when the process ends, whether it succeeds or fails. If it hangs, then no email is sent. |
   | When Process Fails | Sends an email to the specified addresses when the process fails. If the process succeeds or hangs, then no email is sent. |
   | Periodically | Enter a time period in minutes. While the process is running, emails are sent to the specified addresses at that interval until the process finishes. An email is also sent when the process succeeds or fails. |
   
   The email notifications contain the start and end time of the process, the target system, the replication type, and the included replication tasks. If there was a failure, an error code is also included. Each process in a recurring series sends its own notification.
8. Click **Next**.
9. From the dropdown list, select the **Undo** replication type.
10. Click **Next** and review the process details.
11. Click **Create**.
12. Find the process in the list and click **Start**.

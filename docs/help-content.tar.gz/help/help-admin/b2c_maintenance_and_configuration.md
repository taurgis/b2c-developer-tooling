# eCDN Maintenance

_Use either Business Manager or the CDN zones API to manage the zones created to support eCDN on your development, staging, and production instance._

## Related Content

- [Renew a Certificate for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_rotate_a_certificate.htm&type=5)
  Development, staging, and production zone certificates require renewal when you use self-managed SSL certificates.

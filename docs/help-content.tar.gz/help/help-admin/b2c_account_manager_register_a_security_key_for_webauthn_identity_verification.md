# Register a Security Key for WebAuthn Identity Verification in B2C Commerce

_Register a Fast Identity Online (FIDO) U2F or WebAuthn (FIDO2) compatible security key as a verification method for multi-factor authentication (MFA) logins. To verify your identity, insert your security key into the appropriate port on your computer or mobile device to complete verification. You can register the same security key with multiple service providers and multiple Salesforce orgs and accounts. You can also register one key per account._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Have your security key in hand so you’re ready to insert it when prompted. If you wait too long, your registration attempt can time out.

1. How you proceed depends on the MFA verification method settings of your organization:

   - Connecting a security key is required at your next login and is the only type of verification method allowed: proceed to the next step.
   - Connecting a security key or another verification method is required at your next login: click **Security Key** and proceed to the next step.
   - If you are logged into Account Manager, and if registering multiple MFA verification methods is an option, connect a security key in your Account Information. Click **Add** next to **Multi-Factor Verification** and choose **Security Key** and proceed to the next step.
2. At the prompt, insert your security key into the appropriate port on your computer or mobile device. If it has a button, touch the button.

   Security keys aren’t a biometric device, even though some have a button that requires your touch to activate the device.
3. Click **Continue** to dismiss the confirmation message.

   Now you’re ready to use this identity verification method. Your security key generates the required credentials, and the browser passes them on to Salesforce to complete the verification. To help keep your account secure, we send you an email notification whenever a new identity verification method is added to your Account Manager account.

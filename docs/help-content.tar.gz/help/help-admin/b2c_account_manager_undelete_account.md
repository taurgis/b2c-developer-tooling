# Undelete an Account in B2C Commerce

_When an account is deleted, the deleted user can no longer log into any systems requiring Account Manager credentials. If you delete an account by mistake or as a security precaution, you can undelete the account. Only account administrators can undelete an account._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **User**.

   The Users page opens, showing a list of accounts.
3. In the **Filter by status** list, select **Deleted Users only**.
4. Click **Undelete** next to the user whose account you want to undelete.

   A message asks you to confirm that you want to undelete the user's account. If you click **Cancel**, the undelete operation is canceled, and the user's account remains deleted.
5. Click **OK**.

   Account Manager restores the account. If the deleted account was linked to Salesforce Identity (SSO), Account Manager cancels the link to Salesforce Identity. To link the account, the user is required to register a verification method for multi-factor authentication (MFA) with Account Manager. This action is a one time requirement for the account.

# Connect to OpenAI

_Configure the SFTP connection between B2C Commerce and OpenAI to allow product feed uploads._

Before you begin, ensure that:

- The **Enable OpenAI Feed Generation (CFT)** and **Enable OpenAI Feed SFTP Upload** feature switches are turned on.
- You have Secure File Transfer Protocol (SFTP) credentials for OpenAI. Salesforce securely provides these credentials to you.

The SFTP connection allows B2C Commerce to securely upload your product feed to OpenAI's infrastructure. Once connected, the system stores the credentials securely in the B2C Commerce keystore, and you can reuse them across multiple sites in your realm.

> **Note:** Although you can reuse the same credentials across multiple sites, we recommend using different SFTP credentials for each unique site that you configure this integration with, so that feed uploads for different sites don't interfere with each other.

You enter SFTP credentials in the **SFTP Configuration** section of the **General Settings** tab. For the rest of the General Settings configuration, see [b2c_openai_feed_general_settings.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_general_settings.htm&type=5).

> **Restriction:** SFTP credentials can be entered only on production instances, and the daily feed sync runs only on production. You can configure Business Details, field mappings, product filter rules, and the feed preview on any non-production instance—development, staging, or sandbox.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations > OpenAI**.

   The OpenAI configuration page opens.
2. On the **General Settings** tab, in the **SFTP Configuration** section, enter your SFTP credentials:

   1. For **SFTP Username**, enter your OpenAI SFTP username.
   2. For **SFTP Password**, enter your OpenAI SFTP password.
3. Click **Connect**.

   Business Manager validates the credentials by attempting to connect to the SFTP server. If the credentials are invalid, the system displays an error message and you can correct them before proceeding. If successful, the status changes to **Connected** and the system stores the credentials securely. The SFTP Username and SFTP Password fields are disabled to prevent accidental modifications.

Your B2C Commerce site is now connected to OpenAI. The system stores the credentials with the ID `openai-sftp-{systemDomain}`, and other sites in your realm can reuse them.

To change your SFTP credentials after connecting, you must first disconnect and then reconnect with the new credentials.

- Turn on the daily feed sync to start uploading your product feed.
- Configure field mappings to customize how the system sends your product data to OpenAI.

**Disconnect from OpenAI:** To disconnect from the OpenAI integration, on the **General Settings** tab, in the **SFTP Configuration** section, click **Disconnect**. When you disconnect:

- The system removes the OpenAI channel configuration.
- The system deletes the stored SFTP credentials from the keystore.
- The **Enable Daily Feed Sync** toggle is automatically turned off.
- Your field mapping data is preserved and is available when you reconnect.

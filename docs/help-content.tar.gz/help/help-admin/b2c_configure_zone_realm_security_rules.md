# Realm Security Rules for eCDN Zones

_Realm Security Rules let you define Managed IP Address Lists and Custom Firewall Rules that control how trusted IP traffic is handled across your eCDN zones. These rules replace the legacy Trusted IP configuration._

### Overview

> **Note:** The Realm Security Rules tab is available only when the **Enable eCDN Trusted IP Migration** feature switch is enabled for your organization. If the tab is not visible in Business Manager, contact your Salesforce account team.

Realm Security Rules provide two components that work together to manage trusted IP traffic:

**Managed IP Address Lists**
: Named lists of IP addresses or CIDR ranges. You can scope a list to your entire realm (account level) or to a single zone (zone level). See [Create and Manage Trusted IP Address Lists](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_trusted_ip_address_lists.htm&type=5).

**Custom Firewall Rules**
: Rules that reference your IP address lists and define a skip action, so traffic from trusted IPs bypasses selected security checks. See [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5).

> **Important:** Realm Security Rules replace the legacy Trusted IP list groups that were previously configured via the Firewall tab in the zone settings slider. If you had existing Trusted IP configurations, Salesforce migrates them automatically. See [About the Trusted IP Migration to web application firewall (WAF) Custom Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_trusted_ips_to_custom_rules.htm&type=5) for details.

### Accessing Realm Security Rules

To open the Realm Security Rules tab:

1. In Business Manager, click the App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure and select **Configure Zone** from the dropdown menu.
   
   _(image: Embedded CDN Settings page showing the Configure Zone option in the zone actions dropdown menu)_
3. Select the **Security Rules** tab.
4. Select the **Realm Security Rules** sub-tab.

### Realm Security Rules tab — account level

_(image: Realm Security Rules tab at the account level showing migrated Custom Firewall Rules and Managed IP Address Lists)_

### Custom Firewall Rule — skip action detail

_(image: Edit Custom Rule dialog showing IP address list conditions and Skip actions configured for a migrated Trusted IP allowlist rule)_

### Account-Level vs. Zone-Level Scope

Managed IP Address Lists and their associated Custom Firewall Rules can be scoped at two levels:

> **Note:** Account-level changes affect all eligible zones across development, staging, and production. A warning banner is displayed when you make account-level changes on a Production instance. On non-production instances, the Realm Security Rules tab is read-only. Use the Production instance to create or modify account-level rules and lists.

### Realm Security Rules tab — zone level

_(image: Realm Security Rules tab at the zone level showing Custom Firewall Rules and Managed IP Address Lists scoped to a single zone)_

### Zone Security Rules tab

_(image: Zone Security Rules tab showing zone-level Custom Firewall Rules, Rate Limiting Rules, and WAF-v2 eCDN Managed Ruleset settings for a specific eCDN zone)_

### Behavior: What Traffic Is Bypassed

When traffic originates from an IP address in a trusted list and matches a skip rule, the following security checks are bypassed:

- Custom firewall rules
- WAF managed rules
- Rate limiting rules

In addition, DDoS Layer 7 protections are automatically adjusted for accounts that have account-level trusted IP lists configured. This prevents false-positive challenges on legitimate high-volume traffic from trusted sources. No additional configuration is required for DDoS adjustments. For details on the specific managed rules that are overridden, see [DDoS Layer 7 Override Details](b2c_migrate_trusted_ips_to_custom_rules.xml#b2c_migrate_trusted_ips_to_custom_rules/ddos-l7-overrides).

> **Tip:** Skip rules are evaluated before any blocking or rate-limiting rules and are automatically positioned at the top of the ruleset. If both an allowlist skip rule and a blocklist rule exist for a zone, the allowlist skip rule is positioned first. You do not need to manage rule ordering manually.

### Permissions

On non-production instances (staging, development, sandbox), the Realm Security Rules tab is read-only. A blue information banner indicates: *"Realm-level configuration is read-only on this instance. Use the Production instance to make changes."*

On Production, an amber warning banner indicates: *"Account-level changes affect all zones (development, staging, and production)."*

## Related Content

- [Create and Manage Trusted IP Address Lists](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_trusted_ip_address_lists.htm&type=5)
  Create named lists of trusted IP addresses or CIDR ranges to use with Custom Firewall Rules that bypass security checks for trusted traffic.

- [About the Trusted IP Migration to web application firewall (WAF) Custom Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_trusted_ips_to_custom_rules.htm&type=5)
  Learn how Salesforce automatically migrates your legacy Trusted IP configurations to WAF Custom Rules and Managed IP Address Lists, and how to verify your migrated configuration.

# Identify Templates, Controllers, and Pipelines with the Page Information Tool

_To identify the templates, controllers, and pipelines that create page components, use the Page Information Tool. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Select the site to view and click **Toolkit.**

   A new tab opens showing the storefront, with the Storefront Toolkit icons in the upper right corner.
2. Click the Page Information Tool icon. _(image: Page Information Tool icon)_
3. Navigate to the page that you want to inspect and move your mouse over the page.
4. To edit the templates and controllers, click the links in the popups.

   The availability of this functionality depends on which IDE and plug-ins you use.

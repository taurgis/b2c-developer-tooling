# Configure Page Meta Tags in B2C Commerce

_Create page meta tags, which can be used within catalogs and libraries to create rule base page meta tag content._

|  |
| --- |
| Available in: **B2C Commerce** |

You can create [page meta tags](https://help.salesforce.com/s/articleView?id=cc.b2c_page_meta_tags.htm&type=5), which can be used within catalogs and libraries to create rule base page meta tag content.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > SEO& Discoverability > Page Meta Tag Rules**.
2. To define a new meta tag, click **Add**.
3. In the Create Page Meta Tag dialog:

   1. Enter the Meta Tag ID.
   
      Create a maximum of 50 definitions.
      
      The ID begins with a letter, followed by any of the following characters: letters, digits, hyphens, underscores, colons, and periods. The maximum length is 100 characters.
   2. Select the Meta Tag Type: *Name*, *Property*, or *Title*.
   
      The *title* type can only be used with the *title* ID.
   3. Click **Add**.
   
      The Page Meta Tags page opens with the new meta tags in the list.
4. Now [create your rules](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_page_meta_tag_rules.htm&type=5).

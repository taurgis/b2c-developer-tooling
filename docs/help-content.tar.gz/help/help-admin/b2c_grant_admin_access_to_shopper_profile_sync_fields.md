# Grant Admin Access to Shopper Profile Sync Fields

_Shopper Profile Sync writes to several system-controlled fields on person account and contact records. These fields are not editable by administrators under normal conditions. To support migration, a temporary permission is available that allows an admin to modify them._

Grant this access only for the duration of the migration, then remove it so the fields return to their protected, system-only state.

1. Log in to your [connected Salesforce org](https://help.salesforce.com/s/articleView?id=cc.b2c_connected_comm_salesforce_connection.htm).
2. In Setup, go to **Profiles > your user profile > System Settings**.
3. Select **Change access to Shopper Profile Sync fields**.
4. Save the profile.

**What This Permission Grants**

Temporary create and edit access to the following fields on person accounts and contacts:

- CommerceCustomerReference: the Customer ID from B2C Commerce.
- CommerceGroupReference: the Customer List ID from B2C Commerce.
- CommerceOrganizationIdentifier: the realm and instance of the B2C Commerce organization the shopper originated from.

**After Migration**

Remove this permission once the migration is complete. These fields are intended to function as system-managed identifiers, and leaving the access enabled risks unintended modifications that can break the link between Salesforce records and their corresponding B2C Commerce shoppers.

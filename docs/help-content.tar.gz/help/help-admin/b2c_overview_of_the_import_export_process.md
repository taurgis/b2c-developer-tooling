# Overview of the Import/Export Process in B2C Commerce

_Follow a set of basic steps to complete import and export. This topic applies to B2C Commerce._

The basic steps for import are:

First, create an XML file that conforms to the B2C Commerce schema for that type of system object. See the [Import/Export Object Cheatsheet](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_object_cheatsheet.htm&type=5) for a list of all B2C Commerce objects and the schema files used to import them.

Second, transfer the XML file from the merchant backend system to a B2C Commerce instance. For Staging or Production instances, you must also set up a secure connection for the file transfer. Sandboxes don't require a secure connection.

Third, import the XML file into the instance database. Do this import manually through Business Manager or create a custom pipeline. B2C Commerce provides import pipelets for most standard imports. Salesforce recommends using standard import pipelets whenever business objects load into B2C Commerce as opposed to implementing custom logic with script or pipelets. The standard import pipelets can deal with large datasets, are fast and reliable, and use system resources efficiently.

The basic steps for export are:

First, export the database objects to an XML file. The export file uses the same schema definition that is used to import the database objects. Do this export manually through Business Manager or create a custom pipeline. To automate data exports, create a pipeline. B2C Commerce provides export pipelets that can be used for most exports. Sometimes, the export pipelets allow more granularity in the objects you choose to export than Business Manager allows.

Second, transfer files from the instance to the merchant backend system. Use a secure connection if necessary. For example, a PCI-Data Security Standard (DSS) requirement can require a secure connection. Another backend system can also require a secure connection.

For recurring import/export processes, configure batch jobs for both file transfer and import/export. You can also use pipelets for programmatic control of the import/export process.

## Import/Export for Sandboxes

_During site development, each developer uses a separate sandbox. Create an initial sandbox as a template for other sandboxes, so that the work of configuring the site is only done one time. Import isn't used for code upload into sandboxes._

You transfer data files from your local machine to the instance before importing them into the instance database. Files can't be imported unless the files are stored on the instance you want to import them into. Use WebDAV or FTP to push files for import to the cartridge manually. Use a custom pipeline with B2C Commerce scripts to pull files automatically into the instance.

When you’ve moved the import files to your instance, use Business Manager to import the files into the instance database. When you’re confident that your first sandbox has the configuration and data you want your development team to use, you can use Site Export to export the contents and configuration of the site and download them to your developer machine.

> **Note:** There are various objects that can only be imported using Site Import/Export. Make sure that these objects exist before performing Site Import/Export. Don’t export the users or permission settings of the site. You don’t want to override the user and password information for sandboxes you’re importing into.

Any other sandbox can then use Site Import to get the configuration and contents of the exported site. Use this process to create initial sandboxes and whenever you need a new sandbox so that you can branch your code.

During development, new product and price feeds can be imported directly into each sandbox using the Import/Export feature. Each sandbox uses the same import files, but must independently use the Import feature to import files. You can also create custom pipelines to automate the import of data. This step is done to support automatic import of data for staging and production systems.

## Import/Export for Staging and Production

_Normally a custom pipeline is used to move data via a secure connection from a backend system to an instance in the primary instance group._

Infrequent feeds are imported only into the Staging instance and then replicated to the Production instance. Use this approach to protect your Production instance from any problems with the imported data. To manually add Web-only descriptions or other information, some feeds require enhancement in Business Manager. Feeds requiring enhancement are enhanced in the Staging instance and then the data is replicated to Production.

It isn't practical to stage and replicate data that changes frequently. Frequent changes are imported directly into the Production instance using feeds. Frequent feeds are imported into Staging and Production at the same time, so that the instances stay synchronized.

You can also export files from B2C Commerce for your backend systems. Export feeds that are defined by the same B2C Commerce schema files as the import feeds or create custom feeds through a custom pipeline.

During development, start out manually importing files via Business Manager. Eventually, however, it makes sense to automate import and export of files using custom import pipelines. For a Production instance, which can have frequent pricing or inventory changes (every 10 minutes for example), automation is often essential. Automate import and export feeds using custom pipelines and scheduled jobs.

Add business logic to a custom pipeline to let you add values to your import file, update search indexes automatically, or archive the import file.

Export data from your Production instance to third party or backend systems. Add business logic to your custom pipeline to let you change the format of your export file, add values, or do other processing on the file.

## Import/Export for Development Instances

_Development instances typically don't use import or export since they’re testing environments for Production instances. Initially, do a Site import/export from the Staging instance to the Development instance. After the initial import/export, use data replication to update data and code in the Development instance._

To do the initial Site import, use a custom job with the ImportSiteArchive job step. You can’t initiate a Site import from a Business Manager module.

# Order Preference Import and Export

_Import and export some order preferences. This topic applies to B2C Commerce._

Import and export the following site preferences:

- Order Export Settings
   
   - OrderEditExportDelay
   - OrderExportDelay
   - OrderExportFormat
- Order Storage Settings
   
   - OrderIPLoggingEnabled
- Order Data Settings
   
   - OrderLifetime — Order Retention
   - FailedOrderRetention
   - RetainNonExportedOrders
- Failed Orders Setting
   
   - FailNonPlacedOrdersAfter — Auto-Fail Orders
- Order Creation Settings
   
   - GenerateCustomerNumberEnabled — Generate Customer Number for Guest Orders
- Order Access Settings
   
   - StorefrontOrderAccess - Limit Storefront Order Access

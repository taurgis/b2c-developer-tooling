# Configure Access Settings for B2C Commerce

_Limit access based on IP addresses. If you don't provide an allowlist or blocklist, the feature isn't active and these settings have no effect. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

Business Manager IP allowlists and blocklists serve to lock out attackers who have, though illegitimate means, obtained valid credentials. For example, a former employee who obtained credentials when employed, or non-employees who obtained them via social engineering. These lists aren't intended to prevent brute force attacks.

If you log into Business Manager, and you aren't using Unified Authentication, these lists apply *before* Business Manager verifies your credentials.

If you log in using WebDAV or the agent user login process, and you aren't using Unified Authentication, the lists apply *after* Business Manager verifies your credentials.

If you log in using Unified Authentication, regardless of how you log in, these lists apply *after* Business Manager verifies your credentials.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security**.
2. On the Access Restriction tab, enter a range of allowlisted IP addresses allowed to access Business Manager.
3. Enter a range of blocklisted IP addresses not allowed to access Business Manager.

   If an IP address is both blocklisted and allowlisted, it's denied access.
4. Select whether you want invalid login attempts recorded to the error log.
5. To have an email sent when an invalid login attempt occurs, enter one or more email addresses, separated by a semicolon.

   If you don't provide an email address, no email is sent.
6. Select whether you want to block login access to non-specifically allowlisted IP addresses.

   If this option isn’t selected, non-specifically allowlisted IP addresses can access Business Manager.
7. Select whether you want invalid login attempts to count toward the Failed Login Count.

   Choosing this option can lock a user out.
8. Click **Apply**.

# Get a Slack Token for B2C Commerce

_To connect Slack to Business Manager, a Slack administrator acquires a Slack bot token, also known as a Bot User OAuth Token, for your workspace. A Slack admin completes these steps before connecting the workspace to Business Manager._

|  |
| --- |
| Available in: **B2C Commerce** |

Complete these steps before [connecting a Slack workspace to Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_connect_slack_to_business_manager.htm&type=5).

1. In Slack, open the workspace menu.
2. Click **More** and select **Automations**.
3. Click **App Directory**.
4. In the new browser window, click **Manage**.
5. Click **Build**.
6. Select an existing app or click **Create an App**.
7. In the Create an app pop-up, select **From an app manifest**.
8. Select your workspace and click **Next**.
9. Click the YAML tab.
10. Use this file, replacing the name, description, background_color, display_name, and always_online fields.

   ```
   _metadata:
     major_version: 1
     minor_version: 1
   display_information:
     name: your_new_bot
     description: SFCC ECommerce Bot
     background_color: "#2d9c0b"
   features:
     bot_user:
       display_name: ECommerce Bot
       always_online: false
   oauth_config:
     scopes:
       bot:
         - groups:read
         - channels:read
         - chat:write
         - chat:write.public
         - team:read
   ```
   
   Display_name is the name that your Bot uses to send messages under.
11. Click **Create**.
12. Select **Install to Workspace**.
13. In the app homepage under Features, select **OAuth & Permissions** and click **Allow**,
14. The OAuth & Permissions page now lists your token. Use this token when connecting your Slack workspace to your commerce organization.

# Manage Access of Partner Accounts in B2C Commerce

_Account administrators can use Account Manager to manage access of user accounts invited to the administrator's organization (for example, a partner account). You can control which B2C Commerce applications the invited account can access._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **User**.

   The Users page opens, showing a list of accounts.
3. In the **Invited Users** field, click the email address or subaddress of the account whose access you want to manage. If an account has the Account Admin role, but you don’t want the account to have Account Admin access in your organization, create a new account based on a subaddress. Then, assign a more limited role to that account. See [b2c_account_manager_invite_user_to_organization.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_invite_user_to_organization.htm&type=5).

   In the **Organizations** section, you can revoke the account's access to your organization, click the trash bin icon. In the **Roles** section, you can manage the account's access to the sandbox or PIG instances of your organization.
4. In the **Roles** section, click **Add** to open the **Assign Roles** window.
5. In the **Assign Roles** window, search for roles, and select each role to which you want the account to access.
6. Click **Add**.
7. Specify a role scope for all roles requiring access to an instance.

   1. Select the filter icon.
   2. In the **Add Instance Filters** tab, select an organization.
   3. Enter the names for the instances you want the user to have access to.
   4. Select the instances.
   5. Click **Add**.

# Troubleshoot Log Center Alerts

_If you’re missing Log Center notifications in B2C Commerce, check these likely causes and fixes._

| Problem | Likely Causes | Fix |
| --- | --- | --- |
| Alert notifications are missing. | The alert status is set to Inactive, the threshold is configured too high, or no matching log data exists. | Verify that the alert status badge is Active. To check for data availability over the past 60 minutes, click **Preview**. Lower the threshold or adjust filters if data is missing._(image: Log Preview)_ |
| Slack alerts fail to deliver. | The Slack incoming webhook URL is invalid, or the target Slack channel has been archived. | Verify that the target Slack channel exists and is active. Test the webhook configuration URL, and reenter it if necessary. |
| PagerDuty fails to trigger. | The PagerDuty routing key is invalid, or the target service is disabled. | Verify the Events API v2 integration key in your PagerDuty instance. Ensure that the PagerDuty service is active and enabled to receive events. |
| A notification channel isn’t visible. | The configured channel realms don’t encompass all of the alert’s selected realms. | In Notification Channel settings, edit the channel to add the missing realm, or create a realm-unrestricted channel. |

# OpenAI Product Feed Field Reference

_Reference information for OpenAI product feed fields, including required fields, optional fields, and their default mappings to B2C Commerce attributes._

### How Default Mappings Work

The OpenAI product feed uses a data-driven mapping system to transform B2C Commerce product data into the format required by OpenAI. When the system can derive a value using standard B2C Commerce attributes, it creates a default mapping that specifies how the value is derived:

- **Field mappings**: Map directly to a single B2C Commerce product attribute, such as **name**, **brand**, or **price**.
- **Derived mappings**: Calculate values from multiple attributes or apply transformations, such as stripping HTML from descriptions or formatting prices with currency codes.
- **Constant mappings**: Use a fixed value for all products. For example, **is_eligible_checkout** is always `false`. Instant Checkout in ChatGPT isn't supported.
- **Fallback mappings**: Map to the primary attribute first, then fall back to an alternative if the primary attribute is empty for that product. For example, **title** uses **name**, falling back to **masterProductName** if **name** is blank.

You can customize fields marked as **Overridable: Yes** in Business Manager. Fields marked as **Overridable: No** are system-managed and visible in the Field Mapping table, but you can't change their mappings.

### Automatic Field Formatting

The system applies automatic formatting to field values before they are written to the feed. This formatting happens regardless of whether you keep the default mapping or override it with a different attribute. When you override a default mapping, you do not need to adapt your catalog data to match OpenAI's format—the system handles the transformation.

Formatting applies as follows:

- **Dates**: Date and datetime values are formatted to `yyyy-mm-dd` (ISO 8601). Invalid dates are omitted from the feed.
- **Booleans**: Values are converted to `true` or `false`.
- **Numbers**: Numeric values are formatted to the required precision (for example, integers with no decimals, or two decimal places for ratings and prices). Invalid or null values are omitted.
- **Prices**: Positive values are formatted to two decimal places and concatenated with the currency code.
- **Descriptions**: HTML tags are stripped from text.
- **Enums**: Values such as **availability** and **age_group** are validated against predefined allowed values.

### Custom Attribute Inheritance for Variants

When you map a custom attribute to an OpenAI field, the system automatically resolves attribute values for variant products using the following inheritance chain:

1. **Variant product**: The system first checks the variant product for the attribute value.
2. **Variation group**: If the variant doesn't have the attribute value, the system checks the variation group (if applicable).
3. **Master product**: If the variation group doesn't have the value, the system checks the master product.

This inheritance chain ensures that custom attributes defined at the master or variation group level are automatically inherited by variants without requiring duplicate data entry.

### Product Eligibility

Two layers control which products appear in the feed:

- **Product filter rules**: Configurable include and exclude rules that determine which products are sent to OpenAI. By default, the rules match products that are online and searchable, but you can adjust them. See [b2c_openai_feed_product_filter.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_product_filter.htm&type=5).
- **Automatic exclusions**: Regardless of your filter rules, the system always excludes the following from the feed:
   
   - Master products (variants are exported instead)
   - Variation groups (variants are exported instead)
   - Product sets. ChatGPT can't handle the dynamic component selection that product sets require. Bundles, which have fixed components, are supported and are sent to OpenAI as standalone products.

### List Price Derivation

The **price** field maps to the regular (list) price of a product. B2C Commerce doesn't have a built-in "list price" concept; storefront teams implement list pricing using different price book strategies. To accommodate this variety, the system derives the list price for the feed in two steps:

1. **Selected list price book**. If you select a price book in **List Price Book** on the General Settings tab, the system uses the price from that price book. The dropdown contains only price books that are active and contain prices in the feed currency. If you later deactivate the selected price book, reconfigure **List Price Book** to point at a different price book.
2. **Sale price book pathway**. If you don't select a list price book, the system derives the list price from the sale price book that the B2C Commerce price engine selects for the product. The price engine evaluates all applicable price books for the product, not only active ones, and returns the best (lowest) price along with its source price book. From that sale price book, the system applies one of two rules:
   
   - If the sale price book has a parent price book, the system walks the parent chain to the root and returns the price from the root price book. This matches the default behavior of SFRA and SiteGenesis storefronts.
   - If the sale price book has no parent, the system returns the maximum price across all applicable price books for the product. This matches the default behavior of PWA Kit storefronts.

> **Note:** If the resolved list price equals the sale price, the system populates only the **price** field and omits **sale_price** from that product's feed entry. This avoids showing a strike-through price in ChatGPT for products that aren't on sale.

Setting **List Price Book** on the General Settings tab is the most reliable way to ensure the list price in your feed matches what shoppers see on your storefront, particularly for storefronts with custom pricing logic, zone-based pricing, or multi-currency price books.

### Sale Price Derivation

The **sale_price** field maps to the B2C Commerce **salePrice** attribute plus the configured **currency**. The **salePrice** value isn't taken from a single price book—the B2C Commerce price engine selects the **best (lowest) price among all applicable price books for the product**, regardless of price book hierarchy or whether a hierarchy is configured.

Because the same engine populates the price your storefront displays, the **sale_price** value sent to OpenAI matches what shoppers see on your site.

If the resolved sale price equals the resolved list price (the **price** field), the system omits **sale_price** from that product's feed entry. This avoids showing a strike-through price in ChatGPT for products that aren't actually on sale. See [#b2c_openai_feed_default_mappings/list_price_derivation](#b2c_openai_feed_default_mappings/list_price_derivation).

If your storefront uses custom pricing logic—such as zone-based or geo-based price book selection—the default sale price calculation may not match what shoppers see. Setting **List Price Book** on the General Settings tab is the most reliable way to align the feed with your storefront in these cases.

### Required Fields

The following fields are required for a valid product feed entry. Products that are missing required fields are still included in the feed, but OpenAI may reject those individual rows. Use the Product Feed Preview to identify products with missing required fields and fix them before you turn on the daily feed sync. See [b2c_openai_feed_preview.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_preview.htm&type=5).

> **Warning:** If more than 30% of your products are missing required fields, OpenAI may reject the entire feed. Ensure your catalog data is complete before you turn on the daily feed sync.

> **Note:** Some required fields don't have a default mapping. Configure these fields in Business Manager before generating your feed. They fall into two groups:
> 
> - Configure on the **General Settings** tab, in the **Business Details** section:
>    
>    - **seller_name**: Your store or brand name as shown to shoppers in ChatGPT.
> - Configure on the **Catalog** tab, in the **Field Mapping** section, using **Override with constant value or pattern**:
>    
>    - **seller_url**: A URL to your storefront homepage.
>    - **return_policy**: A URL that points to your return policy page.

| OpenAI Field | Type | Default SFCC Mapping | Description | Overridable |
| --- | --- | --- | --- | --- |
| **item_id** | string | **id** (Product ID) | Unique product identifier (SKU). Keep stable across feed updates. | Yes |
| **group_id** | string | **masterProductId** (variants), **id** (non-variants) | Variant group ID. For variant products, uses **masterProductId**; for non-variant products, uses the product ID. | Yes |
| **title** | string | **name**, falls back to **masterProductName** if blank | Product title suitable for conversational surfaces. Avoid promotional text. | Yes |
| **description** | string | **longDescription**, falls back to **shortDescription** (HTML stripped) if blank | Full product description used by OpenAI models to understand the product. HTML tags are automatically removed. | Yes |
| **brand** | string | **brand** (if empty, falls back through the inheritance hierarchy: variant, then variation group, then master) | Brand name. | Yes |
| **url** | string | **productUrl** (generated) | Product detail page URL. Generated using the Product-Show pipeline action with the host name from the Einstein configuration. For PWA Kit and headless storefronts, configure URL patterns separately. | Yes |
| **image_url** | string | Selected Image View Type, or default view-type lookup | Main product image URL. If you select a view type in **Image View Type** on the General Settings tab, the system uses that view type. Otherwise, the system attempts the "large" view type and falls back to the first available view type. Because the fallback can select an unsuitable view type (such as a swatch view), Salesforce recommends selecting a specific view type. If no images are available, the field is omitted from the feed. For bundle products, the main image shows all products in the bundle. Use high-resolution images without promotional overlays. | Yes |
| **price** | number | Selected List Price Book, or sale-price-book pathway | Regular (list) product price with currency code, such as "79.99 USD". If you select a price book in **List Price Book** on the General Settings tab, the system uses that price book. Otherwise, the system derives the list price from the sale price book selected by the B2C Commerce price engine. See [#b2c_openai_feed_default_mappings/list_price_derivation](#b2c_openai_feed_default_mappings/list_price_derivation). Only positive values are included. | No |
| **availability** | string | **availability** (derived) | Stock status. Values derived by mapping B2C Commerce inventory levels to one of five predefined values: `in_stock`, `out_of_stock`, `pre_order`, `backorder`, `unknown`. | No |
| **product_category** | string | **categoryPath** | Semantic product category for search and recommendations, such as "Apparel & Accessories > Clothing > Shirts". | Yes |
| **seller_name** | string | (requires configuration) | Your store or brand name as shown to shoppers. Configure this value on the General Settings tab, in the Business Details section. | Yes |
| **seller_url** | string | (requires configuration) | URL to your storefront homepage. Configure this value on the Catalog tab, in the Field Mapping section, by using Override with constant value or pattern. | Yes |
| **return_policy** | string | (requires configuration) | URL to your store's return policy page. Configure this value on the Catalog tab, in the Field Mapping section, by using Override with constant value or pattern. | Yes |
| **is_eligible_search** | boolean | `true` (constant) | Controls whether the product can be surfaced in ChatGPT search results. By default, every product in the feed is discoverable in search (`true`). To gate search discoverability per product, override this field with a custom boolean attribute (such as `c_chatGPT_eligible`); products with a value of `false` still appear in the feed but aren't discoverable in ChatGPT search. | Yes |
| **is_eligible_checkout** | boolean | `false` (constant) | Controls whether direct purchase inside ChatGPT is allowed. Always set to `false`; shoppers are redirected to your site. | No |
| **target_countries** | string | `US` (constant) | Target countries for the item. Uses 2-letter ISO 3166 country code. | No |
| **store_country** | string | `US` (constant) | Store country. Uses 2-letter ISO 3166 country code. | No |
| **listing_has_variations** | string | Derived from **masterProductId** | Indicates if the listing item has variations. Automatically set to `true` if the product has a master product ID. | No |

### Optional Fields

The following fields are optional and can enhance your product listings in ChatGPT. Optional fields are omitted from the feed when the mapped attribute or constant value is blank.

| OpenAI Field | Type | Default SFCC Mapping | Description | Overridable |
| --- | --- | --- | --- | --- |
| **gtin** | string | **ean**, falls back to **upc** if blank | Global Trade Item Number (UPC/EAN). Omitted from the feed if both are blank. Improves product matching. | Yes |
| **mpn** | string | **mpn** | Manufacturer part number. | Yes |
| **marketplace_seller** | string | (none) | Optional field for the seller or point of checkout when **seller_name** is a third-party entity. | Yes |
| **additional_image_urls** | string | **additionalImageLink** | Additional image URLs for richer presentation. Comma-separated list. | Yes |
| **video_url** | string | (none) | Product video URL. | Yes |
| **model_3d_url** | string | (none) | 3D model URL for product visualization. | Yes |
| **sale_price** | number | **salePrice** + **currency** | Discounted price with currency code, such as "59.99 USD". The B2C Commerce price engine derives **salePrice** as the best price across all applicable price books. The system omits this field when the resolved sale price equals the resolved **price**. See [#b2c_openai_feed_default_mappings/sale_price_derivation](#b2c_openai_feed_default_mappings/sale_price_derivation). | Yes |
| **sale_price_start_date** | date | **salePriceStart** | Sale price start date in ISO 8601 format, such as "2025-07-01". Omitted if blank or invalid. | Yes |
| **sale_price_end_date** | date | **salePriceEnd** | Sale price end date in ISO 8601 format, such as "2025-07-15". Omitted if blank or invalid. | Yes |
| **shipping_price** | string | (none) | Shipping method/cost/region in format: `country:region:service_class:price`. | No |
| **variant_dict** | string | **variationAttributes** (as JSON) | Variation attributes in JSON format, such as `{"color": "blue", "size": "M"}`. | No |
| **review_count** | number | (none) | Number of product reviews. | Yes |
| **star_rating** | number | (none) | Average review score out of 5, such as "4.50". | Yes |
| **store_review_count** | number | (none) | Number of brand/store reviews. | Yes |
| **store_star_rating** | number | (none) | Average store rating score out of 5. | Yes |
| **height**, **width**, **length** | number | (none) | Product dimensions. Requires **dimensions_unit** if provided. | Yes |
| **dimensions_unit** | string | (none) | Dimensions unit abbreviation, such as "in" or "cm". Required if you provide any dimension value. | Yes |
| **weight** | number | (none) | Product weight. Requires **item_weight_unit** if provided. | Yes |
| **item_weight_unit** | string | (none) | Weight unit abbreviation, such as "lb" or "kg". Required if weight is provided. | Yes |
| **condition** | string | (none) | Product condition, such as "new", "used", or "refurbished". | Yes |
| **gender** | string | (none) | Intended gender audience, such as "male", "female", or "unisex". | Yes |
| **size** | string | (none) | Product size as a word, abbreviation, or number, such as "Small", "XL", or "12". | Yes |
| **color** | string | (none) | Product color. | Yes |
| **material** | string | (none) | Primary product materials, such as "cotton" or "leather". | Yes |
| **age_group** | string | (none) | Target age group. Values: `newborn`, `infant`, `toddler`, `kids`, `adult`. | Yes |
| **accepts_returns** | boolean | (none) | Whether the product accepts returns (`true` or `false`). | Yes |
| **return_deadline_in_days** | number | (none) | Return deadline in days, such as "14" or "30". | Yes |
| **accepts_exchanges** | boolean | (none) | Whether the product accepts exchanges (`true` or `false`). | Yes |
| **is_digital** | boolean | (none) | Indicates if the product is digital (`true` or `false`). | Yes |

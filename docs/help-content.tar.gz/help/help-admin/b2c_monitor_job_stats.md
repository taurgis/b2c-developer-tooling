# Monitor Job Statistics

_Monitor the duration and number of executions for jobs. Filter and sort the statistics._

|  |
| --- |
| Available in: **B2C Commerce** |

- Click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Job Statistics**.

   When you filter the statistics by job name or site or if you sort the statistics, the screen changes immediately to reflect the filter or sort options you selected. If you select a date range, click **Filter** to refresh the screen.

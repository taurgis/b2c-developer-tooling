# Enable Continuous Order Capture for B2C Commerce

_To maintain business continuity, accept orders during Omnichannel Inventory service interruptions. Enabling this feature makes sure of uninterrupted sales but requires accepting the risk of potential overselling while Omnichannel Inventory for B2C Commerce is offline._

Before you turn on this feature, make sure that you have Salesforce admin privileges and that your site is configured to use Omnichannel Inventory.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global > Preferences > Feature Switches**.
2. Under Inventory, for Continuous Order Capture for Omnichannel Inventory, click **Read and agree to legal requirements**.
3. Read the terms and if you agree to the legal requirements, click **I agree**.
4. Save your changes.

It's recommended you turn on this feature during normal operations rather than waiting for a service disruption. Configuring the Continuous Order Capture setting makes sure that your storefront is protected and ready to capture orders when an interruption occurs.

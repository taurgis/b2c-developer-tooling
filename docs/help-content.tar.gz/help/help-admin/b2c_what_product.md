# Which Salesforce Commerce Product Do I Have?

_Salesforce Commerce includes the B2B Commerce and B2C Commerce products. It’s important to know which product you’re using so that you can access the correct documentation and resources._

Click below to watch a video about the differences between B2B Commerce and B2C Commerce. For a full screen experience, go to [Which Salesforce Product Do I Have?](https://play.vidyard.com/GDgbWtmLyJUJc9EPUh9hWt).

### B2C Commerce

B2C Commerce is an enterprise product that resides on realms, separate from the Salesforce Platform. The realms contain instances on which you develop, test, and deploy your online storefront. You use Business Manager to configure B2C Commerce. The user documentation for B2C Commerce is at [B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_getting_started.htm).

_(image: Business Manager home page)_

### B2B Commerce

B2B Commerce is part of the Commerce app that resides on the Salesforce Platform. B2B Commerce runs on Salesforce orgs. You manage your B2B store from its home page. The user documentation for B2B Commerce is at [B2B Commerce](https://help.salesforce.com/s/articleView?id=commerce.comm_intro.htm&type=5).

_(image: Commerce Store home page)_

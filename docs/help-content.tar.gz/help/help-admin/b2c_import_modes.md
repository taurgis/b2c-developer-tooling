# Import Modes in B2C Commerce

_For import processes, specify an *import mode* to define how to interpret the data within a feed. Some modes aren’t supported for some object types. The import mode, defined for the import process, applies to all objects within the feed. Import modes apply to all import files defined by B2C Commerce schemas._

The following table describes general import mode semantics. See Object Type-specific Import and Export topics for nuances and exceptions.

| Mode | Description |
| --- | --- |
| MERGE | MERGE mode creates an object if it doesn't exist and then performs an UPDATE on the object (see import mode UPDATE). When creating an object, some object attributes have preset defaults. |
| UPDATE | UPDATE mode modifies an existing object. The object isn't created if it doesn't exist.  Object attributes provided in the feed are updated. Object attributes not provided in the feed are left untouched. |
| REPLACE | REPLACE mode recreates an object with the data provided in the feed. The object doesn't need to exist. The import removes existing attributes not provided in the feed.  Technically, REPLACE mode equals a DELETE followed by a MERGE. |
| DELETE | DELETE mode removes an object from the database. Only the object ID is required in the feed. The import ignores the other object attributes. |

DELETE mode deletes objects *in the feed*. Likewise, REPLACE mode deletes and then re-creates objects *in the feed*. Performing a REPLACE import just to change one object deletes the complete object set.

> **Warning:** **Active Data imports always use REPLACE mode.** When importing Active Data CSV files, any attributes not included in the file are permanently deleted. Always make sure your CSV file contains all attributes you want to retain. For more information, see [Import Active Data .csv Files](https://help.salesforce.com/s/articleView?id=cc.b2c_importing_active_data_csv_files.htm&type=5).

Some imports support an attribute mode at the import element level. In this case, the only supported mode is DELETE, whereby the import mode for the process can be overwritten for a particular element. This capability is useful when feeding changed information to a B2C Commerce system. This capability allows a single import process to create, update, and delete objects.

Consider this example, where the import deletes a specific product with product-id *PN-00001*:

`<product product-id="PN00001" mode="delete"/>`

Salesforce recommends that you use delta feeds for production. Delta feeds contain only the changes from the previous feed. Delta feeds are smaller to archive, quicker to import, and easier to troubleshoot. However, for some schemas, some elements override the global import mode and always use the REPLACE mode. These elements can't be included in delta feeds, as they require the full set of objects to be included in each import feed.

### List-Type Elements

The standard behavior for all list-type elements in the XML files is to replace the entire list in the database that the file contains, regardless of import mode MERGE or REPLACE.

If the list-element isn't contained in the import file:

- in MERGE mode, the database list remains
- in REPLACE mode, the import deletes the database list

### Import Mode Processing Examples

We have provided examples of import mode processing.

The following example shows how the import mode you choose updates objects in the database.

The values represented in the feed are:

- A^+a^- an object with a new attribute
- B^-a^ - an object with an attribute removed
- C - an object left unchanged
- D - a new object
- F^Δa^ - an object with an attribute value that is changed

> **Note:** Absent from the XML file is an object that exists in the database (E).

| XML File Objects | Pre-Import Database Objects | Import Mode | Post-Import Database Objects |
| --- | --- | --- | --- |
| A^+a^, B^-a^, C, D, F^Δa^ | A, B, C, E, F | MERGE | A^+a^, B, C, D, E, F^Δa^ |
|  |  | UPDATE | A^+a^, B, C, E, F^Δa^ |
|  |  | REPLACE (except price books) | A^+a^, B^-a^, C, D, F^Δa^ |
|  |  | REPLACE (price books) | A^+a^, B^-a^, C, D, F^Δa^ |
|  |  | DELETE (except price books) | E |
|  |  | DELETE (price books) |  |

For MERGE and UPDATE, attributes not specified in the feed aren’t removed, which is why you see B, rather than B^-a^. Removing an attribute sometimes requires changing the attribute value to none or blank, rather than changing the import mode. The correct value to specify differs, depending on the attribute. See the Framework section for more information on how specific attributes are processed.

For UPDATE, the object D isn't created.

The object "E" isn’t removed in any of the table scenarios, with the exception of price books. If you import a price book in REPLACE or DELETE mode, the import replaces or deletes the entire price book, including data not specified in the feed. For other imports, there’s no mode that deletes objects not included in the feed. Decide on a strategy to explicitly remove outdated objects.

When importing an inventory list in REPLACE mode, any inventory record that is not in the import file gets deleted. If the same inventory list appears multiple times in the same file, it deletes the previously imported elements as well.

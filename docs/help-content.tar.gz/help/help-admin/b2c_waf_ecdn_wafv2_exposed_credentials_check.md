# eCDN WAFv2 Exposed Credentials Check

_Deploy an automated credential check on your end-user authentication endpoints. For any credential pair, the eCDN web application firewall (WAF) performs a lookup against a public database of stolen credentials. Created by the CDN security team, this ruleset provides fast and effective protection for all of your applications. The CDN security team updates the ruleset frequently to cover new vulnerabilities and reduce false positives._

Enable the exposed credentials check ruleset as it’s disabled by default.

- Select the action to perform. Selecting the default option is recommended. When you define an action for the ruleset, you override the default action defined for each rule. The available actions are:
   
   - Default
   - Managed challenge
   - Block
   - JS challenge
   - Log
   - Legacy captcha

_(image: Embedded CDN Settings)_

_(image: WAFv2 Managed Ruleset Settings)_

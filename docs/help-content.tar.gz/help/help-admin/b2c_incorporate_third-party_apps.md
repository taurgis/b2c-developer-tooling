# Securely Incorporate Third-Party Apps

_Storefront capabilities and selling online are Salesforce B2C Commerce's specialties. For other operations, third-party applications bring their expertise to your storefront platform, such as when processing online taxes, credit card payments, and shipping carriers. Using a third-party app created by people who focus exclusively on specific processes is one of the factors that makes B2C Commerce so flexible._

However, using unknown third-party apps can leave any organization open to security vulnerabilities, such as cross-site scripting and information disclosure.

To prevent these issues, use third-party apps that use security best practices as part of supply chain security.

Where applicable, use third-party apps provided by the B2C Commerce LINK Technology Partner Program. These apps offer value-added capabilities and applications that complement B2C Commerce. In addition, Salesforce's partner listing process requires that these apps follow security best practices.

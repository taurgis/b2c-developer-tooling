# Activate the Connection Between Account Manager and Salesforce in B2C Commerce

_After you enable identity federation, link Account Manager with your Salesforce org._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. In a web browser, go to [https://account.demandware.com](https://account.demandware.com/).
2. Select **Login with SSO**.
3. Enter your Salesforce credentials.

   You’re redirected back to Account Manager.
4. Enter your Account Manager username (email address).

   The Account Manager and Salesforce CRM Core email addresses are the same.
5. Click **LOG IN**, and enter your password.
6. Click **LINK ACCOUNT**.
7. Use a registered multi-factor authentication (MFA) method to verify that you’re authorized to log in to Account Manager.

   You’re now logged in to Account Manager.
8. Review the history details to verify that your account is linked to Salesforce Identity.

Next, install Account Manager as a connected app and configure your Salesforce platform.

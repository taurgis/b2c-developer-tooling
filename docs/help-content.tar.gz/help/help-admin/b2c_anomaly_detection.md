# Anomaly Detection in Log Center

_Identify performance regressions, operational issues, and suspicious activity from unusual patterns in Log Center. Log Center continuously analyzes incoming log data and compares the data with learned baseline behavior. When data deviates from the baseline and meets your thresholds, Log Center flags the anomaly. This topic applies to B2C Commerce. Use these guidelines to reduce false positives and improve detector accuracy._

- Start with critical applications, such as authentication failures or error logs.
- Start with a higher threshold, then adjust severity and confidence over time.
- Review detector results regularly, and refine filters to show more relevant results.
- Create separate detectors for different environments to avoid mixing baselines.

The Log Center Anomaly Results window shows the detected anomalies over time. You can compare actual and expected trends, and open related logs for investigation.

_(image: Anomaly Detection Results in Log Center)_

| Field | Description |
| --- | --- |
| Severity | Severity score and category predicted by the model, from 0.0 to 1.0. Higher values indicate more severe anomalies.  Severity ranges:  0.0 (no anomaly) 0.1–0.3 (low) 0.4–0.6 (medium) 0.7–0.9 (high) 1.0 (maximum)  Severity also maps to chart and table colors:  Red (high) Orange (medium) Blue (low) Green (normal) |
| Confidence | Model confidence score, from 0.0 to 1.0, indicating that the behavior is anomalous. Higher values indicate higher confidence. Typical ranges:  0.0–0.3 (low) 0.4–0.6 (medium) 0.7–1.0 (high) |
| Actual | Observed value for the metric or trend at the time of the anomaly. |
| Expected | Predicted value for the metric or trend at the time of the anomaly. |
| Deviation | Difference between the actual and expected values. |

If you need help with validating a detector strategy, tuning thresholds, or troubleshooting results, contact your Salesforce admin or open a support case.

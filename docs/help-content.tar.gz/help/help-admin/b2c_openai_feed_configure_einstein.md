# Configure Catalog and Order Feeds for Commerce Cloud Einstein Deployment

_Before you can use the OpenAI product feed integration, configure Einstein catalog feeds. If your site already uses Einstein features, you can skip this task._

|  |
| --- |
| Available in: **B2C Commerce** |

You need Business Manager administrator permissions to configure Einstein feeds.

If you haven't configured Einstein feeds before, complete this task to set up catalog and order data feeds. The OpenAI product feed integration uses only the catalog feed; order feeds are not required for OpenAI syndication. The catalog feed exports product data to Commerce Cloud Einstein, which the OpenAI integration uses to generate your product feed.

> **Note:** Configure catalog and order feeds only on production instances.

To configure catalog and order feeds:

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Einstein Status Dashboard**.
2. Using the dropdown menu to the right of each site, select **Configure**.
3. In the **Host** field, enter the storefront hostname for the current site.

   For example, `www.mycompany.com`. The OpenAI product feed uses this hostname to construct the **url** column for each product, so shoppers who click through from ChatGPT land on your storefront.
   
   > **Important:** If the Host field already shows a value such as `staging-realm-pod.demandware.net`, that's the instance hostname, not your storefront hostname. Replace it with the storefront hostname before you save.
   
   > **Note:** Don't include the URL scheme (`https://`) in the Host field.
4. In the Deployment Configuration section, select **Region**.

   Select a region only one time per site. This setting specifies a region corresponding to your primary business location. The system uses this information to determine where to physically store and process predictive data. Make sure you configure the region setting in both your Production and Staging instances.
5. Use the following table to define specific actions:

   | Action | Select … |
   | --- | --- |
   | Generate product recommendations on product details pages for pages that are currently out of stock. | Out-of-Stock ProductsThis option enables Einstein to store out-of-stock product catalog information, to continue recognizing out of stock product IDs viewed by shoppers, and to honor any applied recommender rules. The OpenAI product feed also uses this configuration to include or exclude out-of-stock products in the feed. |
   | Storefront catalogs that leverage product type: **Variation Group**. | Variation Group Products |
   | Product catalogs that contain data for products beyond the default locale. | Multi-Locale |
6. To export orders created after a specific date, specify a value in the Export Orders Created After field.

   > **Note:** When specifying this value, ensure that it's either the date your site went live on Commerce Cloud or two years, whichever is the smaller value.
7. Define the maximum number of orders per run.

   This value is the anticipated number of orders you expect on a peak day. The default value is 10,000. As a reference, for a setting of 100,000 orders, the order feed processing time is approximately 30 minutes.
   
   > **Note:** When configuring maximum orders per run for new sites with large order histories, we recommend that you increase the number of orders to exceed 10,000. This setting enables the order feed to import orders from the most recent date instead of taking many days to catch up to the current day. If the order feed isn't up to date, it's possible that Commerce Insights won't generate. Commerce Insights displays shopper basket visualization for the last 7 days.
8. (Optional) To run the catalog and order feeds immediately, click **Save**.
9. Set the Schedule Catalog and Order Feed switch to **On**.

   If the switch is inactive, catalog and order feeds aren't scheduled for the site.
10. Define the catalog feed schedule.

   | Field | Recommendations |
   | --- | --- |
   | Start Date and Time | To ensure Einstein receives your most current product information or recent product launches, schedule jobs to run shortly after replication from staging to production completes.To view staging to production replication job completion time go to **Staging Instance > App Launcher > Administration > Replication > Data Replication Processes > view End Time for Type: Transfer & Publication**. |
   | Time Unit | Day |
   | Frequency | 1We recommend a daily catalog feed to enable Einstein to remain up to date with any changes. The entire catalog is exported only on the first run. To keep daily runtimes shorter, subsequent runs contain only deltas. The feed frequency can be once per day, once every other day, once per week, and so on—but not more frequently than once per day (for example, no twice per day or hourly). |
11. (Optional) Define the order feed schedule.

   Order feeds are not required for the OpenAI product feed integration. Configure the order feed only if you use other Einstein features that require it, such as Commerce Insights or Product Recommendations.
   
   | Field | Recommendations |
   | --- | --- |
   | Start Date and Time | Schedule jobs for off-peak ordering times. |
   | Time Unit | Day |
   | Frequency | 1Because it uses orders from the last 7 days, configuring a daily order feed is important for keeping the Commerce Insights feature up to date. Order feeds are also used in the Product Affinity Algorithm for the Product Recommendations strategy. |
12. Click **Save**.

   Business Manager saves the configuration.
13. Wait at least 24–48 hours for deployment to complete.
14. Log a ticket with Salesforce Support and request to be added as an initial Site Admin to the Configurator.
15. (Optional) After you are added as the Site Admin, open the Einstein Configurator and navigate to **Admin > User Management**. Add additional users as needed.

   This step is optional and gated by permissions. Complete it only if you need to manage Einstein Configurator users. Users must have an Account manager account in the relevant organization, but don't need a specific Account Manager role.

See Also

- [Configure Catalog and Order Feeds for Commerce Cloud Einstein Deployment](https://youtu.be/5YKKqpNuqds?si=kwSoyakQjLI9JX9n)

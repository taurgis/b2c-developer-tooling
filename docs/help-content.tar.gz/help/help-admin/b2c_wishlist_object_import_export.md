# Wish List or Order Status Object Import/Export in B2C Commerce

_There’s no built-in support for importing wish list objects or order status objects. However, you can develop a proprietary XML format and use the B2C Commerce script or a pipelet to update these objects._

Wish lists can be exported as product lists.

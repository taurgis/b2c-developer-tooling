# Shopper Authentication in B2C Commerce

_Shoppers can register and create accounts on your storefront or they can remain anonymous. For example, to browse your storefront, shoppers aren’t required to log in to their account or even have an account. However, when a shopper creates an account, you now have their information, such as billing address, credit card, and previous orders. Authenticated shoppers can also access certain functionality that’s not available to anonymous shoppers, such as a gift registry and wishlist._

To create an account, the shopper enters a username and password. After registering, a shopper can change their password. Use Business Manager to configure a password policy as the primary security control for shopper authentication. To enhance security, increase password length from eight characters (default) to 10 characters.

Salesforce B2C Commerce supports OAuth2 to authenticate shoppers and obtain information about them from third-party OAuth Providers, such as Google and Facebook. Shoppers must authorize this access. This feature also makes it faster and easier for shoppers to register with and log in to your storefront. Instead of entering personal information, they can log in with an existing account, such as a Google account. Using an existing account gives your storefront permission to retrieve their personal information from that account.

These authentication schemes apply when the storefront goes into production. However, when the storefront is in development or testing, you don't want potential shoppers to find it through a search engine. To prevent this, use Business Manager to restrict access to your development, staging, and production instances to merchants and other people involved in the project.

To do this, enable the `Protection` mode for the storefront and configure a shared username and password. This shared username and password are used for storefront access for internal use, such as for development and testing. Enable storefront protection mode, which is disabled by default.

> **Note:** The merchant is responsible for shopper authorization.

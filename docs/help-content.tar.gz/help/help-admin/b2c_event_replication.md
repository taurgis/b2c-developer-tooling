# Process-Level Replication Events

_Process-level replication events fire when a replication process reaches a terminal state. Use them to track when bulk replication jobs complete or fail._

**Available in:** B2C Commerce release 26.6 and later.

### Event IDs

### HTTP headers

Process-level replication events use the standard headers documented in [Common HTTP Headers for B2C Commerce Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_common_headers.htm&type=5), with `x-sf-cc-event-id` set to the event ID listed above.

### Common payload fields

Both `sf.cc.replication.completed` and `sf.cc.replication.failed` events include these fields inside the `payload` object.

Failed events (`sf.cc.replication.failed`) also include `errorState`, a machine-readable error code. See [Replication Error States](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_error_states.htm&type=5).

### Process types

The `type` field indicates the replication operation.

### Process states

The `state` field indicates the process state.

> **Note:** `CANCELED` is deprecated and shouldn't appear in new events.

### Example: successful data replication

```
{
"eventType": "sf.cc.replication.completed",
"timestamp": "2026-03-11T13:31:13.755934395Z",
"tenantId": "zzzz_stg",
"payload": {
"processId": "12345",
"uuid": "550e8400-e29b-41d4-a716-446655440000",
"type": "ReplicationPublication",
"targetSystem": "Production",
"state": "COMPLETED",
"isDataReplication": true,
"success": true,
"description": "Weekly catalog update",
"replicationGroups": [
{
"id": "ORGANIZATION_CATALOG",
"type": "ORGANIZATION"
},
{
"id": "CATALOG",
"type": "REPOSITORY",
"domain": "storefront-catalog-m-en"
}
],
"startDate": "2026-03-11T13:31:03Z",
"endDate": "2026-03-11T13:31:13.727Z"
}
}
```

### Example: failed replication

```
{
"eventType": "sf.cc.replication.failed",
"timestamp": "2026-03-11T14:22:18.442Z",
"tenantId": "zzzz_prd",
"payload": {
"processId": "12346",
"uuid": "660e8400-e29b-41d4-a716-446655440001",
"type": "Replication",
"targetSystem": "Production",
"state": "FAILED",
"isDataReplication": true,
"success": false,
"description": "Emergency content update",
"errorState": "ErrorConnectLiveSystem",
"replicationGroups": [
{
"id": "SITE_CONTENT",
"type": "SITE"
},
{
"id": "SITE",
"type": "REPOSITORY",
"domain": "RefArch"
}
],
"startDate": "2026-03-11T14:22:15Z",
"endDate": "2026-03-11T14:22:18.442Z"
}
}
```

### Example: successful code replication

```
{
"eventType": "sf.cc.replication.completed",
"timestamp": "2026-03-11T15:05:32.118Z",
"tenantId": "zzzz_prd",
"payload": {
"processId": "12347",
"uuid": "770e8400-e29b-41d4-a716-446655440002",
"type": "CodeReplicationPublication",
"targetSystem": "Development",
"state": "COMPLETED",
"isDataReplication": false,
"success": true,
"codeVersion": "version1",
"replicationGroups": [],
"startDate": "2026-03-11T15:00:00Z",
"endDate": "2026-03-11T15:05:32.118Z"
}
}
```

### Notes

- The `description` field is optional user-provided text.
- An empty `replicationGroups` array indicates code-only replication.
- Error states are machine-readable codes, not localized text. See [Replication Error States](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_error_states.htm&type=5).

## Related Content

- [Replication Group IDs](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_groups.htm&type=5)
  Replication events carry one or more replication groups in their payload. Each replication group identifies a unit of data that participated in the replication. Use this page to look up what a given group ID covers.

- [Replication Error States](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_error_states.htm&type=5)
  Failed process-level replication events (`sf.cc.replication.failed`) include an `errorState` field with a machine-readable code that identifies the failure. Use this page to look up what an error state means.

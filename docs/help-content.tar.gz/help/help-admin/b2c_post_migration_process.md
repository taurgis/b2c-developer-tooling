# Post-Migration Tasks for B2C Commerce

_Post-migration tasks validate your eCDN traffic flow and setup. To complete the post-migration process, coordinate with B2C Commerce Engineering. B2C Commerce Engineering creates and activates a staging Business Manager zone to handle your Business Manager traffic that goes through only your Business Manager host name, for example, `staging-<realm>-<customer>.demandware.net.`Business Manager supports eCDN for staging instances._

This step is only required of staging instances on realms created before June 2023 as the Business Manager zones pre-exist in all development and production instances.

|  |
| --- |
| Available in: **B2C Commerce** |

[B2C Commerce Engineering](https://developer.salesforce.com/docs/commerce/b2c-commerce/overview) services include the lockdown protections that protect your production and development instances.

Post-migration tasks:

1. Revert to the *.demandware.net certificate at the origin. This step applies to custom certificates installed to the POD for the staging instance.

   B2C Commerce Engineering validates that traffic is flowing through eCDN for the configured host names. After validation, B2C Commerce Engineering reverts the certificate at the origin level to the standard *.demandware.net certificate. The Salesforce Commerce API (Shopper Commerce API (SCAPI)) can then connect to your staging instance.
2. Create and activate a staging Business Manager zone.

   B2C Commerce Engineering creates and activates the Business Manager zone for your implementation.
   
   B2C Commerce Engineering creates and activates the Business Manager zone for your implementation.
   
   If you use the self-service steps to create an eCDN zone and certificate, contact Salesforce Commerce Cloud (SFCC) Support. They contact B2C Commerce Engineering to create and activate a staging Business Manager zone.
   
   If you implement an existing custom certificate for your staging instance, B2C Commerce Engineering creates and activates the staging Business Manager zone automatically. If you do not want this to be done, please contact [Salesforce Support](https://help.salesforce.com/s/articleView?id=000318530&type=1&language=en_US).

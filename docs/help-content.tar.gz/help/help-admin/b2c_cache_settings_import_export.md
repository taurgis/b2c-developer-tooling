# Cache Settings Object Import and Export in B2C Commerce

_Use the cache settings object to manage static cache time to live, cache enablement, and page cache partitions. This topic applies to B2C Commerce._

Cache settings are often replicated instead of imported, because a full page cache invalidation is required before they take effect. The cache settings import always uses a replace semantic. The replace semantic deletes any partition definitions not included in the import. After import, the cache for all partitions is invalidated.

| Object Information | Details |
| --- | --- |
| Schema file | cache-settings.xsd |
| Granularity | Page cache partition configurations, static cache time to live value per instance, and whether the page cache is enabled per instance. |
| Business Manager import and export location | ***site* > Administration > Site Development > Site Import & Export** |
| Pipelets | N/A |

This table describes cache-settings.xsd schema elements, and provides considerations when creating values for these elements.

| Element | Description | Example |
| --- | --- | --- |
| Settings | Sets static cache time to live and page cache enablement flags. | <settings> <development> <static-cache-ttl>86400</static-cache-ttl> <page-cache-enabled>true</page-cache-enabled> </development> <staging> <static-cache-ttl>0</static-cache-ttl> <page-cache-enabled>false</page-cache-enabled> </staging> <production> <static-cache-ttl>86400</static-cache-ttl> <page-cache-enabled>true</page-cache-enabled> </production> </settings> |
| Page-Cache-Partitions | Specifies the configuration of page cache partitions. You can specify a maximum of 10 pipelines. | <page-cache-partitions> <page-cache-partition partition-id="partition0"> <name>partition0</name> <pipelines> <pipeline>Account-Show</pipeline> <pipeline>TestPipeline-Start</pipeline> <pipeline>Pipeline3-Start</pipeline> <pipeline>Pipeline4-Start</pipeline> <pipeline>Pipeline5-Start</pipeline> <pipeline>Pipeline6-Start</pipeline> <pipeline>Pipeline7-Start</pipeline> <pipeline>Pipeline8-Start</pipeline> <pipeline>Pipeline9-Start</pipeline> <pipeline>Pipeline10-Start</pipeline> </pipelines> </page-cache-partition> </page-cache-partitions> |

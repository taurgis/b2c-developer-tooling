# Browser-Based Local Data Storage in B2C Commerce

_B2C Commerce uses browser cookies and session storage objects to store and track information. This topic applies to B2C Commerce._

Browser cookies and session storage object information can exist on machines with browsers running B2C Commerce merchant applications, or with browsers accessing websites that run on B2C Commerce.

**Understanding Cookie Type Classifications**

The tables in this topic classify cookies as either **Required** or **Functional**. These classifications describe **technical purpose and platform dependency only**. They are not intended to represent legal classifications or consent requirements under privacy regulations such as GDPR or ePrivacy.

- **Required:** Cookies classified as Required are technically necessary for the operation, security, or integrity of the Salesforce B2C Commerce application or service. These cookies support essential functions such as session management, authentication, security controls, and infrastructure routing. They are created as part of normal platform operation and cannot be disabled without impacting core functionality.
- **Functional:** Cookies classified as Functional support feature-level behavior and platform capabilities beyond core session and security functions. These cookies enable or control optional functionality such as analytics, personalization, preference handling, configuration signaling, or feature gating. Functional cookies **can be created by default** to support platform behavior or configuration, even when the associated feature is disabled or suppressed. Being labeled "Functional" does not guarantee that the cookie is created only after consent. The classification reflects technical purpose, while creation timing is driven by platform behavior.

> **Note:** The Required and Functional classifications do not map 1:1 to GDPR-defined cookie purposes (Strictly Necessary, Preferences, Statistics, Marketing). GDPR is an EU regulation, but its enforcement and interpretation vary by country. Merchants are responsible for determining which cookies require consent in their jurisdiction and for managing consent via a Consent Management Platform (CMP). Consult your legal advisors for guidance specific to your situation.

When processing privacy requests from shoppers for account deletion or the Right to be Forgotten, merchants can inform or remind the shopper about the cookies set on B2C Commerce websites. Although these data objects are no longer used after their lifespans expire, they sometimes persist on a shopper’s browser. Depending on the scope of a shopper's request, a merchant reminds them that they can and, in some cases, delete all data objects from their own browsers if they wish to withdraw consent or completely delete all identifiable data from B2C Commerce. Instructions for deleting these objects manually depends on the browser type. Instruct shoppers to refer to the documentation for their browser. Consult your legal advisors when responding to privacy requests.

> **Note:** You might want to implement functionality on your storefront that allows shoppers to easily delete their own B2C Commerce cookies. For example, you could create a privacy information page with a button that deletes B2C Commerce cookies from the shopper's browser.

> **Note:** In the following tables, an asterisk in an object name represents a random string appended to the name. For example, the dwac_* cookie can appear on a user’s computer as "dwac_js894CJS92kD."

**Shopper Applications**

The following B2C Commerce shopper-facing applications use cookies that can exist on a shopper's computer:

- Salesforce B2C Commerce Storefront
- SiteGenesis
- B2C Commerce Einstein

**B2C Commerce Storefront**

Used by B2C Commerce to operate a storefront.

| Cookie | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| dwanonymous_* | 180 days | Required | Random ID used to identify an unregistered shopper or a shopper who has not yet logged in independent of the session. For example, this is used to track basket and order activity and for analytics. It is not used for any activity that occurs after the shopper registers an account. The * in the cookie name is a value unique to the site. |
| dwsid | Current session | Required | Identifies the current browsing session. |
| sid | Current session | Required | Identifies the current browsing session. The Salesforce Reference Architecture (SFRA) uses this to determine whether to display the cookie hint content asset. Only used by SFRA and by customizations. |
| dwsecuretoken_* | Current session | Required | Used with dwsid to secure the session through HTTPS. The * in the cookie name is a value unique to the site. |
| dwcustomer_* | 180 days | Functional | Identifies a registered shopper. Used only when the shopper selects **Remember Me**. (This is an optional website feature.) The * in the cookie name is a value unique to the site. |
| dw_dnt* | Current session | Required | Controls client-side JavaScript for B2C Commerce tracking features (Analytics, Einstein, and ActiveData). B2C Commerce sets it with each page response, based on the value of the corresponding session attribute **TrackingAllowed**. The value of this cookie always matches that of the Einstein __cq_dnt cookie. |
| dwac_* | Current session | Functional | Stores the following data for analytics purposes: Session ID, report suite name, shopper’s customer ID, source code group ID (encoded), currency mnemonic, and time zone. The * in the cookie name is a value unique to the site. |
| dwpersonalization_* | 180 days | Functional | Tracks participation in A/B test groups for analytics purposes. If the shopper participated in a test, then the value is cleared when the shopper logs out. The * in the cookie name is a value unique to the site. |
| dwsourcecode_* | Varies from 0-999 days | Functional | Stores the source code for campaign and affiliate tracking. You set the lifespan of this cookie for each source code in Business Manager. The * in the cookie name is a value unique to the site. |
| __anact | Ephemeral | Functional | Transfers some Analytics-related data to the front end, such as data for no-hit searches. |
| dw_store | 180 days | Functional | The store id for the session. This is used for the Store-Specific Pricing and Promotion feature. When a shopper enters a postal or zip code, it is used to locate the nearest store and store that in this cookie to drive pricing and promo experiences. |
| dw_effective_time | Session | Functional | The effective time for the session. This is used for the Shop the Future feature. When the shopper enters an effective date, for example, future order pick up, it is used to find the accurate pricing and promotions to display to the shopper.The Shop the Future feature is not supported in Product List Pages. |
| _cfduid | 30 days | Required | Helps Cloudflare detect malicious visitors to customers' websites and minimize blocking of legitimate users. Can be used on customers' end user devices to identify individual clients behind a shared IP address and can apply security settings on a per-client basis. This is required to support Cloudflare's security features. See Cloudflare's documentation for details on this third-party cookie. |

**SiteGenesis**

Used by SiteGenesis and available for use by sites based on SiteGenesis. Not used by SFRA.

| Cookie | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| dw_cookies_accepted | Current session | Required | When the merchant has enabled the cookie hint notice, it records that the shopper has acknowledged that cookies are being used. See SiteGenesis Standards Compliance for more information. |
| dw_TLSWarning | 30 days | Required | Identifies whether the shopper's browser only supports outdated versions of Transport Layer Security (TLS). Set to true if the browser fails the compatibility check or if the check can't be completed. See TLS Browser Detection for information on the compatibility check. |
| dw | Current session | Functional | This cookie has been deprecated and is no longer used to collect data. It is in the process of being removed from the SiteGenesis codebase. |

**Used by Einstein for AI functionality**

The uuid (third-party) and __cq_uuid (first-party) cookies contain a randomly-generated user ID that exists on a shopper's browser and can be used during a visit to any B2C Commerce website, regardless of the merchant. These cookies are only set or accessed during a site visit if the __cq_dnt cookie, which tracks consent, is not set. The merchant is responsible for obtaining and tracking consent.

Note: Once a value is set for these cookies, it remains until it expires or until the shopper deletes it from the browser. When a shopper visits a B2C Commerce merchant site where the __cq_dnt cookie is set, these cookies are simply ignored. If a shopper requests that a merchant delete their data, then all data associating that shopper with the cookie value is removed from the merchant's B2C Commerce instance. The cookies can remain on the shopper's browser, but that merchant can no longer connect them to that shopper.

| Data Object | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| cqcid | Current session | Required | Hashed ID for an unregistered shopper. |
| cquid | Current session | Required | Hashed ID for a known shopper. |
| __cq_uuid | 13 months | Functional | First-party version of the third-party uuid cookie. Contains a randomly generated user ID. Used to collect information about the shopper's activities on the merchant's own website. This information is also used for analytics purposes, including by B2C Commerce Reports and Dashboards. |
| __cqact | Current session | Required | Holds the queue of browser activities until they are sent. |
| __cqviews | Current session | Required | If sessionStorage is not available, contains the most recently viewed recommendations until they are sent. |
| __cqsviews | Current session | Required | If sessionStorage is not available, contains the products in the most recent search results until they are sent. |
| __cqcviews | Current session | Required | If sessionStorage is not available, contains the products in the most recently viewed category page until they are sent. |
| __cq_anchor | Current session | Required | If sessionStorage is not available, contains the anchor products for recommendations on a page. |
| weird_get_top_level_domain | Current session | Required | Detects the root domain on the page. |
| __cq_bc | 30 days | Functional | First-party version of the bc cookie. Contains activity history, such as the last 10 products viewed by the shopper. |
| __cq_seg | 30 days | Functional | Contains inferred shopping propensity attributes and other segment attributes used in predictive sort. (First-party version) |
| __cq_dnt | Current session | Required | Indicates that the browser has opted out of CC Einstein tracking for this site. B2C Commerce sets it with each page response based on the value of the corresponding session attribute **TrackingAllowed**. The value of this cookie always matches that of the Storefront dw_dnt* cookie. |
| cq | Current session | Functional | (Session storage object) Tests whether sessionStorage is available. |
| cq.anchor | Current session | Functional | (Session storage object) Contains anchor product IDs. |
| cq.viewReco | Current session | Functional | (Session storage object) Contains the most recently viewed recommendations. |
| cq.viewSearch | Current session | Functional | (Session storage object) Contains products from the most recent search results. |
| cq.viewCategory | Current session | Functional | (Session storage object) Contains products from the most recently viewed category page. |
| __cq_seg | 30 days | Functional | Contains inferred shopping propensity attributes. Third-party cookie set on .cquotient.com. |
| uuid | 30 days | Functional | Third-party version of the first-party __cq_uuid cookie set on .cquotient.com. Contains a randomly generated user ID. Used to track data for analytics purposes, including B2C Commerce's own analytics as described in the Trust & Compliance documentation, such as B2C Commerce Reports and Dashboards. |
| bc | 30 days | Functional | Contains activity history, such as the last 10 products viewed by the shopper. Third-party cookie set on .cquotient.com. |
| __cq_recoUUID | Current session | Functional | Tracks the recommendation request so that a click can be attributed to it. |
| __cq_banditPrediction | Current session | Functional | Tracks the contextual bandit response so that a click can be attributed to it. |

**Merchant Applications**

The following B2C Commerce merchant applications use cookies that can exist on a user's computer. No shopper data is involved.

- Control Center
- Account Manager
- Log Center
- Business Manager
- Order Management
- B2C Commerce Reports and Dashboards

**Control Center**

| Cookie | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| SESSION | Current session | Required | Identifies the current browsing session. |
| XSRF-TOKEN | Current session | Required | Used to validate requests. This protects against cross-site request forgery (CSRF). |

**Account Manager**

| Cookie | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| JSESSIONID | Current session | Required | Identifies the current browsing session. |
| dwAccountManager | Current session | Required | Authenticated session ID |
| amlbcookie | Current session | Required | OpenAM-specific load-balancing cookie for Account Manager (not used). |
| NGINX_SESSION | Current session | Required | Load-balancing cookie for Account Manager |
| XSRF-TOKEN | Current session | Required | CSRF protection token |

**Log Center**

| Cookie | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| JSESSIONID | Current session | Required | Identifies the current browsing session. |

**Business Manager**

| Cookie | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| dwbmsid | Current session | Required | Identifies the current browsing session when the **Separate Business Manager Session Cookie** feature is active. |
| _ga | 720 days | Required | Identifies the official Google Analytics cookie. As per Google documentation, this cookie distinguishes users. B2C Commerce sends the following data as part of this cookie:  user ID page information customer (merchant), such as Tory Burch  site PSD, such as production, staging, development page, such as page module |
| _gat | 1 minute | Required | Identifies the official Google Analytics cookie. Per Google documentation, this cookie throttles the request rate. This is a temporary cookie with a life span of 1 minute and doesn't include any personal identifiable information. |
| pendo_identity | 94 days | Required | Identifies the Pendo cookie that processes the Salesforce B2C Commerce data. |
| pendo.sess.jwt | 36 hours | Required | Identifies the Pendo cookie that processes the Salesforce B2C Commerce data. |

**Order Management**

| Cookie | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| .BF397AUTH | Current session | Required | Stores authentication token. |
| ASP.NET_SessionId | 15 minutes when true; 30 minutes when false | Required | Identifies the authenticated session ID. |
| AWSELB | Current session | Required | (For AWS users) Identifies the load-balancer session. |
| RETAILCENTER | Permanent | Required | Identifies the store when a user selects the store in Retail Center. The value is specific to the computer. |
| AWSELBCORS | Current session | Required | (For AWS users) Uses session for session stickness. |
| MscState | Current session | Required | Identifies the session cookie for the sdk and website. The cookie saves the cart data in Customer Service Center, the identity of how users are logged in, and the cultural locale information for the logged in user. |
| __dwocXtkn | Current session | Required | AntiCSRF validation token |
| CSC.minstate | Current session | Required | Identifies the Customer Service Center's session state. |

**B2C Commerce Reports and Dashboards**

| Cookie | Lifespan | Cookie Type | Description |
| --- | --- | --- | --- |
| connect.sid | 1 hour | Required | Identifies the current browsing session. |
| XSRF-TOKEN | 1 year | Required | Validates requests. Protects against CSRF. |
| _pendo_accountid* | Varies | Functional | Processes data for Pendo analytics. Also used by Einstein and Business Manager. |
| _pendo_meta* | Varies | Functional | Processes data for Pendo analytics. Also used by Einstein and Business Manager. |
| _pendo_visitorid* | Varies | Functional | Processes data for Pendo analytics. Also used by Einstein and Business Manager. |

# Services Import/Export in B2C Commerce

_The services.xsd schema file describes all web service profile and credential data. B2C Commerce encrypts credentials during a services export. This topic applies to B2C Commerce._

Site export exports certain objects (including database objects and static files) and stores them in a single .zip file, which is available for download. You can upload the .zip file to another instance and import it there. Site import is possible only if there’s no custom site in the instance.

Credentials: credential configuration is partially exported.

*Granularity:* all services.

### Business Manager Import Location

**Administration > Site Development > Site Import & Export**

**Administration > Operations > Import & Export > Services**

### Pipelets

ImportServices

ExportServices

*Granularity:* selected objects.

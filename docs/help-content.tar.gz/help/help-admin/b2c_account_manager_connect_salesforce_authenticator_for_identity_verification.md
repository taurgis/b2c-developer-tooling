# Connect Salesforce Authenticator (Version 3 or Later) to Your Account for Identity Verification in B2C Commerce

_The Salesforce Authenticator mobile app is a fast and easy verification method for multi-factor authentication (MFA) logins. Register the app to connect it to your Account Manager account. To receive and approve push notifications sent to your mobile device, Salesforce Authenticator requires that you secure your mobile device with a security pin or face ID._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Download and install the Salesforce Authenticator app (version 3 or later) for the type of mobile device you use.

   For iPhones, you can get the app from the [App Store.](https://itunes.apple.com/us/app/salesforce-authenticator/id782057975?mt=8)
   
   For Android devices, you can get the app from [Google Play](https://play.google.com/store/apps/details?id=com.salesforce.authenticator&hl=en).
   
   If you previously installed version 1 of Salesforce Authenticator on your mobile device, you can update the app to version 3 through the App Store or Google Play. The update preserves any connected accounts you already have in the app. These accounts are code-only accounts that generate verification codes but don’t receive push notifications or allow location-based automated verifications. If you have a code-only account for the username that you used for your current login to Salesforce, swipe left in the app to remove that username before proceeding. In the following steps, you connect the account for that username again. The new connected account gives you full Salesforce Authenticator version 3 functionality. If you already have version 2 installed, version 3 updates are pushed out to you.
   
   Depending on the MFA verification method settings of your organization:
   
   - Connecting Salesforce Authenticator is required at your next login and is the only verification method allowed: click ** REGISTER DEVICE** to continue.
   - Connecting Salesforce Authenticator or another verification method is required at your next login: Click **Salesforce Authenticator** to continue.
   - If you’re logged into Account Manager, and if registering multiple MFA verification methods is an option, you can connect Salesforce Authenticator in your Account Information: click **Add** next to **Multi-Factor Verification** and choose **Salesforce Authenticator**.
2. Open the Salesforce Authenticator app on your mobile device. If you’re opening the app for the first time, you see a tour of the app’s features. Take the tour, or go straight to adding your Account Manager account to the app.
3. In the app, tap **Add** to add your account.

   The app generates a unique two-word phrase.
4. In the Connect Salesforce Authenticator window, enter the phrase in the **Two-Word Phrase** field.
5. Click **Connect**.

   If you previously connected an authenticator app that generates verification codes to your account, you sometimes see an alert. Connecting a new version of the Salesforce Authenticator mobile app invalidates the codes from your old app. When you need a verification code, get it from Salesforce Authenticator. In the Salesforce Authenticator app on your mobile device, you see details about the account you’re connecting.
6. To complete the account connection, tap **Connect** in the app.

   To help keep your account secure, we send you an email notification whenever a new identity verification method is added to your Account Manager account.
   
   After you connect the app, you get a notification on your mobile device when you do something that requires identity verification. When you receive the notification, open the app on your mobile device, check the activity details, and respond on your mobile device to verify. If you’re notified about activity you don’t recognize, use the app to block the activity. You can flag the blocked activity for your Account Administrator. The app also provides a verification code that you can use as an alternate method of identity verification.

# Removing Outdated Objects in B2C Commerce

_How you remove outdated objects depends on whether you enrich the data from your backend system with more attributes in Business Manager. It also depends on the type of business object you want to remove. B2C Commerce generally recommends creating feeds of objects to delete, imported using the DELETE mode, to safely remove all types of objects, regardless of whether they have enriched data or not._

### Removing Catalog Objects

Most merchants import product objects from a backend feed and then enrich the objects in Business Manager with URLs or other web-specific attributes. In this case, the usual import mode is MERGE. This mode, however, doesn’t delete objects from the database. Therefore, products remain in the database until you delete them.

You have the following options to delete unwanted catalog objects:

- DELETE feed - Create a feed containing objects you want to delete and import it using the DELETE mode. This mechanism is recommended, because it can be used with all types of objects and doesn't affect enriched data.
- Catalog feed syntax for delete - For catalog feeds only, Specify objects to remove in the feed itself, if your backend system can produce the required syntax. This syntax isn't available for other types of feeds.
- Pipelet catalog delete - The ImportCatalog pipelet supports the following configuration options for the `ImportConfiguration` parameter.
   
   | Option | Description |
   | --- | --- |
   | key=deleteCatalog; value=true \| false | Deletes the catalog before the import. Use this mechanism as a high-performance way to empty a catalog. However, if you use this option it removes any enriching attributes added in Business Manager, so use it only for unenriched objects. |
   | key=replaceCustomAttributes; value=true\| false | Deletes custom attributes before import when used with UPDATE or MERGE mode. Use this mechanism to automatically remove obsolete custom attributes, but is faster than REPLACE mode. |
   | key=replaceCustomAttributesExclusions; value=attrID1, attrID2, ... | Import of product custom attributes in REPLACE, MERGE, and UPDATE mode doesn't replace the listed attributes. This approach is used in combination with the `replaceCustomAttributes` option. |
- Business Manager object delete - Delete the objects in Business Manager. This approach isn't recommended, unless you have only a few objects to delete.

Choose to remove the entire catalog or all custom attributes before import. But the instance doesn't contain full data while the feed imports. If the import feed isn't successful, only the data that was successfully imported exists in your instance database. This approach isn't recommended for production systems. However, this strategy can be useful if you have different seasonal catalogs and you want to replace all the products. You can also use this strategy if you have multiple catalogs on staging. For example, suppose you have one catalog that is populated only by external vendors that you want to delete. Also, suppose that you have a second custom storefront catalog you want to preserve. For the second catalog, you can run an UPDATE to preserve the changes made already on STAGING.

### Removing Other Objects

You have the following options to delete objects:

- DELETE feed - Create a feed containing objects you want to delete and import it using the DELETE mode. This approach is recommended, because this mechanism can be used with all types of objects and doesn't affect enriched data.
- Business Manager object delete - Delete the objects in Business Manager. This approach isn't recommended, unless you have only a few objects to delete.

Removing custom meta Data

The meta data import wizard in Business Manager provides an option to delete all meta data before the actual import. Use this option to automatically delete existing meta data and use the MERGE or UPDATE mode for a faster import.

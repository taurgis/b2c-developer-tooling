# Use Custom Attributes in OpenAI Feed Mappings

_Map custom product attributes to OpenAI feed fields when the default B2C Commerce standard attributes don't meet your needs._

Before you map custom attributes, ensure that:

- The custom attributes are defined in your product catalog.
- The custom attributes are part of an attribute group. Otherwise, they don't appear in the dropdown.
- The custom attributes have accurate values populated for all your products.

Custom attributes allow you to send specialized product data to OpenAI that isn't available in standard B2C Commerce attributes. For example:

- Material or fabric composition for apparel
- Technical specifications for electronics
- Nutritional information for food products
- Custom brand or manufacturer fields

You can identify custom attributes by the `c_` prefix in their names (for example, **c_material**).

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations > OpenAI**.
2. Click **Catalog**.
3. In the field-mapping table, locate the OpenAI field you want to map to a custom attribute, and click **Override** next to the field.
4. In the **Select SFCC Field** dropdown, scroll to find your custom attribute or type the attribute ID to search.

   Custom attributes appear with their `c_` prefix. For example, a custom material attribute appears as **c_material**.
5. Select the custom attribute.

   To restore the default mapping, click **Reset.**

The custom attribute is now mapped to the OpenAI field. When the system generates the feed, it retrieves the value from your custom attribute for each product.

Map **c_fabricComposition** to **material** to include detailed fabric information like "60% Cotton, 40% Polyester". Set **return_deadline_in_days** to a constant value like `30` to specify your return window.

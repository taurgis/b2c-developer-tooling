# Importing or Exporting SiteGenesis Data in B2C Commerce

_The SiteGenesis application doesn't include import and export feed examples. However, if you run Site Import/Export (export) on the SiteGenesis data, the files exported are valid import files. These import files contain the SiteGenesis data. This topic applies to B2C Commerce._

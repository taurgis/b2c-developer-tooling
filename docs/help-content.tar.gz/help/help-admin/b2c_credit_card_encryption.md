# Credit Card Encryption in B2C Commerce

_Credit card encryption, key generation, and re-encryption are automatic in B2C Commerce. B2C Commerce provides the ability to monitor this process for merchants undergoing a PCI audit._

Payment instruments, such as debit and credit cards, aren’t removed from B2C Commerce. They’re masked after a data retention period that you can configure. The default retention period is 12 months. While B2C Commerce masks credit card payment instrument types based on credit card validity, it masks payment instruments of other types after the data retention period expires. It masks payment instruments assigned to orders after the data retention period expires.

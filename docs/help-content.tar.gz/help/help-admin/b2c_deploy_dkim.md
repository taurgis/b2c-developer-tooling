# Configure DKIM for B2C Commerce

_Major email providers, including Google, Microsoft, and Yahoo, now require DomainKeys Identified Mail (DKIM) authentication. Configuring DKIM is essential to ensure that your emails reach customer inboxes and aren’t rejected or flagged as spam. Configure DKIM to verify that the emails come from the domain that they claim to be from._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Generate a private-public key pair, a .p12 key, for DKIM. See [b2c_generate_private_key.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_generate_private_key.htm&type=5).
2. Import the .p12 key for DKIM.

   1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Private Key and Certificates**.
   2. Click **Import**, and then select the p12 key.
   3. Provide an alias and, optionally, a password. Save the key.
3. Enable DKIM and specify a DKIM selector in Email Settings.

   The DKIM selector is a unique, user-defined string within the DKIM email signature that references a specific public key within your DNS records. It’s used to differentiate multiple DKIM keys on the same domain. The selector forms the prefix for your DNS TXT record, which is formatted as: **<selector>._domainkey.<domain>**.
   
   For example, if the email address is **noreply@notifications.example.com** and the selector is **myselector**, the DNS TXT record label is **myselector._domainkey.notifications.example.com**.
   
   1. In **Administration > Operations > Email Settings**, select **Enable DKIM**.
   2. For Private RSA key, select the .p12 key that you imported.
   3. Enter a name for the DKIM selector.
   4. Click **Apply**.
   
      Keep these considerations in mind.
      
      - The domain isn’t manually configured. Instead, it’s the same domain used when sending email. For example, **noreply@notifications.example.com**.
      - An instance can have only one private key and selector, but the same public key and selector can be used across multiple instances.
      - The same private-public key pair can be used across multiple domains, even on the same instance.
      
      This diagram shows that an instance has only one active private key and selector at a time for DKIM. But this single private key can be associated with multiple hostnames via the Manage Hostnames interface.
      
      _(image: A private key can be associated with multiple hostnames.)_
      
      This image shows that all storefronts share the same underlying private key configured on the same instance. When hosting multiple storefronts on the same production instance, you must duplicate the public DNS TXT records for each unique subdomain.
      
      _(image: Multiple storefronts can share the same private key configured on the instance.)_
4. Configure the DNS record for your email domain in the DNS hosting provider or domain registrar.

   Update the value of the DKIM TXT record entry in your DNS record.
   
   For example, with a selector named **myselector** for the domain **notifications.example.com**, enter the TXT entry in the record: `myselector._domainkey.notifications.example.com`
   
   The content of the TXT entry is a long variable.
   
   For example, `"v=DKIM1; k=rsa;" "p=MIIBIjANBgkqhk…`
   
   The TXT record is required to store the public key.
   
   > **Note:** A single string within a DNS TXT record can’t exceed 255 characters. A TXT record can hold multiple strings. If your DKIM record is longer than 255 characters, split it into multiple quoted strings within the same record. To split strings, use double-quoted characters. When an email server queries your DNS, it automatically concatenates those quoted strings into one long, unbroken public key. 1024-bit RSA keys don’t require splitting, but 2048-bit RSA keys do.

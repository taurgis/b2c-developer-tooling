# Follow the Principle of Least Privilege

_The principle of least privilege is a core zero trust concept. Implementing least privilege means that you give users, applications, systems, and other components only the minimum privilege level required to do their job._

Design granularity into the application to allow for separation of responsibilities within an organization. For example, a user account for the sole purpose of checking analytics doesn’t need permission to manage the product catalog. So, the user account only has rights to check Business Manager Analytics. Other privileges, such as managing the catalog, are blocked.

Effectively managed role-based access control (RBAC) makes these implementations possible. RBAC lets you create roles based on a set of permissions. Managing users’ permissions is now as simple as assigning them to their corresponding roles.

Least privilege provides the following benefits.

- Users can’t accidentally perform high-privilege actions without explicit permission.
- Malicious insiders can’t leverage over-privileged accounts to further their attacks.
- Attackers can’t take advantage of poor permissions to make their attacks easier.

For example, all Business Manager users and Open Commerce API (OCAPI) clients are set up with deny-by-default permissions. It's the administrator's responsibility to provide the permissions that allow each user to do their job.

The administrator must also ensure that all users, roles, and permissions are updated and relevant. Regular audits on the accounts can help the process.

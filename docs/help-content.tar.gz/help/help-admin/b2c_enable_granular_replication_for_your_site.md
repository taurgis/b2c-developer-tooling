# Enable Granular Replications for Your B2C Commerce Site

_Turn on granular replications in your staging and production B2C Commerce instances to make small updates to existing content on an as-needed basis._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Feature Switches**.
2. Turn on **Granular Replications Feature**.
3. Click **Apply**.

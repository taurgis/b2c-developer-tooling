# B2C Commerce Hyperforce FAQ

_Salesforce B2C Commerce infrastructure is getting an upgrade. It’s migrating from Salesforce first-party data centers to Salesforce Hyperforce, the next-generation cloud infrastructure platform powered by public cloud technologies._

This effort is a multi-year journey as most other clouds at Salesforce are also‌ migrating to Hyperforce. The move to hyperforce is one of our largest investments in the B2C Commerce product. It demonstrates our commitment to the longevity of this product for many years to come.

**Why is my realm moving?**

Salesforce is committed to the longevity and scalability of B2C Commerce. We invest in the platform to make sure it can scale and meet the needs of your growing organization. To prepare for your organization's continued growth, we occasionally move a customer’s realm to a new, improved infrastructure. This change enables us to upgrade and modernize our infrastructure and continue to provide you with the levels of performance and trust you expect from Salesforce B2C Commerce.

**What is Hyperforce?**

Hyperforce is Salesforce’s next-generation cloud infrastructure platform powered by public cloud technologies. For an overview and general information about Hyperforce, see [Introducing Hyperforce - General Information and FAQ](https://help.salesforce.com/s/articleView?id=000388902&amp;type=1).

**What are some of the benefits of Hyperforce?**

As a Cloud infrastructure, Hyperforce provides these added benefits:

- Data residency: Serve your employees and customers globally while providing enhanced choice and control for data residency and compliance.
- Scalability: Grow and scale your business more flexibly and sustainably. No more moving realms due to resource scale-up or hardware refresh.
- Security: Hyperforce is secure by default through industry-leading features such as least privileged control, zero trust principles, and Infrastructure-as-Code. Your data is encrypted in transit and at rest.
- Privacy: Hyperforce provides comprehensive privacy standards that enable transparency and control of your customers’ data

**To which region is my realm moving?**

Your new Hyperforce realm is in the same Salesforce region as the current POD location.

**Where are the physical locations of the assigned Hyperforce AWS regions?**

- us-east-2 — US East (Ohio)
- ap-northeast-1 — Tokyo, Japan
- eu-north-1 — Stockholm, Sweden
- ap-southeast-2 — Sydney, Australia
- ap-south-2 — Hyderabad, India

**Is there a schedule for moving realms to Hyperforce?**

Salesforce is scheduling existing customers to upgrade to Hyperforce over the next couple of years, beginning in Q4 of 2024. As the upgrade date approaches, Salesforce notifies you 60 to 90 days in advance of your scheduled move date.

At least one month ahead of the move date, customers receive a pre-move checklist and instructions. Use the checklist to make sure your realm is ready to migrate to the Hyperforce infrastructure. On the move date, Salesforce engineers move all realm data, including certificates, to the new Hyperforce location. During the move, the storefront enters maintenance mode. You’re restored to normal operation after the move completes.

**Will the currently allowlisted IPs in the existing source POD be automatically migrated to the new servers?**

Yes. All existing firewall rules are copied from the source Pod to the new Hyperforce destination.

**As a customer, what do I do to prepare for the move?**

After the realm move date is finalized, you’re asked to prepare for your realm move to Hyperforce. Salesforce provides a checklist and detailed instructions that walk you through the key steps to configure your services and make sure you experience a smooth upgrade.

**How long does it take to complete the move?**

The realm move happens during a predefined maintenance window. The migration of realm data (measured from when the maintenance page is up to when the maintenance page is removed) usually takes 2–5 hours. Actual migration time depends on how much data is moved.

**Are other Salesforce Clouds moving to Hyperforce, too?**

All other Clouds at Salesforce are‌ upgrading to Hyperforce.

**Are new customers hosted on Hyperforce?**

New customers to Salesforce’s B2C Commerce platform run on Hyperforce. This process is gradual, as we build up the capacity on Hyperforce.

**Is the first-party POD environment going away?**

After all customers’ realms are migrated to Hyperforce infrastructure, the current first-party POD environments are decommissioned.

**If we have integrations with other clouds, such as Marketing Cloud or Service Cloud, do we have to make any changes?**

Check all integrations to make sure that they’re working after the POD move. Most cross-cloud integrations use domain names to connect, which don’t change with a POD move. Cross-cloud integrations don’t use a direct IP to connect. However, some endpoints such as Marketing Cloud Personalization can be impacted. If API calls are no longer successful after Pod migration, add the new destination Hyperforce Region IPs to your firewall rule allow list. The Hyperforce external IP list is available at [https://ip-ranges.salesforce.com/ip-ranges.json](https://ip-ranges.salesforce.com/ip-ranges.json).

**Does my development environment (sandboxes) move to Hyperforce, too?**

On-Demand Sandboxes (ODS) don’t move with your realm. No action is needed if you’re using ODS. If you still use the B2C Commerce Sandbox (aka POD sandbox), Salesforce is de-provisioning them and replacing them with ODS.

**Do my B2C Commerce functionality and performance remain the same on the new instance?**

After the upgrade, ‌overall B2C Commerce functionality, performance, and user experience remain unchanged.

**Can my realm be moved sooner or later than the scheduled date? **

There are many realms to upgrade and migrate. After a date is selected, it’s difficult to reschedule. If you have specific needs or requirements regarding the upgrade to Hyperforce, contact your Account Executive (AE) or Customer Success Manager (CSM) as early as possible.

**What can I expect to happen next?**

When your realm is near the scheduled move date, you’ll receive a notification. The notification includes the move date and the pre-move checklist. Use the checklist to get your realm ready for the move. Salesforce asks that you respond to the notification to confirm the date and to ask questions.

**How can I get more information about Hyperforce in general?**

Explore these links to ‌learn more about Hyperforce.

- [Salesforce Hyperforce POV](https://www.salesforce.com/products/public-cloud-infrastructure/)
- [Introduction to Hyperforce YouTube Video](https://www.youtube.com/watch?v=DIqZPxLl2Xw)
- [Introduction to Hyperforce - General Information and FAQ](https://help.salesforce.com/s/articleView?id=000388902&type=1)

If you have questions not addressed in this FAQ, send them to b2c-hyperforce@salesforce.com, or contact your AE or CSM.

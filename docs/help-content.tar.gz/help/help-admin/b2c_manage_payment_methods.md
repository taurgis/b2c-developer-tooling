# Manage Payment Methods for B2C Commerce

_Manage Checkout and Express Checkout payment methods for your Storefront Reference Architecture (Salesforce Reference Architecture (SFRA)) or Composable Storefront site._

|  |
| --- |
| Available in: **B2C Commerce** |

# Install the Salesforce Payments Plug-In for a B2C Commerce Salesforce Reference Architecture (SFRA) Site

_The Salesforce Payments plug-in supports multiple payment methods and third-party payment gateways, streamlining a shopper’s checkout experience. To set up the Salesforce Payments plug-in for a B2C Commerce Storefront Reference Architecture (SFRA) site, make sure you have access to the Salesforce B2C Commerce repositories on GitHub._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Confirm that you can access the [Salesforce CommerceCloud](https://github.com/SalesforceCommerceCloud/) repositories on GitHub.

   For more information, see [Get the SFRA Repositories from GitHub](https://developer.salesforce.com/docs/commerce/sfra/guide/b2c-build-sfra.html#get-the-sfra-repositories-from-github).
2. Clone or download the `plugin_salesforcepayments`repository to your local system.

   The plugin_salesforcepayments repository is compatible with SFRA v7.0 and later. Donʼt install plugin_commercepayments, which retires in a future version.
   
   In your directory structure, make sure that the SFRA base and plug-in repositories are next to each other, as siblings. If you nest the repositories, you can’t use the build scripts.
   
   For more information, see the README section of the repository.
3. To build the cartridge, run the `npm run build` command from the top-level folder of the `plugin_salesforcepayments` directory.
4. In the `dw.json` file, edit the hostname, username, password, and code version. If the file doesnʼt exist, create it.

   The `dw.json` file establishes the server connection and the code version to upload the cartridge. The code version must match the SFRA deployment in Business Manager.
   
   For more information, see [Upload Code for SFRA](https://developer.salesforce.com/docs/commerce/sfra/guide/b2c-build-sfra.html#upload-code-for-sfra).
5. To upload the cartridge, run the `npm run uploadCartridge` command from the top-level folder of the `plugin_salesforcepayments` directory.
6. In Business Manager, set up the cartridge path.

   1. Click App Launcher _(image: App Launcher)_, and then go to **Administration > Site > Sites > Manage Sites** and select your site.
   2. In Settings, update the cartridge's path name.
   
      Example: plugin_salesforcepayments:app_storefront_base
   3. Click **Apply**.
7. In Business Manager, click App Launcher _(image: App Launcher)_, and then go to **Administration > Site > Site Development > Code Deployment** and activate the code version listed in the `dw.json` file.

To integrate and further customize Salesforce Payments into your SFRA site, you can use script APIs. See [dw.extensions.payments](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/scriptapi/html/api/package_dw_extensions_payments.html).

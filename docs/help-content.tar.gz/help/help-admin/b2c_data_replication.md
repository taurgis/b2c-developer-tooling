# Data Replication in B2C Commerce

_Data replication copies data, metadata, and files from staging to a development or production instance. This topic applies to B2C Commerce._

## Related Content

- [Data Replication Processes in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_replication_processes.htm&type=5)
  Each data replication process copies data, metadata, and files or reverts the most recent data replication copy. This topic applies to B2C Commerce.

- [Create a Data Replication Process in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_create_data_replication_process.htm&type=5)
  Trigger a data replication process manually, schedule it to run at a specified time or recur at a specified interval, or create a job to run it.

- [Data Replication Tasks in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_replication_tasks.htm&type=5)
  A data replication process includes one or more configurable tasks that handle different types of data.

- [Reading Data Replication Logs in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_reading_data_replication_logs.htm&type=5)
  B2C Commerce logs on the staging and target instances record the progress of data replication processes. Understanding them can help you troubleshoot replication problems. When troubleshooting, first examine the logs on the source instance. If they don’t indicate any failures, check the logs on the target instance.

- [Undo a Data Replication Process in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_undo_data_replication_process.htm&type=5)
  When you undo a data replication, data on the target instance reverts to the values from before the most recent data replication process that included publishing. Only run an undo process after a data replication process of type Publishing or Transfer & Publishing.

- [Business Manager Module Data Replication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_bm_module_data_replication.htm&type=5)
  The tables in this section map the data managed in Business Manager modules to data replication tasks. This topic applies to B2C Commerce.

- [Granular Data Replication](https://help.salesforce.com/s/articleView?id=cc.b2c_granular_data_replications.htm&type=5)
  Granular Replication is meant to complement and enhance existing data replications, and not replace it.

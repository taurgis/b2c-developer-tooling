# Associate an Adyen Merchant Account with B2C Commerce

_To use Salesforce Payments with Adyen, associate your existing Adyen merchant account with your B2C Commerce instance. If you don’t have an Adyen merchant account, obtain one from Adyen first. You can’t create an Adyen merchant account through Salesforce Payments._

|  |
| --- |
| Available in: **B2C Commerce** |

Prerequisites:

- To enable Salesforce Payments and Salesforce Payments — Adyen, contact Salesforce Customer Support.
- In your Adyen account, enter an allowed origin. An allowed origin is required for client-side authentication.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
2. Click **Add Account**.
3. Click **Adyen** and then click **Next**.
4. In the Add Merchant Account window, enter your payment gateway credentials.

   Find the information in your providerʼs dashboard.
   
   1. Select the region, which is the live endpoint that matches your client-side environment.
   2. Select the country where the account-holding organization resides or where the business is legally established.
   3. For Connection Type, select whether this is a test or live account.
   4. Enter your merchant account ID, which you can find on your Adyen account details page.
   5. Enter your client key and API key.
   6. Click **Save**.

# HTTPS / TLS in B2C Commerce

_In HTTPS, the communication protocol is encrypted using transport layer security (TLS) or its predecessor, secure sockets layer (SSL). The protocol is also often referred to as HTTP over TLS, or HTTP over SSL._

Always use HTTPS to protect data as it traverses the network. In the absence of HTTPS, the data is sent in clear text, allowing an attacker to view sensitive information. We recommend that you set the configuration to enforce HTTPS, which redirects incoming pages that use HTTP to HTTPS. Configure the setting per site or for all sites of an instance. When you enforce HTTPS globally, Salesforce B2C Commerce ignores site-level settings. However, if you disable the global preference, the site-specific settings return to their previous values. Because TLS requires server certificates and mutual TLS (MTLS) requires client certificates, you must upload your certificates to your site’s keystore.

You can also configure B2C Commerce to use HTTP strict transport security (HSTS), which instructs web browsers to access your domain using only HTTPS. HSTS also prevents attackers from using downgrade attacks against your site. For extra security, you can enable *preload*, which forces web browsers to open your site in HTTPS the first time it’s requested. If your site contains insecure content and HSTS is enabled, the content doesn’t display on your shoppers' web browsers, making your site impossible to view. It’s important that you make sure that your site is fully secure before enabling HSTS.

You can also disable HSTS, but use this two-step process to avoid business interruption.

1. Allow shoppers to access your site using an insecure connection.
2. Stop your site from sending HSTS in the header.

> **Note:** TLS 1.1 is no longer supported. Merchants must use TLS 1.2, which is the minimum-standard security protocol used by B2C Commerce to align with industry best practices for security and data integrity.

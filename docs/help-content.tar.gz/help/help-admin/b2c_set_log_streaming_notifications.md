# Set Log Streaming Notifications

_Create and update notifications for proactive monitoring of log streaming._

1. In the log streaming setup screen, click **Enable notification**.

   All users in the Edit Permissions list including the primary owner receive notifications.
2. From the Notification Time Interval dropdown, select a time interval.

   In the event an error occurs, an error message and search button appear for each error.
   
   _(image: Enable notifications setting for a log stream)_
3. If you receive an error, click **Search** to debug it.
4. (Optional) To disable notifications for all users, uncheck **Enable notification**.

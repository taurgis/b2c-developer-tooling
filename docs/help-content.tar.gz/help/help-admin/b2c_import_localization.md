# Import Localization in B2C Commerce

_Across all B2C Commerce import feeds, B2C Commerce processes `xml:lang` attributes for all localizable elements the same way._

The `xml:lang` attribute must specify a locale that is present on an instance including the default local. Though the locale can be configured as active or inactive. If the `xml:lang` attribute specifies a locale that doesn’t exist on the instance, the element isn't imported. B2C Commerce logs a data error to the import log.

# Salesforce Payments Settings for B2C Commerce

_Use the B2C Commerce Salesforce Payments Settings to configure instance status, payment card capture timing, and payment card credential storage for your site._

## Related Content

- [Set Instance Status for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_set_instance_status.htm&type=5)
  Instance status is the status of payments on your B2C Commerce instance for B2C Commerce.

- [Payment Card Capture Timing for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_card_capture_timing.htm&type=5)
  Capture timing is when a payment is captured and dispersed from the payment issuer to the merchant acquirer for your B2C storefront.

- [Payment Card Credential Storage for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_card_credential_storage.htm&type=5)
  When a shopper authorizes use of saved credentials, the card credential storage indicates how stored credit card credentials can be used. This feature applies to B2C Commerce.

- [Statement Descriptor Settings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_statement_descriptor_settings.htm&type=5)
  A statement descriptor provides banks and credit card networks with a description of the credit card transaction charge. Salesforce Payments adds the description to the shopper’s bank or card statement to identify the source of the charge. When shoppers know the origin of a charge, it reduces payment disputes and chargeback requests. Salesforce Payments supports three statement descriptor settings.

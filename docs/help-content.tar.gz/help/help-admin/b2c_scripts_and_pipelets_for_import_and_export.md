# Scripts and Pipelets for Import and Export in B2C Commerce

_Use B2C Commerce API components for importing and exporting._

| Class or Group | Description |
| --- | --- |
| dw.io.file | Represents file resources accessible from scripting. A path in the file namespace identifies file objects. The file namespace follows this format: (Virtual Path)(Relative File Path). Use this class to create file or directory objects and zip or unzip files. |
| dw.net.HTTPClient | Supports the HTTP methods GET, POST, HEAD, PUT, and DELETE. If a secure connection via HTTPS is established, the used server certificate must be signed by one of the B2C Commerce supported CAs and must not be self-signed. |
| dw.net.FTPClient | Supports the FTP commands CD, GET, PUT, DEL, MKDIR, RENAME, and LIST. The FTP connection is established using passive transfer mode (PASV). The transfer of files can be text or binary. |
| dw.net.FTPFileInfo | This class stores information about a remote file. Use this class to detect if a new export file is in place on a remote machine. |
| dw.net.WebDAVClient | This class supports the WebDAV methods GET, PUT, MKCOL, MOVE, COPY, PROPFIND, OPTIONS, and DELETE. Use the client as shown in the following example. The WebDAV client supports the basic authentication scheme and the digest authentication scheme. The methods of this class don't generally throw exceptions if the underlying WebDAV operation doesn't succeed. Check the result of a WebDAV operation using the methods succeeded(), getStatusCode(), and getStatusText(). This WebDAV client can't be used to access the B2C Commerce server via WebDAV protocol. |
| dw.net.WebDAVFile Info | This class gets information about a remote file. Use this class to detect if a new export file is in place on a remote machine. |

# Secure Storage in B2C Commerce

_Salesforce B2C Commerce stores many types of sensitive information, the most important being credit card details._

## Related Content

- [Credit Card Encryption in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_credit_card_encryption.htm&type=5)
  Credit card encryption, key generation, and re-encryption are automatic in B2C Commerce. B2C Commerce provides the ability to monitor this process for merchants undergoing a PCI audit.

- [Private Keys and Certificates in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_certificates_and_private_keys.htm&type=5)
  In various scenarios, you must import your third-party certificates and private keys into your instance’s keystore. A keystore can store multiple entries, each of which can be of type `PrivateKeyEntry` or of type `TrustedCertificateEntry`. This is similar to the terminology used by `java.security.KeyStore`.

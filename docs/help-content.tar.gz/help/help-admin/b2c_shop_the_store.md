# Shop the Store

_Shop the Store refines search results based on your B2C store’s location and store-level inventory. Shoppers can select a store and start discovering products available at that location or look up a product and then refine their search using the location. Shoppers can filter the Product List Pages to search for products at a particular location using Shop the Store._

For example, Adam, an avid gamer, is eager to play the latest Call of Duty. He checks the online gaming B2C store, finds the nearest physical store, searches for the game and adds it to his cart. He then opts for in-store pickup and starts gaming right away.

With Shop the Store, shoppers retrieve search results based on the store inventory list. Shop the Store can index up to 50 million inventory records. The exact number of inventory records depend on the number of stores and number of SKUs in each store. For example, merchants can index 1,000 stores with 50,000 SKUs in each store or 100 stores with 500,000 SKUs in each store.

In an API request, retrieve up to ten store inventory list IDs using the *ilids* URL parameter.

- If the URL parameter contains multiple store inventory list IDs, the product visibility is determined with an OR condition. For example, show all products available in *store A *or *store B *or *store C*.
- If the URL parameter contains valid and invalid store inventory list IDs, B2C Commerce ignores the invalid inventory list ID and filters search results using valid inventory lists. For example, if the search parameter is*ilids=valid1|valid2|invalid*, then B2C Commerce filters the search or category by valid1 and valid2 store inventory lists.
- If the URL parameter contains invalid store inventory list IDs, the system retrieves the site inventory list or displays an empty search result. For example, if the search parameter is *&ilids=invalid*, then B2C Commerce filters the search or category by site inventory list or displays an empty search result.
- Admins can control the fallback behaviour when there’s no store inventory list, using the Shop the Store Inventory Fallback feature switch.
   
   - If the switch is enabled, the system retrieves the site inventory.
   - If this switch is disabled, the site displays an empty search result. See [Set Feature Switches (Toggles) in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_feature_switches.htm&language=en_US&type=5).

### Shop the Store Limitations

- Enable Shop the Store for a maximum of ten sites stores per instance.
- Shoppers can’t sort products based on inventory data. For example, shoppers can't sort the search results by fastest-selling products. However, shoppers can sort products based on price or brand. To give the best experience to your shoppers, create sorting rules with nonavailability related attributes. See [Sorting Rules for B2C Commerce. ](https://help.salesforce.com/s/articleView?id=cc.b2c_sorting_rules.htm&language=en_US&type=5)
- Einstein product recommendations and search suggestions aren't filtered by the availability status of a selected store. When a shopper selects a store from the store locator, some suggested products can be available online but not at that store.
- The Show Orderable Products Only search preference controls whether unavailable products appear in search results at the site level. However, when Shop the Store is enabled, the search results consider both site and store inventory.
   
   For example, consider a shopper searching for a Men's Leather Jacket that has two product variations: Black, which is available in online, and Brown, which is out of stock online, but available in Store XYZ.
   
   If Shop the Store is enabled and is configured to check Store XYZ inventory, the search results show both product variations: Black, available online, and Brown, available in Store XYZ.

## Related Content

- [Enable Shop the Store](https://help.salesforce.com/s/articleView?id=cc.b2c_enable_shop_the_store.htm&type=5)
  Enable Shop the Store for up to ten B2C stores. With this feature, shoppers can search in-store inventory online. Either import store inventory lists or integrate with Omnichannel. Shoppers can then browse store-specific inventory and conveniently pick-up purchases from a preferred location.

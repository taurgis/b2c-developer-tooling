# Account Manager Audit Log Events

_Log Center publishes audit log events for Account Manager, including changes to users, API clients, and organizations. Use filters and keyword searches to track specific field changes or action events within a selected time frame._

Audit events are available in Log Center for 90 days, after which they're automatically deleted.

> **Note:** Audit logs are also available in the previous Account Manager location until the September 23, 2026 release. To retain historical data, download your Account Manager logs before that date.

### Before You Begin

Access to audit events depends on your role:

- **Log Center External Administrator role**: View all audit events across the organizations that you belong to.
- **All other users**: View audit events related to your own account, including events where you're the target or the actor.

To view entity details linked from audit events, you also need the Account Administrator or Read-Only Account Administrator role in Account Manager.

### Access Account Manager Audit Log Events

> **Note:** Account Manager audit log events are only available in the Americas (AMER) region. If you don't see **Account Manager Audit** in the **Events** tab, check the region selector in the top-right corner of Log Center and select **AMER**.

To access the Account Manager Audit Log Events page directly, select the **Go to Log Center** link in Account Manager. Or, follow these steps from a browser or Business Manager.

1. Open Log Center from a browser or from Business Manager. For details, see [View Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_start_log_center.htm).
2. In the top-right corner, confirm that the region is set to **AMER**. If not, select **AMER** from the region selector.
3. Select **Account Manager Audit** from the **Events** tab.
4. (Optional) After filtering for the Account Manager audit events that you want, select **Download CSV** to export the data.

_(image: Log Center Events page with Account Manager Audit selected.)_

### Understand Key Fields

**Target ID**

The Target ID identifies the Account Manager entity that was modified. Targets can be a user, an API client, or an organization.

For security, Log Center shows only IDs, not email addresses. Select the provided link to view full details in Account Manager.

**Actor ID**

The Actor ID identifies the entity that performed the action. Actors can be a user or an API client. Select the provided link to view full details in Account Manager.

**SystemUser** is a special actor that represents automated background actions, such as scheduled processes or system-triggered updates, that occur without direct user intervention.

**Organization context**

Filter by organization name to view changes to entities belonging to that organization and changes to the organization itself. This filter is most useful if you're an admin in multiple organizations.

**Event attribution**

- **User changes**: Changes to a user are attributed to the user's primary organization, regardless of which organization context the change was made in.
- **API client changes**: Changes involving an API client are attributed to each organization that the API client belongs to. If the API client belongs to multiple organizations, the same event can appear in multiple organizations' audit logs.

### Filter Audit Events

| Filter | Use |
| --- | --- |
| **Target Type** | Filter by entity type: user, API client, or organization. |
| **Actor Type** | Filter by actor type: user or API client. |
| **Event Type** | Filter by action type, such as create, update, delete, or role assignment. |
| **Role Assignment** | Filter by the role involved in a role assignment or role tenant filter change. |
| **Organization Membership** | Filter by the organization involved in a membership change. |

To filter by tenant or to search for text within event messages, use the keyword search bar. No dedicated tenant filter exists, so keyword search is the recommended approach for tenant-level queries.

### Common Use Cases

**Audit user role changes**

To track all role assignments for users in a specific organization:

1. Filter by **Organization Name** and select your organization.
2. Filter by **Target Type** and select **User**.
3. Filter by **Role Assignment** and select the role that you want to track.

The results show all users who were assigned or removed from the selected role.

**Monitor API client activity**

To review actions performed by a specific API client:

1. Filter by **Actor ID** and select the API client ID.
2. Optionally, filter by **Organization Name** to scope the results to a specific organization.

Review the **Event Types** filter to see which actions were performed.

**Audit organization-level changes**

To monitor changes to organization settings:

1. Filter by **Target Type** and select **Organization**.
2. Filter by **Organization Name** and select your organization.

The results show all changes to the organization's configuration.

**Find events for a specific tenant**

To find all events related to a specific tenant filter, enter the tenant identifier in the keyword search bar.

**Search by keyword or field value**

To search for specific field values across all events, use Log Center Query Language (LCQL).

1. Select **LCQL** at the top of the page.
2. Select a field and enter the value to search for in the parentheses.
3. For role names, enter each role name as it appears in the [Account Manager roles](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_roles.htm) documentation.
4. To add more field conditions, type a space, choose **AND** or **OR**, then select the next field.
5. Select **Search**.

_(image: Log Center Query Language search for a specified Message.)_

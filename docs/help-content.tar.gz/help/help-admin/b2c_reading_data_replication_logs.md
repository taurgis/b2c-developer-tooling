# Reading Data Replication Logs in B2C Commerce

_B2C Commerce logs on the staging and target instances record the progress of data replication processes. Understanding them can help you troubleshoot replication problems. When troubleshooting, first examine the logs on the source instance. If they don’t indicate any failures, check the logs on the target instance._

### Logs on the Source (Staging) Instance

To view data replication logs on the source instance, click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Development Setup**, and click the **Log Files** link. Find the logs in `https://[staging_instance_name]/on/demandware.servlet/webdav/Sites/Logs`.

The beginning of the replication process in the logs has a timestamp similar to that of the data replication task.

> **Note:** A single staging log can contain several days worth of events.

This example shows the log entry for the start of a data replication process.

```
[2007-01-15 21:17:12.848 GMT] ISH-CORE-2250: New replication task "1168895828901" in domain "Sites-Site" successfully created.
```

This example shows the process gathering `stats` for all tables.[2007-01-15 21:27:06.602 GMT] ISH-CORE-2070: SQL (64ms, rows=1): begin dbms_stats.gather_table_stats(user,'PRODUCTOPTION_AV$1', method_opt => 'for all indexed columns', cascade =>TRUE); end;

These example lines show how `rsync` prepared the source file system directories for copying to the target instance.

```
2007-01-15 21:27:08.317 GMT] StagingGroup: Site specific content search index (Relative directory: search/content)
```

```
[2007-01-15 21:27:08.317 GMT] ISH-CORE-2486: Synchronize Files of unit 'Sites-customer-Site' in site 'Sites-customer-Site' to exchange directory at '/remote/aaas/staging/stg'.
```

```
[2007-01-15 21:27:08.318 GMT] Executing command: /build/2.0.0/system/bin/synchronize.sh /remote/aaas/aaas_stg/sharedata/sites/Sites-Customer-Site/1 /search/content/ /remote/aaas/staging/stg/Sites-Customer-Site/search/content/ ()
```

```
[2007-01-15 21:27:08.402 GMT] rsync debug (/usr/bin/rsync -tr --delete /remote/aaas/aaas_stg/sharedata/sites/Sites-Customer-Site/1 /search/content/ /remote/aaas/staging/stg/Sites-Customer-Site/search/content/)
```

```
[2007-01-15 21:27:08.476 GMT] ISH-CORE-1956: Files in path 'search/content' of site 'Sites-Customer-Site' are successfully prepared
```

The final step on the staging instance is a hand-off to the target server. This example shows a log entry for a successful process to this point.

```
[2007-01-15 21:27:09.783 GMT] Staging pipeline in live system successfully called.
```

If the replication failed on the staging instance, the log instead has a line similar to this example. See the Troubleshooting Replication topic for next steps.

```
ISH-CORE-2491: Setting state of process with uuid='dC8KAANna1111EOTN9h9md4' from 'StartingStagingProcess' to 'ErrorAcquiringEditingLocks
```

### Logs on the Target (Development or Production) Instance

To view data replication logs on the target instance, click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Development Setup**, and click the **Log Files** link. Find the logs in `https://[target_instance_name]/on/demandware.servlet/webdav/Sites/Logs`

This example shows the initial log entry on the target instance for a data replication process.

```
2007-01-15 20:29:30.321 GMT] Copy staging process with uuid=bcFvkiaalTMxM444667bVYFqBX[2007-01-15 20:29:32.347 GMT] Starting StagingResources-Acquire@Sites-Site (
```

These examples show log entries for the start of database transactions for various data replication tasks. An error message following this type of entry can indicate failure of that task.

```
[2007-01-15 20:30:20.296 GMT] ISH-CORE-2070: SQL (123ms, rows=1): INSERT /*+ APPEND */ INTO CATALOG$1 dest SELECT CATALOGDOMAINID,ID,TYPECODE,STATUS,PROXYFLAG,STARTMAINTENANCE​,ENDMAINTENANCE,POSITION,UUID,OCA,DOMAINID,​LASTMODIFIED FROM CATALOG$S src WHERE src.DOMAINID NOT IN('bcIxgiaalXEYQ2223334N9rLDa')
```

```
[2007-01-15 20:30:20.665 GMT] ISH-CORE-2070: SQL (369ms, rows=0): TRUNCATE TABLE CATALOGSITEASSIGNMENT$1 REUSE STORAGE
```

```
[2007-01-15 20:30:20.769 GMT] ISH-CORE-2070: SQL (100ms, rows=1): INSERT /*+ APPEND */ INTO CATALOGSITEASSIGNMENT$1 
```

This example shows a log entry for the switch from a temp table to the source table, which happens after the data copy. An error message here can indicate a problem with this step.

```
[2007-01-15 20:35:43.935 GMT] ISH-CORE-2300: <dbms_output> Switching synonym PRODUCT_AV from PRODUCT_AV$2 to PRODUCT_AV$1...
```

This example shows the final log entry for a successful data replication process.

```
[2007-01-15 21:31:17.434 GMT] ReplicationPublication process finished with state 'StagingProcessCompleted'.
```

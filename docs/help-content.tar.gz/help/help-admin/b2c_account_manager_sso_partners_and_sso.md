# Partners and Single Sign-On to Salesforce

_Your company security policies drive partner login through your IDP (Identity Provider). Some IDPs offer guest logins that don’t require a license. Alternatively, your partners can log into B2C Commerce apps with their existing Account Manager credentials._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Caution:** Shared credentials invite the extreme risk of account takeover and are NOT recommended in any use case. Make sure that your partner users have specific and unique login credentials, whether through your IDP or with Account Manager credentials directly. Additionally, Salesforce prohibits sharing user credentials with multiple users. Before you can satisfy the [multi-factor authentication (MFA) requirement](https://help.salesforce.com/s/articleView?id=xcloud.security_overview_2fa.htm&type=5), resolve any shared accounts or credentials that are in use. This practice is incompatible with MFA because each user must register and connect a unique verification method to their Salesforce account before they can log in. If multiple users are sharing a single account, only one person can log in to that account after MFA is enabled.

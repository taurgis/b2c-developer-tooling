# Managing Attributes via a Backend System in B2C Commerce

_If you use a backend catalog management system to define attribute data or new product attributes, use catalog import to import new product attribute definitions into B2C Commerce. Also make sure that attributes managed via the backend system can't be edited in Business Manager._

### Useful Elements for Managing Attributes

In the catalog.xsd, the product-attribute-definitions element uses the complexType.AttributeDefinitions type, which contains two useful elements:

- `externally-managed-flag` - used to indicate that the custom attribute values are externally managed and can't be edited in Business Manager.
- `externally-defined-flag` - indicates whether the custom external system manages the custom attribute definition and then imports it into our system. This element is intended for merchants using Catalog Management Systems, where they manage their catalog data along with product meta data. Attribute definitions imported along with catalog information are implicitly marked as `externally-defined`. There’s no way to set the `externally-defined-flag` in Business Manager.

> **Note:** Although most metadata attributes can be set when creating a product attribute definition, the following attributes can only be set via Business Manager:
> 
> - `order-required-flag`
> - `searchable`

### Product Object Custom Attribute Definitions

Custom product attribute definitions created in the catalog import can't be searchable or order-required. To prevent unintended changes to the storefront, change these attribute settings after catalog import.

> **Note:** Carefully consider whether the new attributes can affect your cart, checkout procedure, or order information.

## Delete and Create Custom Product Attribute Definitions in a Single Feed

_Delete obsolete attribute definitions and create attribute definitions in a single feed using the `product-attribute-definitions` element._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In UX Studio, in the pipeline that you use to import your catalog, locate the ImportCatalog pipelet.
2. In the ImportConfiguration parameter, enter `{importAttributeDefinitions:true}`.

   If this option isn't set, the import process ignores the product-attribute-definition element and generates an error in the import log.
3. From your backend system, generate a feed based on the catalog.xsd that has the following:

   - a `product-attribute-definitions` element for each new attribute definition you want to create.
   - To remove a product attribute definition that is externally defined, make sure that it isn't included in the feed. Whether you’re importing with the UPDATE, MERGE, or REPLACE mode, the replace semantic is always used for `product-attribute-definitions` element, so the import removes any attribute definitions flagged externally defined in the database and not defined in the import file.
4. Import the feed via a job.

   Importing the feed manually in Business Manager ignores the `product-attribute-definitions` element when you import the feed manually.

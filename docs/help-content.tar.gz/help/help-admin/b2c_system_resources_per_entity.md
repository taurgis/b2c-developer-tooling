# Locking System Resources during Job Execution

_When you create a job, prevent another job from modifying system resources while your job is executing. To know which system resources to assign to the job, know which resources are related to which entity. For example, if your job modifies customers, assign the system resource profile to your job because customers are related to the profile system resource. When your job is executing, another job can't modify the profile system resource and unexpectedly change the outcome of your job. Resource locks are re-entrant locks. In other words, if a job locks a resource, job steps in that job can lock the same resource again. The product index Rebuild task doesn't require any resource locks except itself. However, the product index update task requires resources locks on Product, Catalog and Category. This topic applies to B2C Commerce._

The following table shows which resources an entity update affects. If your job modifies the entity, you assign the associated system resource to the job, so your job locks the resource while it executes and another job can't modify it.

| Entity | System Resource |
| --- | --- |
| Content Library | content, folder, and library |
| Customer | profile |
| Customer List | customerlist |
| Product List | productlist |
| Customer Group | customergroup and profile |
| Custom Objects | customobject |
| Catalog | catalog, product, and metadata |
| Price Book | pricebook |
| Inventory List | inventory |
| Order | address and order |
| Tax Table | taxation |
| Shipping Method | shipping |
| Payment Method | paymentmethod |
| Search Settings | searchindex |
| Gift Certificate | giftcertificate |
| Source Code Group | sourcecode |
| Store | store |
| Content Slot | slot |
| Meta Data | metadata |
| Job Schedules | schedule |
| Services | service, servicecredential, and serviceprofile |
| Site | site Site import also affects resources for each element of the site that is imported. For example, a site import that contains stores locks the store resource. |

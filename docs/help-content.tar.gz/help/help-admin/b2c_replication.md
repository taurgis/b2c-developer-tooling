# Replication in B2C Commerce

_Replication securely copies selected storefront data or a code version from a staging instance to a development or production instance on your Primary Instance Group (PIG). It’s a two-step procedure that first transfers the data or code version, then publishes the data or activates the code version. This topic applies to B2C Commerce._

## Related Content

- [Replication Processes in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_replication_processes.htm&type=5)
  A replication process performs a replication or rolls back a previous replication. You can run a replication process manually, or schedule it to run automatically in B2C Commerce.

- [Replication Best Practices in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c__replication_best_practices.htm&type=5)
  When defining and running replication processes, follow these recommendations. This topic applies to B2C Commerce.

- [Code Replication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_code_replication.htm&type=5)
  Code replication transfers a code version from staging to a development or production instance and activates it on the target instance. This topic applies to B2C Commerce.

- [Data Replication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_replication.htm&type=5)
  Data replication copies data, metadata, and files from staging to a development or production instance. This topic applies to B2C Commerce.

- [Page Cache and Replication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_page_cache_replication.htm&type=5)
  Both code and data replication have page cache implications. Certain replication tasks automatically invalidate and refresh the cache. There are other times where you clear the cache manually.

- [Troubleshooting Replication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshooting_replication.htm&type=5)
  These tips can help you troubleshoot some common replication issues. This topic applies to B2C Commerce.

# Create Inventory Lists and Records

_Use Business Manager to create inventory lists and records. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

If you use Salesforce Omnichannel Inventory, then you can’t create or modify individual inventory records in B2C Commerce.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Inventory**.

   If you see unavailable fields, you have read-only permission. You can search for inventory lists and view their details. You can't modify, delete, or create inventory lists. If you have mixed permission to access one module (via different roles), the higher-level access is granted. See your administrator if you require write access.
   
   For read-only access, the role still needs the functional permissions, either `Manage_Inventory` (for all inventory lists globally) or `Manage_Site_Inventory` for selected sites.
2. On the Inventory Lists page, click **New** to create an inventory list.

   To edit an existing inventory list, click the inventory list ID or click **Edit** beside the inventory list ID.
3. On the General tab:

   1. Enter the ID and a description.
   2. Select **Default In-Stock** to set all products as available (in-stock) that 's not contained in the inventory list of the current site.
   3. To determine a product bundle’s availability using its inventory record instead of the records of the bundled products, select **Use Bundle Inventory Only**.
   
      Use this option to allow a bundle to be available regardless of whether its bundled products are separately available.
   4. Select **On Order Inventory Enabled** if you want to activate inventory soft allocation for orders. If selected, inventory transactions are finalized during order export instead of during order creation.
   
      This setting isn’t compatible with Salesforce Omnichannel Inventory.
4. On the Attributes tab, you see attributes once you have defined custom attributes.
5. On the Site Assignments tab, select one or more sites.

   A site can use only one inventory list to determine availability data. However, an inventory list can be assigned to multiple sites to share its availability data.
6. On the Records tab, select **In Inventory List** and click **Find**.

   A list of products included in the inventory list appears.
7. To assign records:

   When using Omnichannel Inventory, you can’t create or modify individual inventory records.
   
   1. Select **Not in Inventory List** and click **Find**.
   
      A list of products from which you can select appears.
   2. Click a product ID.
   3. On the product details page, click the **Inventory**tab.
   4. Click **Create** beside a product for which you want to add an inventory record.
   5. On the New Record page, select **Perpetual** and specify a value for Allocation.
   
      To use the `Is Available` option in your storefront, set each product's Perpetual flag.
   6. Click **Create**.
   7. Specify the inventory record settings: pre-order and backorder handling and allocation and in-stock date.
   8. Click **Apply**.
   9. Click **<<Back** to return to the Inventory Lists page for the product.
   10. If not assigned, assign the inventory list to a storefront site.
8. On the Inventory Lists page, click the **History** tab.

   If you have enabled change history for inventory lists, you see the creation date and the date of the last update.
   
   Following this information, you see a link that shows the change date, user ID, and the number of changes.
   
   To see more details, click this link:
   
   - Date and time
   - User ID
   - Action: see the update actions in Viewing Change History.
   - Object: see the objects that 's updated per action in Viewing Change History.
   - Scope: inventory lists affected
   - Show details link: click to see metadata details.

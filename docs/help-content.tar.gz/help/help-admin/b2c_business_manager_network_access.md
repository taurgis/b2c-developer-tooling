# Business Manager Network Access in B2C Commerce

_To limit network access to Business Manager, configure security controls to restrict access to specific IP addresses or ranges. The intent of setting these network access restrictions is to lock out attackers who obtained valid credentials through illegitimate means. To enable this functionality, you can specify a range of allowlisted IP addresses allowed to access Business Manager and a range of blocklisted IP addresses not allowed to access Business Manager. If an IP address is blocklisted and allowlisted, it’s denied access._

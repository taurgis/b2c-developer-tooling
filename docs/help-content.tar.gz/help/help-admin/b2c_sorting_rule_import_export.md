# Sorting Rule Import/Export in B2C Commerce

_The sort.xsd schema defines sorting rules, dynamic attributes, and sorting options. This topic applies to B2C Commerce._

**Validation**

In addition to schema validation performed on the XML, logical validation is also performed during the import process.

The following error conditions result in a <dynamic-attribute> or <sorting-rule> element being skipped, and an error message appearing in the import log:

- An attribute-id attribute value for a <sort-by-product>, <sort-by-product-active-data>, or <sort-by-product-availability-model> element doesn't refer to the ID of a known attribute for the corresponding system object type
- An attribute-id attribute value refers to the ID of an attribute of an unsupported attribute type, for example, password.

The following error conditions result in a <sorting-rule> element being skipped, and an error message shown in the import log:

- An attribute-id attribute value for a <sort-by-dynamic-attribute> element doesn't refer to the ID of a known dynamic attribute.

The following error conditions result in a warning message shown in the import log:

- A <sorting-attribute> element has an include-text-relevance XML attribute that isn't supported for its type, such as <sort-by-text-relevance>.
- A <sorting-attribute> element doesn’t have an include-text-relevance XML attribute that is supported for its type, such as <sort-by-dynamic-attribute>.

If text relevance isn’t specified in the XML for a sorting attribute of a type that supports it, no default text relevance is specified.

The following error conditions result in a <rule-context> element being skipped, and an error message shown in the import log:

- The rule-id attribute value doesn't refer to the ID of a sorting rule for the site.
- The category-id attribute of the <category> element doesn't refer to the ID of a category in the catalog assigned to the site.

The following error conditions result in a <storefront-option> element being skipped, and an error message shown in the import log:

- The rule-id attribute value doesn't refer to the ID of a sorting rule for the site.

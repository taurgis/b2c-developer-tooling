# Revert Users from Unified Authentication

_With Unified Authentication, your users can log into Business Manager via Account Manager. Unified Authentication streamlines the login process and reduces the number of login credentials the users have. You can't revert migrated users to the Business Manager login using Business Manager. Instead, to revert affected users, export the users, modify the file, and reimport the users. This applies for administrators who are manually migrating users to unified authentication. This doesn’t apply to administers who started using B2C Commerce after October of 2019 because their organizations automatically use unified authentication._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Export the affected users using Site Export.
2. To delete all affected users, import the file in [delete mode](https://help.salesforce.com/s/articleView?id=cc.b2c_import_modes.htm&type=5).
3. Remove the external id from the affected users.
4. Set a password for the affected users.
5. Reimport the updated file.

   The users can now use the Business Manager login.

Users are required to reset their password upon their next login.

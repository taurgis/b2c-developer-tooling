# Select Contact Users to Receive Account Manager Security Notification Emails

_Select up to five contact users to receive security email alerts about changes in B2C Commerce Account Manager._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. In Account Manager, click **Organization** and select your organization.
2. In the Contact Users field, add up to five users.

   Users must have your organization set as their primary organization. If you remove a user from your organization, they’re also removed from the contact list.
3. Save your changes.

After you configure a contact user, they receive an email notification when any of these events occur:

- User Invitation and Removal
   
   - A user with administrative rights is invited to the organization.
   - > **Note:** These roles are considered administrative and trigger notification emails based on user events.
      > 
      > - Account Administrator
      > - API Administrator
      > - User Administrator
      > - Global Access Administrator
      > - Read-Only Account Administrator (starting with Account Manager 3.6)
   - A user with administrative rights is uninvited (removed) from the organization.
   - An invited user is assigned administrative rights and is automatically uninvited (typically due to shared partner account conflicts).
   - An invited user is assigned administrative rights and is not automatically uninvited (exception cases).
      
      > **Note:** Because partner accounts with shared admin privileges retain admin rights in your organization, they are automatically removed from your organization. The only exception to this removal is if a partner account is also an administrator in your organization. Security contacts receive an email, whether or not the user is removed. We recommend you create a new account for any removed user.

- API and System Access
   
   - An API client with administrative rights is assigned to the organization.

- Settings and Configuration
   
   - Critical organization settings are changed. For example, just-in-time user provisioning or inactive user settings.

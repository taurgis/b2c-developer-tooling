# Buy Now and Pay Later Payment Services for B2C Commerce

_The buy now, pay later payment option for B2C Commerce makes it convenient for shoppers to purchase items in all price ranges. Salesforce Payments offers Buy Now, Pay Later payment through Klarna and AfterPay._

## Related Content

- [Buy Now Pay Later with Afterpay for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_buy_now_pay_later_with_afterpay.htm&type=5)
  Afterpay is available in Salesforce Payments through your Stripe Merchant account as a Checkout payment method. With Afterpay, shoppers make payment in interest-free installments. This feature is available for B2C Commerce.

- [Buy Now Pay Later with Klarna for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_buy_now_pay_later_with_klarna.htm&type=5)
  Klarna is available as a Checkout payment method. With Klarna, shoppers can spread the cost of their order over three or four interest-free payments. To review the countries where Klara is available, see the Stripe documentation. This feature is available for B2C Commerce.

# Purge an API Client from Account Manager

_B2C Commerce Account Manager administrators can purge API clients that are set to the disabled status for seven days or more._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **API Client**.
3. Purge the API client.

   1. In the Action column click **Purge**.
   
      If the purge option isn't available, disable the API client. Allow for the seven day wait period and retry. See [Enable and Disable an API Client ID in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_enable_disable_client_id.htm&type=5).

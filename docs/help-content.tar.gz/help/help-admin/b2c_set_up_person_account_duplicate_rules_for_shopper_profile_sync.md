# Set Up Person Account Duplicate Rules for Shopper Profile Sync

_Configure matching and duplicate rules in Salesforce to prevent duplicate person accounts when Shopper Profile Sync creates or updates shopper records._

1. Log in to your [connected Salesforce org](https://help.salesforce.com/s/articleView?id=cc.b2c_connected_comm_salesforce_connection.htm).
2. Navigate to **Setup > Data > Duplicate Management > Matching Rules**.
3. Click **New Rule**.
4. For Object, select **Person Account** and click **Next**.
5. Fill in the form:

   - Name: Shopper Profile Sync Matching Rule
   - Unique Name: Shopper_Profile_Sync_Matching_Rule
   - Description: Matching rules for Shopper Profile Sync.
6. Under Matching Criteria, add the following fields:

   1. Required (must be present to turn on Shopper Profile Sync):
   
      - Commerce Customer Reference (Exact Match, Match Blank = true)
      - Commerce Organization Reference (Exact Match, Match Blank = true)
   2. Optional (customize based on how you want to deduplicate shoppers; substitute or add other standard or custom fields that are mapped in Shopper Profile Sync):
   
      - First Name (Fuzzy: First Name)
      - Last Name (Fuzzy: Last Name)
      - Email (Exact Match)
7. Click **Add Filter Logic** and enter: (1 AND 2) OR (3 AND 4 AND 5)

   This logic prioritizes matching on Commerce Customer Reference and Commerce Organization Reference first. If no match is found on those fields, the rule falls back to matching on the optional fields. If you change the optional fields in step 5, update this filter logic to match your field numbering.
8. Click **Save**.
9. Click **Activate**.
10. Navigate to **Data > Duplicate Management > Duplicate Rules**.
11. Click **Standard Person Account Duplicate Rule**.
12. Click **Edit**.
13. Under Rule Details, for Record-level security, select **Bypass sharing rules**.
14. Under Actions, set:

   - Action On Create: Allow (no alert, report)
   - Action On Edit: Allow (no alert, report)
   
   > **Note:** These settings control how duplicate person accounts are handled. Choose to allow duplicate person accounts to be created with a warning, or block or prevent creation.
15. Under Matching Rules, select **Shopper Profile Sync Matching Rule**.
16. Click **Save**.
17. Click **Activate**.

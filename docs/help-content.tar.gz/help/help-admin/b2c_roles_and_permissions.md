# Roles and Permissions in B2C Commerce

_We recommend limiting access to modules to only users who use the module. To restrict and grant access to modules, use roles and permissions. When properly configured, a user who logs into B2C Commerce sees only the modules required for their job. This eliminates confusion and increases the security of the organization._

> **Note:** Roles and permissions described here are for Business Manager users only and not for storefront customers.

### Roles

Roles represent groupings of permissions. They're defined in the context of an organization. Assign multiple roles to a user and associate these roles with permissions. A user owns the permissions assigned to each of their roles. B2C Commerce defines sample roles for the SiteGenesis application site, such as the administrator role. This role has permissions on all Business Manager modules below the Administration menu. Create your own roles depending on your specific needs for the site's organization. Check your assigned roles, including instance filters, on the Account Information page in Account Manager.

### Permissions

Configure Business Manager [module permissions](https://help.salesforce.com/s/articleView?id=cc.b2c_bm_module_permissions.htm&type=5) and [functional permissions](https://help.salesforce.com/s/articleView?id=cc.b2c_bm_functional_permissions.htm&type=5). Module permissions include the ability to transfer, replicate, and edit B2C Commerce data. Also let users log in on behalf of a shopper or as a shopper, which is useful for support. Specify read or write access for most data, for one or more sites or across all sites in an organization.

Functional permissions let a user perform specific functions in B2C Commerce. To edit data, combine functional permissions with Business Manager module permissions. You can also grant WebDAV permissions.

To view a list of all users assigned to a specific permission, [audit a permission](https://help.salesforce.com/s/articleView?id=cc.b2c_audit_a_permission.htm&type=5).

### Business Manager Example

This example assumes you have multiple sites and need to assign different levels of permissions for different users.

| User Name | Title | Access Needs |
| --- | --- | --- |
| Marie | VP of Marketing | Views pricing and inventory for all sites. Views content assets for all sites. |
| Traude | Site Merchandiser | View and edit storefront catalog, pricing, and inventory. A site merchandiser is important if there are multiple businesses running on the same realm that don't want to share data. The site merchandiser can only see data for their site, not data for other sites. |
| Lucas | Site Administrator | Can’t view catalog, pricing, or inventory data. Can transfer data via WebDAV. Can replicate data. Can import or export data. Can run jobs. |
| Henry | eCommerce Developer | Needs full access to catalog, pricing, and inventory data across all sites. Permission to transfer data via WebDAV or replicate data. These permissions only function for his sandbox. |

As a first step, create roles.

| Role | Business Manager Permissions | Functional Permissions |
| --- | --- | --- |
| corporate | For each site, add the following site permissions:  Products and Catalogs Content | No permissions assigned. |
| merchandiser | For a specific site, add the following site permissions:  Products and Catalogs Content Search Online Marketing Ordering Analytics | Assign these:  Manage_Site_Catalog Manage_Site_PriceBooks Manage_Site_Inventory |
| site_admin | Add the following organization permissions:  Replication Site Development module, Import & Export and Site Import & Export Operations  For a specific site, add the following site permissions:  All Batch Processes All Import & Export modules | Assign these:  Replication_Run_For_Org WebDAV_Realm_Access WebDAV_Manage_Customization WebDAV_Transfer_Files |
| developer | All Site Development modules Operations - Custom Log Settings, Pipeline Profiler | No permissions assigned. |

After you have created the roles, assign users to them.

| Role | Permissions |
| --- | --- |
| Marie | corporate |
| Traude | merchandiser  If you wanted Traude to be able to view prices and inventory for all sites, but only be able to edit the data for her site, you can also add her to the corporate role. |
| Edward | support_rep |
| Lucas | site_admin |
| Henry | developer |

## Related Content

- [Create a Role in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_roles.htm&type=5)
  A role is a named group of permissions. For example, group all of the permissions related to catalog management into a role called Catalog Manager. Next, assign this role to the user whose job it is to manage the catalog. This topic applies to B2C Commerce.

- [Administrator Role in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_administrator_role.htm&type=5)
  The administrator role is the top-level role for an organization. This role is automatically created and can't be deleted directly or indirectly by import. This topic applies to B2C Commerce.

- [WebDAV Client Permissions](https://help.salesforce.com/s/articleView?id=cc.b2c_web_dav_client_permissions.htm&type=5)
  WebDav client permissions let you configure which API clients can access your WebDAV files. These permissions also give you fine-grained control over which directories each client can access.

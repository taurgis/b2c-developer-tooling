# Generate a Private-Public Key Pair

_DKIM authentication requires you to specify a private key in Business Manager in B2C Commerce. Generate a private key in a terminal with these commands._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. To generate a private key, enter `openssl genrsa -out private.pem 2048`.
2. Convert the private key to the p12 format.

   A p12 (PKCS#12) file is a secure, binary format used to store and transport private keys, public certificates, and intermediate CA certificates in a single, password-protected file.
   
   1. Enter `openssl req -new -key private.pem -out tmp.csr -subj "/CN=dkim01/O=customer"`
   2. Enter `openssl x509 -days 3650 -signkey private.pem -in tmp.csr -req -out "tmp_certificate.pem"`
   3. Enter `openssl pkcs12 -export -inkey private.pem -in "tmp_certificate.pem" -out private_key.p12 -password pass:12345`
3. Export the public key to be published in the DNS. Enter `openssl rsa -in private.pem -pubout -out public.pem`

# Set HSTS for Business Manager in Global Preferences

_HTTP Strict Transport Security (HSTS) can substantially improve the security of the Business Manager. To secure Business Manager, HSTS instructs web browsers to access the domain using only HTTPS._

|  |
| --- |
| Available in: **B2C Commerce** |

Web browsers check the Business Manager HTTP header for information on HSTS. When the web browser reads a max age for HSTS, the browser doesn't check the header again until the max age has expired. Because a web browser checks the header only after the max age has passed, you can't manually disable HSTS. Change the max age at any time. Update HSTS only on an HTTPS connection. Choosing Cease signals to the User Agent to stop regarding the host as a known HSTS Host.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security**.
2. Select Access Restriction.
3. Select Max-Age.
4. Review and accept the acknowledge message.
5. Select one of the pre-defined values.
6. Click **Apply**.

> **Note:** Enabling HSTS requires this site to fully run HTTPS, having a valid certificate in place. Otherwise, your browser won't be able to access the site anymore. Therefore consider increasing the max-age setting in stages. For example, to make sure access to the instance works properly while having HSTS enabled, consider increasing the max-age value from five minutes, to one hour, to one day to 180 days or more.

# Documentation for the B2C Commerce Preview and GA Releases

_When we release a preview version of B2C Commerce, we update the B2C Commerce Help to reflect new functionality in that preview version. The new functionality isn’t available in production instances for approximately two more weeks, when the preview version of B2C Commerce becomes the GA version._

If you’re using a B2C Commerce production instance during the two-week period before the new functionality is available, the updated information in the Help doesn’t apply to your instance. For information about the new features in the latest B2C Commerce version, with links to updated Help topics, see the [B2C Commerce Release Notes](https://help.salesforce.com/s/articleView?language=en_US&id=commerce.b2c_parent.htm).

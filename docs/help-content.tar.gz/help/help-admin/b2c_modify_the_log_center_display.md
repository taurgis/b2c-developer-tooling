# Modify the Log Center Display

_By default, when you conduct a search, Log Center shows the list of issues in a detailed view. You can also view the list in compact view._

The histogram shows a graph of the number of issues logged in a time interval. The initial time interval is 15 minutes; this interval changes with the time filter. The minimum value for the aggregation interval is 1 minute. “All” represents the aggregated count for all the logs; ‘hits” represents the aggregated count for the result of filters and keyword search.

1. To switch between detailed and compact view, click the appropriate icon next to Display options.
2. To show the number of issues that appear on each page, click the number next to “Hits/page.”
3. To show more pages of issues, click **Older** and **Newer**.
4. To change the included counts, click **All** or **Hits**.
5. To reapply filters, select the value you want and click **Show filtered results**.

# Import/Export Analytics and Reporting in B2C Commerce

_B2C Commerce reports on import and export processes via the Reports & Dashboards Technical dashboard, system logs, and import and export logs. System logs provide general information about the system and APIs. Import and export logs, in contrast, provide information that is specific to import/export processes (whether through Business Manager or via pipelets)._

### Reports & Dashboard Technical Dashboard

B2C Commerce provides the Technical Reports dashboard to give you insights about your site’s server-side technical operations data, including pipelines and controllers.

Download the Technical dashboard data as spreadsheet files.

### System Logs

The system logs, accessible via WebDAV, capture information that is related to API processing, data staging, and error handling. Use the links provided in Business Manager (Administration > Site Development > Development Setup > WebDAV section > Log files). These logs can provide useful information when troubleshooting import and export related issues.

### Import and Export Logs

If you use the `XMLValidation` pipelet to validate your import and export, generate a log. The log is located by default under `IMPEX/log` in your cartridge. Access this log via your WebDAV connection. For example: `https://you.dw.demandware.net/on/demandware.servlet/webdav/Sites/Impex/log`.

To find the name of the log generated for a particular execution of the pipeline, use a breakpoint on the `XMLValidation` node and check the log file attribute.

Not all errors thrown by the import pipelets and logged cause the pipeline processing to stop. It's important to include error handling for some of these exceptions, so that you’re aware of problems when they occur.

B2C Commerce automatically cleans up any log files in the `IMPEX/log` folder 30 days after they were created on Staging and Production instances and 7 days after they were created on Sandbox and Development instances.

# Enhance Site Speed

_Want your customers to love their online shopping experience? Speed up your web store. These speed optimization features help your storefront load faster, so customers spend less time waiting and more time browsing._

### Time to First Byte (TTFB)

Time to first byte (TTFB) is a metric that measures the time between the request for a resource and when the first byte of a response begins to arrive. These request phases represent TTFB:

- Redirect time
- Service worker startup time (if applicable)
- DNS lookup
- Connection and Transport Layer Security (TLS) negotiation
- Request, up until the point at which the first byte of the response has arrived

Reducing latency in connection setup time and on the backend can lower your TTFB.

### Argo

Argo, a Content Delivery Network (CDN) feature, analyzes, and optimizes routing decisions. When a customer visits a storefront, there are many hops between the customer's machine and the eCDN, and then finally the Origin servers. Argo helps find the best route to reach the eCDN. Since implementing ARGO, customers have experienced an average improvement of 20-30%. Argo Smart Routing uses latency and packet loss data collected from each request that traverses the CDN network and identify the optimal paths across the internet. Argo is implemented as part of the B2C Commerce CDN.

### Early Hints

Early Hints are an HTTP status code (103 Early Hints) that helps websites load faster. To increase load speed, an Early Hint sends the browser a preview of the page before the final content is ready. This way, the browser can start a preload of the page while it waits for the server to generate the rest. Early Hints helps decrease page loading times and reduces ‌user-perceived latency.

B2C Commerce’s eCDN is positioned close to end users, which means Early Hints can be delivered quickly. Early delivery significantly decreases the time it takes for the server to generate a page. The eCDN tracks the Time to First Byte from the moment the customer’s browser makes the request until the browser receives the Early Hints. A faster TTFB optimizes performance and enhances user satisfaction.

By using Early Hints, you can improve your web store performance and create a better experience for your users.

### HTTP/2 to Origin

HTTP/2 to Origin uses the HTTP/2 protocol between eCDN and the origin and improves performance between the two. HTTP is a common protocol that has evolved over time. Each version adds new features that improve performance. HTTP/1.1 and HTTP/2 are both widely used on the Internet today. HTTP/1.1 has been around for a long time, but in 2015, the Internet Engineering Task Force introduced HTTP/2, which reduces page load times.

This setting takes effect only when your origin supports HTTP/2. HTTP/2 is backward-compatible. If it isn’t supported, eCDN uses HTTP/1.

### HTTP/3

HTTP/3 is a version of the Hypertext Transfer Protocol that uses Quick UPD Internet Connections (QUIC) as its transport protocol. QUIC uses the User Datagram Protocol (UDP) which is faster than the Transmission Control Protocol (TCP) and supports rapid network switching. This approach mitigates head-of-line blocking which can slow down high-transaction connections. QUIC also separates the layer 4 transport connection from the layer 3 IP flow, allowing for better migration between networks. Network packet loss or reordering can slow down connections that have many transactions.

QUIC is better suited for the way we use the internet today. It's designed for phones and other mobile devices that are constantly switching between networks. The original internet protocols were developed when devices weren't as portable and didn't switch networks as often.

### Brotli

Brotli compression improves the delivery of static text-based web assets such as HTML, CSS, JS, and JSON. To achieve this, it reduces payload sizes, resulting in quicker delivery.

Brotli is the preferred compression algorithm and is used if "br" is present in the HTTP Request Header "Accept-Encoding." To guarantee a gzip response, set the "Accept-Encoding" header to "gzip." If the header includes all options (gzip, br, zstd), eCDN prioritizes Brotli.

When Brotli is disabled, the eCDN defaults to auto compression. In this mode, the optimal algorithm is chosen based on the visitor's browser support and the CDN provider's evolving preferences.

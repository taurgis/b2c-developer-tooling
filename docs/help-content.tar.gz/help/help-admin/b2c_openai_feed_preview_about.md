# About the Product Feed Preview

_The Product Feed Preview shows you the resolved feed data—including missing required fields—before you turn on the daily feed sync. Use it to verify your field mappings, identify products with errors, and download a sample CSV._

The Product Feed Preview is a self-service validation tool on the Catalog tab of the OpenAI configuration page. It applies your field mappings, your product filter rules, and the system-level exclusions to a sample of your catalog, and shows the resulting feed entries. Use the preview to catch field-mapping problems and missing data before the system uploads the feed to OpenAI.

### What the Preview Shows

For each product included in the preview, the system shows the resolved value for every Channel Field in the feed—the same values that the daily feed sync sends to OpenAI. Use the columns in the preview table to spot-check titles, image URLs, prices, availability values, and search and checkout flags.

Products with missing or invalid required fields appear with an error icon. Hover over the icon to see which fields are affected, then return to the Field Mapping section to fix them. See [b2c_openai_feed_mapping.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5).

### Hostname for Non-Production Environments

In non-production environments, product URLs aren't visible in the preview by default. Click **Enter Hostname** and provide the storefront hostname you want the preview to use. After you enter a hostname, the system uses it to construct the **url** column for each product. The hostname applies to the preview only; it doesn't change how the daily feed sync constructs URLs in production.

In production environments, the hostname is pre-populated from the Host field on the Einstein Status Dashboard, and the **url** column is visible by default. See [b2c_openai_feed_configure_einstein.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_configure_einstein.htm&type=5).

### Master Products and Variants

The preview shows master products as expandable rows. Click a master product row to see its variants. The preview shows up to 100 variants per master product. Variants inherit attribute data from their master product unless you override the inheritance with a custom mapping.

> **Note:** The system never includes master products themselves in the feed sent to OpenAI. Master products appear in the preview only as containers for their variants. See [b2c_openai_feed_overview.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_overview.htm&type=5).

### What's Excluded from the Preview

If a product you expect to see isn't in the preview, one of the following exclusions applies:

- **System exclusions**: The system always excludes master products, variation groups, and product sets. Variants and standalone products appear in the feed.
- **Filter rule exclusions**: Products that don't match your include rules, or that match an exclude rule, aren't shown. See [b2c_openai_feed_product_filter.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_product_filter.htm&type=5).
- **Site catalog assignment**: The product isn't assigned to the active catalog for the current site.
- **Variant cap**: Up to 100 variants are shown per master product.
- **Inactive catalogs**: Products in inactive catalogs aren't included.

### Sample CSV Download

To export the resolved feed data for offline review, click **Download Sample**. The system generates a CSV file that contains the resolved feed values currently shown in the preview. Error indicators are visible in the preview UI only and aren't included in the downloaded CSV. Use the CSV to share the feed data with stakeholders or to compare resolved values across catalog updates.

# Payment Methods for B2C Commerce

_With Salesforce Payments, you can offer shoppers Checkout, Express Checkout, or both payment methods on your storefront. If you offer Checkout, shoppers can purchase items using Afterpay, Amazon Pay, Bancontact, credit cards, EPS, iDEAL, Klarna, PayPal, SEPA Debit, TWINT, or Venmo. If you offer Express Checkout, shoppers can purchase items using Amazon Pay, Apple Pay, Google Pay, PayPal, or Venmo._

## Related Content

- [Express Checkout Considerations for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_express_checkout_considerations.htm&type=5)
  Although Express Checkout is often faster and easier to use than the Checkout payment method, features such as coupons, gift wrapping, shopper product customization, and gift card redemption aren’t always a good fit for Express Checkout.

- [Manage Payment Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_payment_methods.htm&type=5)
  Manage Checkout and Express Checkout payment methods for your Storefront Reference Architecture (Salesforce Reference Architecture (SFRA)) or Composable Storefront site.

- [Customize Where Express Checkout Payment Methods Appear on Your Storefront](https://help.salesforce.com/s/articleView?id=cc.b2c_express_checkout_display.htm&type=5)
  Choose where Express Checkout payment methods appear on your Storefront Reference Architecture (Salesforce Reference Architecture (SFRA)) or Composable Storefront site.

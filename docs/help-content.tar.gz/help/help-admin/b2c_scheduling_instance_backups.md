# Scheduling Instance Backups in B2C Commerce

_Schedule instance backups._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Note:** The instance backup is only available for staging instances. To backup a production or development instance, use the job framework and setup a backup in a production or development instance.

1. In Business Manager click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Site Import & Export**.
2. Click **Scheduled Backups.**
3. On the Instance Backup Configurations page, click **New** or select an existing job.
4. On the Edit (or New) Backup Configuration page, enter the relevant information and click **Apply**.

   | Option | Description |
   | --- | --- |
   | Configuration Name | Name of the backup configuration |
   | Enabled | Indicates whether backup configuration is enabled |
   | Job Settings | Max backups to keep (1, 3, or 5) |
   | Job Schedule | When to start, at what time, and how frequently |
5. Select the data to include in the backup. Be as granular or as inclusive as you want.
6. Click **Apply**.

If a staging instance export or backup fails for any reason, Salesforce B2C Commerce still generates a .zip file, but appends the suffix "-invalid" to the filename. Salesforce recommends that you establish a mechanism to detect if an invalid file is produced.

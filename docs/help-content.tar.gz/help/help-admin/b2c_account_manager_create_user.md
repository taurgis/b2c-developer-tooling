# Create a User Account in B2C Commerce

_You must be an account administrator to create an account. Each account must belong to one or more organizations, and you can create accounts only for organizations of which you are a member._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **User**.

   The Users page opens, showing a list of email addresses for all users in your organization (or organizations).
3. Click **Add User**.

   The Email validation page opens.
4. Enter the email address and click **Add**.

   If Account Manager finds an account using the specified email address, you can add the user to your organization. (See [Add an Account to Your Organization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_invite_user_to_organization.htm&type=5).) If Account Manager does not find an account, the Add User page opens, prompting you for additional information.
5. In the Add User page, enter the values for the following fields:

   - Email Address. If your email provider supports subaddressing, you can use a + in the email address field.
   - First Name
   - Last Name
6. (Optional) Enter or select values for the following fields:

   - Business Phone
   - Mobile Phone
   - Home Phone
   - Preferred Language
7. In the **Organizations** section, click **Add** to open the **Assign Organizations** window if you want to change the preselected organization.

   1. Search for organizations, and check each organization to which the account belongs (each account must belong to one or more organizations).
   2. To apply the organizations to the user, click **Add**.
8. In the **Primary Organization** list, select the user's primary organization.

   Only account administrators for the primary organization can manage the user's account.
9. In the Roles section, click **Add** to open the **Assign Roles** window.

   If the user needs to access a Business Manager instance, select either **Business Manager User** or **Business Manager Administrator** under the eCommerce Platform section.
   
   1. Search for roles, and check each role that you want the user to have.
   2. To assign the roles to the user, click **Add**.
   
      Some roles, for example **Business Manager User** or **Business Manager Administrator**, need access to specific sandbox or PIG instances and a role scope is required.
10. If the role needs access to an instance, add a role scope.

   1. Select the filter icon.
   2. In the Add Instance Filters tab, select an organization.
   3. Enter the names for the instances you want the user to have access to.
   4. Select the instances.
   5. Click **Add**.
11. Click **Add**.

   A message is sent to the user's email address, which the user can use to activate their account. See Activate a B2C Commerce Account. The user's email address immediately appears in your list of users.
   
   If the user needs more roles, you can change their roles from the Users tab.

Additional Resources

- [Manage B2C Commerce Users with Account Manager](https://www.youtube.com/watch?v=MaWiLbyC55E&list=PLFNbZmUNjID7UuW9nGFwbNgAVF3yNlu3v&index=5&pp=iAQB)
- [Enable Business Manager User Permissions for B2C Commerce](https://www.youtube.com/watch?v=yIRMhv_EevI&list=PLFNbZmUNjID7UuW9nGFwbNgAVF3yNlu3v&index=6&pp=iAQB)

# Introduction to Roles in B2C Commerce

_In Business Manager, you can perform authentication to determine if the user is who they claim to be. You can also perform authorization to determine if the user has permission to perform the specific action they’re attempting._

The following entities can consume storefront services.

- Shoppers interacting with a site
- API clients (custom code) making calls to the Open Commerce API (OCAPI) Shop API

The following entities can consume Business Manager services.

- Users interacting with Business Manager
- API clients (custom code) making calls to the OCAPI Data API

In each case, consider using a distinct credential per user, such as a password, rather than a single shared credential. In addition to reducing the likelihood of credential theft, the credential process is easier to maintain. If a member leaves the team, you can delete their credentials instead of redistributing a new set of credentials across the team.

# Modify eCDN Exposed Credentials Check Settings

_Deploy an automated credential check on your end-user authentication endpoints. For any credential pair, the eCDN web application firewall (WAF) performs a lookup against a public database of stolen credentials. Created by the CDN security team, this ruleset provides fast and effective protection for all of your applications. The CDN security team updates the ruleset frequently to cover new vulnerabilities and reduce false positives._

Enable the Exposed Credentials Check ruleset.

Select the action to perform. The default is recommended. The available actions include:

- Block (Default)
- Managed challenge
- JS challenge
- Log
- Legacy captcha

When you define an action for the ruleset, you override the default action defined for each rule. To remove the action override, set the ruleset action to Default.

_(image: Embedded CDN Settings)_

_(image: WAFv2 Managed Ruleset Settings)_

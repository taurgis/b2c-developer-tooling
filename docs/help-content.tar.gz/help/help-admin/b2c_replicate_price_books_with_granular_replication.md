# Replicate Prices with Granular Replication

_Replicate specific prices from staging to production._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Price Books**.
2. Select the price book to update.
3. Select the **Price Definitions** tab.
4. Enter the product ID or name.
5. Update the price table entry.
6. Click **Publish**.

   _(image: Click Publish.)_
   
   _(image: Success Message.)_
7. (Optional) You can also access price book data from the Products page.

   1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Products**.
   2. Select the product whose price entry you want to update.
   3. On the Product Details page, select the **Pricing** tab.
   4. Update the price book entry.
   5. Click **Publish**.
   
      _(image: Click Publish.)_

# Security Best Practices for Developers in B2C Commerce

_As a B2C Commerce developer, use these security best practices to develop secure storefronts._

## Related Content

- [Encryption and Cryptography in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_encryption_and_cryptography.htm&type=5)
  Salesforce B2C Commerce extends Salesforce-maintained cryptography libraries that enable you to safely encrypt, sign, and generate cryptographically strong tokens and secure random identifiers. Salesforce maintains industry standard compliance frameworks as noted on the B2C Commerce page on Salesforce’s Trust Compliance website.

- [Cross-Site Scripting in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_cross_site_scripting.htm&type=5)
  Cross-site scripting (XSS) enables attackers to inject client-side JavaScripts into a webpage viewed by a targeted user. To prevent malicious attacks through content manipulation, you must properly encode all user-provided content.

- [Declarative Security via HTTP Headers in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_declarative_security_via_http_headers.htm&type=5)
  You can use declarative security controls as a strong line of defense against client browser-based attacks such as clickjacking and offer built-in browser protection against cross-site scripting (XSS). The OWASP Secure Headers Project describes HTTP response headers that your application can use to increase the security of your application.

- [Content Security Policy (CSP) Configuration](https://help.salesforce.com/s/articleView?id=cc.b2c_content_security_policy.htm&type=5)
  Content Security Policy (CSP) is a security feature that you configure for your storefront. When you implement CSP, you're responsible for making sure that your configuration enables the necessary scripts to run as intended.

- [Commerce Script Injection in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_commerce_script_injection.htm&type=5)
  Server script injection, or remote code execution, is a class of attack where maliciously crafted input is run in a privileged code execution context. This class of attack enables an attacker to control the code executed on the server.

- [Cross-Site Request Forgery in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_cross_site_request_forgery.htm&type=5)
  Every storefront contains some protected requests that require a high level of security protection. Authenticated shoppers who change their accounts or submit personal data to a server to complete an action typically perform these requests. Users expect that they alone make these requests, and only when they specifically initiate the request.

- [Secret Storage in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_secret_storage.htm&type=5)
  Storing and using secrets is one of the most sensitive actions taken by a developer to ensure the security of shopper information. A secret can be, and is not limited to, the following items.

- [Using Hooks Securely in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_using_hooks_securely.htm&type=5)
  In Salesforce B2C Commerce, you can use hooks as a powerful tool to extend default functionality. Like all powerful tools, however, hooks are dangerous if not used properly.

- [Data Validation in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_validation.htm&type=5)
  Validating user input is the basis of application security. Data validation ensures that it is exactly the kind of data that an application expects. B2C Commerce generally rejects invalid requests outright and returns an error to users. Choose where to perform data validation, but we focus on client- and server-side validation.

- [Open Redirect Attacks in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_open_redirect_attacks.htm&type=5)
  When a web application trusts user input as a redirect destination, an attacker can use that input to redirect users to a website that they control and steal their information.

- [Authentication and Authorization Best Practices in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_developer_authentication_and_authorization.htm&type=5)
  Exploitation of access control vulnerabilities is a core skill of attackers. To protect against the attackers, enforce server-side access control checks for business functions such as account management, order management, and purchasing.

- [Supply Chain Security in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_supply_chain_security.htm&type=5)
  Unverified software sources included through uploads and external linking represent potential vectors for attack.

- [Secure Logging in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_secure_logging.htm&type=5)
  Salesforce B2C Commerce logs are stored securely and are accessible only to users in the `site_admin` or `developer` roles. Logs are accessible via the web interface or over WebDAV. Consider this when you decide what types of information to log.

- [General Secure Coding Practices in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_general_secure_coding_practices.htm&type=5)
  Even with all the security controls that Salesforce B2C Commerce provides, poor coding practices can negate these controls and introduce weaknesses. Refer to the OWASP Secure Coding Practices - Quick Reference Guide for general recommendations.

# Gift Certificate Site Preferences for B2C Commerce

_Specify how you want to handle gift certificates within the Business Manager._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Gift Certificates**
2. Enter or select the following settings:

   | Option | Description |
   | --- | --- |
   | Sender Name | Appears on emails sent from Salesforce B2C Commerce to the customer. |
   | Sender Email | Return address. Appears on emails sent from B2C Commerce to the customer. |
   | Email Template | Name of the Internet Store Markup Language (ISML) template used to format the email (or template of your choice). |
   | Gift Certificate Code Masked | Controls whether to export gift certificate codes in clear text or masked.  True: masks all but the first four characters of a gift certificate code False: shows all characters of gift certificate codes in clear text |
   | Export Merchant ID | Controls if the gift certificate merchant ID is exported. |
3. Click **Apply**.

   For example:
   
   |  |  |
   | --- | --- |
   | Sender Name | Customer Support |
   | Sender Email | support@salesforce.com |
   | Email Template | marketing/giftcertificateemail.isml |
   | Gift Certificate Code Masked | True |

# Add Payment Methods to a Payment Zone for B2C Commerce

_To configure how shoppers complete purchases, customize payment methods for each payment zone based on country or currency._

|  |
| --- |
| Available in: **B2C Commerce** |

Before adding payment methods to a zone, make sure that your merchant account has at least one checkout type enabled.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Ordering > Salesforce Payments**.
2. Click **Assign Payment Zone**.
3. Select a **Payment Zone**.
4. Select one or more payment methods for the payment zone.
5. Click **Save**.

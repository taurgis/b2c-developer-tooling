# Edit Alert Settings for B2C Commerce

_An individual user can change the priority of an alert or prevent it from appearing on their homepage or header. This only impacts the notifications for that user._

|  |
| --- |
| Available in: **B2C Commerce** |

Users can mute or change the priority of alerts that appear in Business Manager. They can’t mute Slack alerts or notifications.

1. On the Business Manager homepage, click the pencil icon in the Alerts section.
2. In the Priority column, select a priority from the dropdown menu.

   If you select **Don't Show** for an alert, that alert isn't shown on the homepage or the alerts module.
3. To show the alert in the header or on the homepage, select **Show on Homepage** or **Show in Header**.

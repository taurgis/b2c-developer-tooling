# Legacy Jobs

_We recommend that you use the new job framework to create and manage jobs, but the legacy, deprecated functionality is also available in Business Manager. This topic applies to B2C Commerce._

The new jobs framework has many advantages.

- Use preconfigured steps that require no coding.
- Developers can create custom job steps using their preferred IDE to write a CommonJS module.
- Use flows to set up parallel execution of job steps.
- Start and monitor jobs using OCAPI (Open Commerce API).
- Monitor the progress of jobs in Business Manager.

## Related Content

- [Create a Legacy Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job_legacy.htm&type=5)
  Legacy jobs use pipelines that a developer creates using the UX Studio plug-in to the Eclipse IDE. This functionality is deprecated. We recommend creating jobs using the new job framework.

# Omnichannel Inventory Location Graph Changes

_When you manage inventory with Omnichannel Inventory, changes to the location graph in Omnichannel Inventory require coordinated updates in B2C Commerce. To make any of the changes described here, follow the appropriate steps in order._

> **Note:** Use the Salesforce core APIs or UI to make location graph changes. You can’t modify the location graph with the headless Commerce APIs.

### Best Practices

Adding or removing locations or location groups after loading inventory availability data can trigger large availability data and cache updates. To mitigate the performance impact, we recommend these practices:

- Schedule location graph changes for times with low order traffic.
- Add or remove only one location or location group at a time.
- After making a change, wait for the update to finish before importing new inventory availability data. If you made the change in the Omnichannel Inventory console app, confirm it in the Location Management section.

### Remove a Location or Location Group

To remove a location or location group that’s associated with a B2C Commerce inventory list:

- (B2C Commerce) If the inventory list is assigned to a site or store, assign a different inventory list to that site or store. If it’s assigned to a store, deleting the store can also be an option.
- (B2C Commerce) Delete the inventory list associated with the location or location group.
- (Omnichannel Inventory) Delete the location or location group.

### Add a Location or Location Group

To add a location or location group and associate it with a B2C Commerce inventory list:

- (Omnichannel Inventory) Create the location or location group.
- (Omnichannel Inventory) If creating a location, initialize its inventory data and add it to any appropriate data import processes.
- (Omnichannel Inventory) If creating a location group, add the locations to it.
- (B2C Commerce) Create the inventory list. Make sure that its ID matches the External Reference of the location or location group.
- (B2C Commerce) Open the Omnichannel Inventory Integration Status page and verify that the inventory list is synchronizing with Omnichannel Inventory.
   
   - If the inventory list is associated with a location group, its Location Type and Items Cached values appear on the Status page in a short time.
   - If the inventory list is assigned to a site, its Location Type and Items Cached values appear on the Status page in a short time.
   - If the inventory list is associated with a location and isn’t assigned to a site, its Location Type appears on the status page in a short time. However, its Items Cached value doesn’t appear until after the next overnight data synchronization.
- If the synchronization isn’t working, contact Salesforce Support to attempt to trigger it manually.

### Change the Element Type Associated with an Inventory List

If an inventory list is associated with a location, change it to be associated with a location group, or vice versa. However, we don’t recommend it.

- (Omnichannel Inventory) Change the External Reference of the location or location group currently associated with the inventory list.
- (Omnichannel Inventory) Set the External Reference of the location or location group to associate with the inventory list.
- Contact Salesforce Support and request a refresh of your inventory list.
   
   > **Note:** If you don’t request an explicit refresh, the integration can fail to recognize the change until it causes an error.
- (B2C Commerce) Open the Omnichannel Inventory Integration Status page and verify that the inventory list is synchronizing with the correct target in Omnichannel Inventory.
   
   - If the inventory list is associated with a location group, its Location Type and Items Cached values appear on the Status page in a short time.
   - If the inventory list is assigned to a site, its Location Type and Items Cached values appear on the Status page in a short time.
   - If the inventory list is associated with a location and isn’t assigned to a site, its Location Type appears on the status page in a short time. However, its Items Cached value doesn’t appear until after the next overnight data synchronization.
- If the synchronization isn’t working, contact Salesforce Support to attempt to trigger it manually.

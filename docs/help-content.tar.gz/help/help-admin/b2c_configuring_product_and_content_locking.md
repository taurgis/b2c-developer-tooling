# Configure Product and Content Locking for B2C Commerce

_Define the time (in minutes) for when products or content are locked while editing. During this time, other users can't edit the product record or content asset. The lock (applied before product editing) is released after this time._

|  |
| --- |
| Available in: **B2C Commerce** |

If you lock a base product, Business Manager automatically locks the related variation products, unless locked by another user. This technique reduces the number of clicks required when editing a variation. When you unlock a base product, its variation products are also unlocked, unless locked by another user.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Locking.**
2. On the Locking Preference page, specify in minutes how long you want a product record to be locked by default.
3. Specify in minutes how long you want a content asset to be locked by default.

   If you specify 0, content asset locking is disabled for the site.
4. Click **Apply** to make changes or click **Reset** to revert to system default of 60 minutes.

   Lock a product if you have full permission or restricted permission (permission restricted to the storefront catalog of the currently selected site). The permission is independent from the selected locale.
   
   You can't lock a product when you have no permission at all.

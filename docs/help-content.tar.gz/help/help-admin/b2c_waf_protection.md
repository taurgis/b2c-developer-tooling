# web application firewall (WAF) Protection

_Enabled by default when creating proxy zones, WAF is a layered approach to security and an important component of a multitiered approach to bad actor mitigation._

Though not intended to be a protection from all possible bad actors, WAF protects production, staging and development storefront host-names from certain code-level vulnerabilities. These vulnerabilities can include:

- SQL injection attacks
- cross-site scripting
- Open Web Application Security Project (OWASP) WAFv2 Managed Ruleset–Identified threats targeting the application layer. The CDN provider integrates the Open Web Application Security Project (OWASP) ModSecurity Core Rule Set into its platform. Regular monitoring makes sure that the WAF ruleset remains up to date with the latest version of OWASP available from the official code repository.
   
   - The OWASP WAFv2 Managed Ruleset, implemented by the CDN, mirrors the OWASP ModSecurity Core Rule Set (CRS) and undergoes routine monitoring for updates from OWASP. The update makes sure the ruleset aligns with the latest official code repository version.
   - Functioning as a unified entity, the OWASP WAFv2 Managed Ruleset calculates a threat score and determines appropriate actions based on this score. When a request matches a rule within the ruleset, the threat score incrementally rises according to the rule's score. If the final threat score surpasses the configured threshold, CDN executes the action specified in the last rule of the ruleset.
- eCDN Managed ruleset–These are threats identified by the CDN security team. This ruleset provides fast and effective protection for all of your applications. The ruleset is updated frequently to cover new vulnerabilities and reduce false positives.
- eCDN Exposed Credentials check Managed ruleset–A set of pre-configured rules for well-known Content Management System (CMS) applications that perform a lookup against a public database of stolen credentials. Implementing an automated credential check on your end-user authentication endpoints makes sure the WAF ruleset is used to look up against a public database of compromised credentials for any credential pair.

When using WAF, keep the following in mind.

- WAF can stop a bot attempting to exploit common code vulnerabilities. However, WAF can miss a bot attempting to brute force coupon codes because the request is a legitimate HTTP and web form request.
   
   Contact your account team for management solutions from one of our recommended bot-specific partners, if applicable.
- The OWASP ruleset can be either on or off. WAF OWASP ruleset doesn't support customizing individual rules within the OWASP ruleset.
- eCDN Managed ruleset can either be on or off. eCDN Managed ruleset doesn't support customizing individual rules within the eCDN Managed ruleset.
- CDN Exposed Credentials checks can either be on or off, eCDN Exposed Credentials check doesn't support customizing individual rules within the eCDN Exposed Credentials checks.

WAF monitors Internet traffic, examining all HTTP or HTTPS (full site) and Ajax (small data snippet) requests made to your storefront. It incorporates the OWASP most common web application vulnerabilities to determine an effective rule set. Rules can be based on multiple request attributes such as user-agent, path, country, query string, IP address, and more.

WAF performs several functions to help protect your storefront.

- Inspects website addresses or URLs to detect anything out of the ordinary.
- Filters out malicious traffic attempting to exploit certain application vulnerabilities.
- Helps prevent bad actor threats from exploiting code vulnerabilities.

WAF default settings provide a sensitivity mode of Low and an action of Challenge.

# Omnichannel Inventory Integration Setup and Configuration

_Plan and implement your integration of Salesforce Omnichannel Inventory with B2C Commerce._

### Planning the Integration

Before you begin, review the organization of your inventory and design a system to meet your specific business needs. Some of the decisions to consider include:

- How to handle data imports from an external system of record, such as a WMS.
- Which physical and virtual inventory locations to include in the Omnichannel Inventory location graph.
- Which locations and location groups to associate with inventory lists in B2C Commerce.
- Whether to use B2C Commerce stores to associate inventory lists with order product line items. If so, how to map stores to the location graph.

If you’re adding Omnichannel Inventory to an existing B2C Commerce implementation, these considerations also apply:

- How to map your existing sites, stores, and inventory locations to locations and location groups in Omnichannel Inventory.
- How to associate inventory lists that 's used for orders but not assigned to a site with locations or location groups in Omnichannel Inventory. (For example, lists assigned to a store.)
- Whether any existing customizations are incompatible with Omnichannel Inventory, and whether to reimplement them in Omnichannel Inventory. That includes any customization that creates or modifies individual product inventory records.
   
   > **Note:** Open Commerce API (OCAPI) calls to the `inventory_lists/{inventory_list_id}/product_inventory_records` endpoint aren’t compatible with Omnichannel Inventory.
- Whether any other existing customizations or business processes can benefit from being reimplemented in Omnichannel Inventory.
- How to transfer any existing inventory data import processes from B2C Commerce to Omnichannel Inventory.
- How to manage the cutover from the existing implementation to the integrated system. For example, Plan an order moratorium while switching to the new system for managing availability data.

### Implementing the Integration

Setup and configuration of the integrated inventory system includes these steps:

- Prepare Omnichannel Inventory
- Prepare B2C Commerce
- Set up the trust relationship between Omnichannel Inventory and B2C Commerce
- Activate the integration

For detailed instructions, see the [Salesforce Omnichannel Inventory Implementation Guide](https://resources.docs.salesforce.com/232/latest/en-us/sfdc/pdf/salesforce_omnichannel_inventory_implementation_guide.pdf).

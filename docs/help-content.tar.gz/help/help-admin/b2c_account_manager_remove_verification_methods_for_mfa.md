# Remove Verification Methods for Multi-Factor Authentication in B2C Commerce

_If you want to replace a multi-factor authentication (MFA) verification method, you can remove registered methods from your Account Manager account._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **Account Information**.
3. Under **Multi-Factor Verification**, click the trash bin icon of the method you want to remove.

   Account Manager displays a message asking you to confirm that you want to remove the method.
4. Click **Remove**.

   > **Note:** If you lose your verification method and don’t have a registered backup method, contact your account administrator to restore access to your account.

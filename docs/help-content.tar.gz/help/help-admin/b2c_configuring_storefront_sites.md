# Configuring Storefront Sites for B2C Commerce

_New sites require some level of access control. Many use a single shared password for all users. Using a Business Manager login with the functional permission provides a much higher level of security and access control, in particular with frequent password renewals and employees leaving an organization._

|  |
| --- |
| Available in: **B2C Commerce** |

For any services requiring access to the protected site, a Business Manager login is also strongly recommended. However, if the password expiration cycle is problematic, the shared password option provides a low-maintenance access control mechanism.

> **Note:** You can use the shared password for some of the users by simply setting the generic password. It doesn't deactivate the protection that is configured via Business Manager user logins.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Adminstrator****Sites****Manage Sites.**

   Use the sort buttons to sort your sites. Sites appear in this order throughout the Business Manager user interface.
2. Click a site in the Storefront Sites table to manage an individual site.
3. On the **General** tab, configure the time zone, a customer list, the brand, and billing entity.

   See [Site Time Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_site_time_zone.htm&type=5) and [Site Brand and Billing Entity](https://help.salesforce.com/s/articleView?id=cc.b2c_site_brand_and_billing_entity.htm&type=5).
   
   The ID, default currency, and taxation type are read only.
4. Click the **Settings**> tab.

   Specify the cartridges and the cartridge path used by your site.
   
   See [Registering Your Cartridge](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-cartridges.html#register-a-cartridge).
   
   The HTTP/HTTPS section has been deprecated. The preferred way to configure HTTP/HTTPS hostnames is in the site aliases configuration (SEO/Aliases Configuration). The HTTP/HTTPS hostnames values configured in this section apply if no hostnames are defined by aliases configuration, and are intended only to support the deprecated configuration style.
5. (Optional) Change the session timeout setting. The default is 30 minutes.

   1. In the Timeout field, enter a value between 15–120 minutes.
6. Click the **Cache** tab.

   See [Configure the Static Content Cache](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-content-cache.html#cache-configuration).
7. Click the **Site Status** tab.

   Access to non-production storefronts, for example, not yet live or residing on a different instance type (for example, staging/development) is typically protected by the storefront password protection.
   
   When configuring access, you can provide a single user name/password set for everyone on the team. For a greater level of security, however, you can use Business Manager passwords. The benefit is that if a member leaves the team, their credentials can be deleted instead of having to redistribute a new set of credentials across the team.
   
   1. Select the **Site Status:** Maintenance, Online (Protected), or Online.
   2. When you select Online (Protected), select one of the following:
   
      - Only users with the functional permission 'Access_Protected_Storefront': Only Business Manager users with the required functional permission *Access_Protected_Storefront* can log into the storefront. The storefront verifies that the credentials match a Business Manager user.
      - Shared Password: Enter the username and password. All team members of the client staff or third-party teams who are eligible to access the storefront share this credential set.

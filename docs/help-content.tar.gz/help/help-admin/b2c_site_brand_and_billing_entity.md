# Site Brand and Billing Entity in B2C Commerce

_Use Business Manager to set the site brand and billing entity, so you can analyze GMV reports._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Adminstrator****Sites****Manage Sites > site.**
2. Enter the Brand for the site.

   A site can only have one Brand. However, multiple sites can have the same Brand attribute value. If you use the Brand attribute, the Order Journal reflects the value, which can then be used for internal order tracking purposes.
3. Specify the Billing Entity for the site.

   The Billing Entity attribute can be used to assign a specific geographic identifier to track the specific regions which orders can be associated with. A site can only have one Billing Entity, however, multiple sites can have the same Billing Entity attribute value. If you use the Billing Entity attribute, the Order Journal reflects the value, which can then be used for internal order tracking purposes.
4. Click **Apply**.

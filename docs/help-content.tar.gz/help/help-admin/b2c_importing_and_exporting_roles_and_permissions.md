# Import and Export Roles and Permissions

_Import and export access roles and users through the Site Import & Export module in Business Manager. This topic applies to B2C Commerce._

To import and export access roles and users through the Site Import & Export module, you need several permissions. To import or export users, you need permissions to the Users module. To import or export access roles, you need permissions to the Roles & Permissions module. To import or export user-role assignments, you need permissions to both the Users module and the Roles & Permissions module.

### Role Locale Permissions Import/Export

A role in an import file without a locale permission is given permissions on all globally active locales and B2C Commerce logs a data warning. This function happens because, starting with Release 16.9, a role export file always has locale-level permissions. A file without locales was created with a previous release, when all roles had access to all locales. For backward compatibility, B2C Commerce grants existing roles without locale permissions access to all locales when you import an *old* file.

### Resource Path Concept

A resource path is a semantic, human-readable ID that denotes a certain entity in the system. The system recognizes three kinds of resource paths: a resource path that denotes a Business Manager module, a resource path that denotes the merchant's organization, and a resource path that denotes a particular site of the merchants organization. The advantage of a semantic ID is that it remains constant over different instances (that is, development, production, staging, and sandbox).

### Resource Path for Module Permissions

The syntax of the resource path is:

```
BUSINESSMGR/SystemMenu|CustomMenu/<ID of the organization>/-|<ID of the site>/<ID of the Business Manager module>
```

- SystemMenu | CustomMenu - SystemMenu denotes a Business Manager module provided by B2C Commerce. CustomMenu denotes a Business Manager module provided by merchants' custom cartridge.
   
   > **Note:** The resource path is only valid as a whole if the resource type and the type of the Business Manager module, as denoted by the subpath, match. If the resource type is "SystemMenu", but the subpath denotes a custom Business Manager module, the path can't be valid as a whole. If the resource type is "CustomMenu", the Business Manager module must be provided by a custom cartridge. Only the Business Manager menu actions provided by merchant customization can be "CustomMenu".
- <ID of the organization> is the ID of the merchant's organization: "Sites".
- -|<ID of the site> - Use a dash (-) to denote that the module is one of the Administration modules (and is organization-wide). If the module is site-specific, name the site for which the module should be enabled. The syntax is invalid if the module isn't site-specific and the name of a site is provided.
- <ID of the Business Manager module> - supply the name of the Business Manager module to grant access to, as defined in the Business Manager extension file. The path is valid if the Business Manager module named is available in the passed organization.

### Resource Path for Functional Permissions

There are only two types of resource paths usable in conjunction with functional permissions:

- Resource path to an organization: OBJECT/Organization/SItes
- Resource path to a site: OBJECT/Site/Sites/SiteGenesis

The syntax of the resource path is:

```
OBJECT/Organization|Site/<ID of the organization>/<ID of the site>
```

Depending on the type of functional permission, either a resource path to an organization or to a site can be used. Examples of valid resource paths for functional permissions are:

```
OBJECT/Organization/Sites
OBJECT/Site/Sites/SiteGenesis
OBJECT/Site/Sites/Storefront
```

Example of invalid resource paths for functional permissions are:

```
OBJECT/Site/Sites
OBJECT/Organization/Sites/Storefront
```

The following functional permissions are currently provided by the system:

| Permission | Scope | Description | Valid Resource Path |
| --- | --- | --- | --- |
| Login_On_Behalf | Site | Lets administrators log in on behalf of a customer into storefront. | OBJECT/Site/Sites/YourShopHere |
| WebDAV_Transfer_Files | Organization | Allows accessing log files or impex directories on the server via WebDAV | OBJECT/Organization/Sites |
| WebDAV_Manage_Customization | Organization | Allows access to directories of all custom cartridges via WebDAV | OBJECT/Organization/Sites |

### User Import

The user import includes:

- User credentials
- User profile data, except address data
- User role assignments

During import:

- The import skips a user if one with the same login already exists.
- The import skips the role-user assignment if the access role doesn't exist.
- The import is always executed in the organization domain.
- Users and role-user assignments are always imported into the organization domain.

# B2C Commerce API (Shopper Commerce API (SCAPI)) Hook Metrics

_SCAPI Hook metrics help website administrators and DevOps teams monitor and analyze the performance of SCAPI hooks. These metrics help identify issues with slow performance and failures of SCAPI hooks. SCAPI Hook metrics appear in the Metrics Dashboard with a delay of up to 10 minutes._

Use filters to refine the metrics to a specific API.

- `API Family`: Filter for all APIs belonging to an API family.
- `API Name`: Filter for a single API.

### Hook Execution Time

The Hook Execution Time metric measures the time in milliseconds the hook script takes to run.

Use case:

- Identify performance issues that a poorly implemented hook can cause.

### Hook Execution Errors

The Hook Execution Errors metric measures the number of errors that occurred during the execution of SCAPI hooks.

Use case:

- Identify frequently failing hooks.

Find additional SCAPI metrics in the Commerce Analytics Center (CCAC) SCAPI Dashboard. See [Troubleshooting Salesforce B2C Commerce Performance](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-troubleshooting-platform-performance.html) in the B2C Commerce Guide.

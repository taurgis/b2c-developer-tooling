# eCDN Proxy Zone FAQ

_Find answers to your eCDN proxy zone questions._

### Proxy Zone and Legacy Zone

**What is a CDN Proxy Zone?**

A proxy zone is any new zone created in eCDN. Business Manager translates the proxy zone name. Customers don’t see the proxy zone name. A proxy zone has the following characteristics:

- Ends with `cc-ecdn.net`
- Zone's DNS CNAME starts with `commcloud`
- Proxy Zone configuration is accessible in Business Manager or the CDN-API

**What is a legacy zone?**

A legacy zone, also known as a root zone, is a zone that includes the customer domain name. For example, brand.com.

**How Do I determine if a zone is a root zone or a proxy zone?**

In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Embedded CDN Settings** and find the hostname. If the DNS CNAME starts with commcloud the zone is a proxy zone.

**What problems does an eCDN Proxy Zone solve?**

- **Realm and Instance-Specific Configurations**
   
   You configure Proxy Zones at the instance level. Legacy zones were configured at a domain name level. If you have multiple realms, you can assign different hostnames to different realms. For example, you can manage the eCDN configurations for `us.mystore.com` and `eu.mystore.com` separately.
- **eCDN Managed Certificates (eCDN Automatic Certificates)**
   
   All Proxy zones support auto renewing certificates. B2C Commerce merchants have the option to configure eCDN managed SSL certificates to auto-renew. Auto-renew keeps your certificates valid and makes managing eCDN on development, staging, and production instances easier.

**On which B2C Commerce instance can I configure eCDN managed certificates?**

Configure eCDN Managed certificates for development, staging, and production instances.

**Can I configure eCDN managed certificates in eCDN Proxy Zones through Business Manager?**

Yes, Business Manager supports configuring eCDN managed certificates. See [Add Managed SSL Certificates](https://help.salesforce.com/s/articleView?id=cc.b2c_add_managed_ssl_certificates.htm)

**How do eCDN legacy and proxy zones work together?**

Both legacy and proxy zones can exist only in different realms and Cloudflare accounts. For example, if you have a legacy zone for brand.com in account A, and also created the proxy zone for the hostname in account B. The zones can’t co-exist in the same realm and cloudflare account.

To route traffic to the hostnames, both the legacy and proxy zones require an SSL certificate. In a proxy zone you’re required to specify the hostname when uploading the certificate. In a legacy zone the SSL certificate only serves the hostname that matches the SAN in the uploaded certificate.

**What happens if I have a legacy root zone and proxy zone for the same hostname?**

An SSL certificate is required for any hostname serving traffic in the proxy zone. Configure the proxy zone with a hostname, for example us.brand.com, and a valid SSL certificate.

Traffic for the hostname us.brand.com requires a valid certificate in both the root zone (brand.com) and the Salesforce Commerce Cloud (SFCC) eCDN proxy zone (ending in cc-ecdn.net) with the custom hostname us.brand.com.

- If the Root zone (brand.com) certificate, used to terminate the Transport Layer Security (TLS) for us.brand.com hostname, expires, it can’t serve the traffic.
- If the proxy zone is missing the hostname us.brand.com, it can’t serve the traffic.

Upload a valid SSL certificate or use an eCDN managed auto renewing certificate.

**Is there a limit to the number of certificates installed for root zones and proxy zones?**

Root or Legacy zones (domain.com), are limited to four custom certificate slots per realm, shared between Production, Development, and Staging.

Proxy zones support both self-manage custom and eCDN Managed auto renewing SSL certificates for any of your sites. The limit for self-managed SSL certificates is five per realm. The limit for eCDN managed auto-renewing certificates is 500 per zone at no additional cost.

Additional certificates in legacy or proxy zones have a monthly subscription cost. Salesforce will discuss new terms with you during your next contract renewal cycle.

**Can I switch from self-managed custom SSL certificates to eCDN managed certificates in Proxy Zones?**

If you have self-managed custom certificates, issued by a certificate authority, in a proxy zone, you can configure SSL certificates for automatic renewal in any zone within the realm. You can also continue to upload SSL certificates for development, staging, and production instances.

Switch to eCDN managed auto renewing certificates or self-managed custom SSL certificates anytime.

Configure self-managed SSL certificates, issued by a certificate authority, in Business Manager or with the CDN-API. Configure eCDN managed only with the CDN-API.

eCDN managed auto-renewing certificates only support single custom hostname certificates. If you have self-managed custom wildcard certificates, continue to use them or create separate custom hostnames with eCDN managed certificates for the hostnames.

**Can I use managed certificates with a third-party CDN stacked on top of eCDN?**

Yes. To use eCDN managed certificates with a third-party CDN stacked on top of eCDN, you’re required to validate the TXT record every three months. This is because automatic certs are on a three-month rotation. Without domain control validation (DCV) delegation, updates to TXT records are required every 2–3 months. If needed, contact our support team and they’ll give you a DCV delegation universally unique identifier (UUID) to include in your DNS record.

**Can I use eCDN managed certificates in eCDN Legacy or Root Zones?**

No. The eCDN managed certificates feature is only available in eCDN proxy zones. All legacy zones, for example brand.com, require a custom certificate. Use Business Manager to upload and renew a certificate before it expires.

### Rollout and Timeline Schedule

**When is eCDN Proxy Zone for Business Manager available?**>

All new zones created after [B2C Commerce 22.8 release](https://documentation.b2c.commercecloud.salesforce.com/DOC1/topic/com.demandware.dochelp/ReleaseNotes/22_8/rn_b2c_rn_22_8_release.html?resultof=%22%32%32%2e%38%22%20%22%72%65%6c%65%61%73%65%22%20%22%72%65%6c%65%61%73%22%20) by default are proxy zones.

### On-Boarding and Activation

**How do I activate the eCDN Proxy Zone feature in Business Manager?**

All merchants can create eCDN proxy zones. There are no additional steps required to activate or enable this feature.

**Are there any requirements to qualify for the eCDN proxy zone?**

There are no requirements to qualify for eCDN proxy zone.

**How do I configure an eCDN proxy zone?**

To create a Proxy Zone on the eCDN, use the self-service Embedded CDN Settings tool in Business Manager.

1. In Business Manager, select Merchant Tools _SEO_ Aliases. Add the root domain (brand.com) and the subdomain (www.brand.com) to the Alias File.
2. In Business Manager, select Administration > Sites > Embedded CDN Settings.
3. Click Add Hostname.
4. Locate the root domain you want to add as the Proxy Zone and click CreateZone.
   
   A progress message displays. B2C Commerce creates the Proxy Zone on its Cloudflare account.
   
   This step can take up to 24 hours. Check back to get the status. 24 hours is the SLA Cloudflare set to activate the TXT record associated with the zone name.
5. When the proxy zone is ready, the hostnames listed in the alias file are automatically populated under the proxy zone name.

**What are the steps to add eCDN managed certificates to my storefront custom hostnames?**

Use the CDN-API to add certificates.

1. For each hostname, upload a certificate using the POST certificate endpoint with the hostname, certificate type automatic. See [addCertificateForZone](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=addCertificateForZone).
2. Select Google or Lets Encrypt for the certificate Authority.
3. Select TXT validation or HTTP validation.

**What are the steps to switch from managed custom certificates to eCDN managed certificates?**

Use the CDN-API to perform this switch

1. For each hostname, upload a certificate using the PATCH certificate endpoint with the hostname, certificate type automatic. See [updateCertificate](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=updateCertificate).
2. Select Google or Lets Encrypt for the certificate Authority.
3. Select TXT validation or HTTP validation.

**What are the steps to add SSL certificates to the merchant’s storefront hostnames?**

Before completing these steps, use the Business manager Embedded CDN Settings to create a proxy zone. Add certificates to the hostnames secures storefront traffic.

1. Under the Configure Zone settings, select the Crypto tab.
2. Select the proxy zone you’re adding a certificate to.
3. Click Add Certificate.
4. Enter the certificate and private key information from your certificate provider.
5. Select which hostnames to which you want to assign the certificate.
6. Click Upload Certificate.
7. Copy the displayed verification TXT information into your own DNS portal (Authoritative DNS).
8. To check the status of hostname validation, click Verify HostName. Verification can take up to six hours.
9. When the hostname is active, create a CNAME record that points traffic, to the new zone.
   
   If you already have the same root domain with your DNS provider in a separate account, it’s required to point the DNS to the new zone and not the standard or root zone. The purpose is to prove intent that you want traffic to come to the new zone rather than the standard or root zone. With this approach, you’re responsible for uploading and managing your SSL certificates on Production and Development hostnames. Expired certificates are automatically removed from the B2C Commerce Platform.

**Can I update an existing certificate with a new certificate that covers existing and new hostnames?**

For an existing hostname with a certificate, use the update certificate option to update the certificate.

To change the hostname and add a hostname on a certificate.

1. Add the new hostname to aliases then select Add Certificate.
2. Add the certificate and private key.
3. Select the hostnames (old and new) you want to update on the certificate.

**If the hostname is removed from the merchant’s realm, does Salesforce remove a hostname from the SSL certificate?**

No. if you removed a hostname from the alias file, Salesforce doesn't remove the hostname from a certificate.

**Assuming I have a Cloudflare DNS, What DNS configuration changes do I make?**

This is relevant only if you already have a root zone in cloudflare and are trying to route the traffic to the new proxy zone in Salesforce B2C Commerce. After creating the Proxy Zone, point the storefront hostname to the eCDN. Use these steps to map the DNS CNAME values in the Embedded CDN Settings to your Cloudflare account.

1. Search for the proxy zone name and select it from the list.
2. Under the DNS tab, locate the hostname that you want to map.
3. Replace all text after ‘is an alias of’ with the DNS CNAME value provided from the Embedded CDN Settings.
4. Click in the Status column until the tooltip DNS Only shows.

The storefront hostname is no live on the eCDN.

**When do I update DNS changes on my Cloudflare Account to point to the eCDN?**

Update your DNS settings on your Cloudflare account when you’re ready to go-live on your B2C Commerce production environment. To run tests before changing your production storefront hostname, update your DNS on your custom dev hostname.

Don’t update the CNAME record until an SSL certificate has been installed in the Embedded CDN Settings tool.

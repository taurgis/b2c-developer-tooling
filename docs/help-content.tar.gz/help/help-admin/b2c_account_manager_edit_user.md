# Edit a User Account in B2C Commerce

_Account Administrators can edit the details, access permissions, and status of users accounts in their organization._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** To improve security, if a user is logged in and you edit their account, their User session is automatically invalidated. To continue their session, the user must log in again.

1. Log into Account Manager.
2. Click **Users**.

   The Users page opens, showing a list of email addresses for all users in your organization (or organizations).
3. In the **Organizations Users** section, click the email address of the account you want to edit.

   The user profile opens.
4. In the Multi-Factor Verification section you can remove multi-factor authentication (MFA) verification methods on behalf of the user. For example, if a user loses or replaces a method, remove it so they can add a new method.

   1. Click the trash bin icon of the verification method you want to remove.
   
      Account Manager displays a message asking you to confirm that you want to remove the method.
   2. Click **Remove**.
5. In the **Organizations** section, click **Add**.

   1. Search for organizations, and check each organization to which the account belongs (each account must belong to one or more organizations).
   2. To apply the organizations to the user, click **Add**.
   
   A message is sent to the email address, notifying the user about their membership in a new organization.
6. In the **Primary Organization** list, modify the user's primary organization.
7. In the **Roles** section, click **Add** to open the **Assign Roles** window.

   If the user needs to access a sandbox of PIG instance, select either **Business Manager User** or **Business Manager Administrator** under the eCommerce Platform section.
   
   1. Search for roles, and check each role that you want the user to have.
   2. To assign the roles to the user, click **Add**.
   
      Some roles, for example **Business Manager User** or **Business Manager Administrator**, need access to specific sandbox or PIG instances and a role scope is required.
8. If the role needs access to an instance, add a role scope. Users can check their assigned roles, including instance filters, on the Account Information page in Account Manager.

   1. Select the filter icon.
   2. In the **Add Instance Filters** tab, select an organization.
   3. Enter the names for the instances you want the user to have access to.
   4. Select the instances.
   5. Click **Add**.

Additional Resources

- [Enable Business Manager User Permissions for B2C Commerce](https://www.youtube.com/watch?v=yIRMhv_EevI&list=PLFNbZmUNjID7UuW9nGFwbNgAVF3yNlu3v&index=6&pp=iAQB)

# Payment Card Credential Storage for B2C Commerce

_When a shopper authorizes use of saved credentials, the card credential storage indicates how stored credit card credentials can be used. This feature applies to B2C Commerce._

You set the instance status in Business Manager. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Ordering > Salesforce Payments** and click **Settings**. There are two settings.

- **Save for future off-session use**–When active, during checkout, the shopper’s credit card credentials are saved by Salesforce Payments and can be reauthorized for off-session use. For example, use the off-session setting and the script API, to authorize recurring subscription payments or reauthorize payment when order fulfillment is delayed.
- **Save for future on-session use**–When active, Salesforce Payments saves and uses the shopper’s credit card for only the current checkout session.

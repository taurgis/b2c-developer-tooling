# Remove a PayPal Merchant Account from B2C Commerce

_Remove the association between a PayPal merchant account and your B2C Commerce instance. If a PayPal merchant account is linked to a default payment zone, first reassign the default payment zone to another merchant account. When you remove the merchant account, B2C Commerce unassigns all payment zones from the account._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
2. Locate the PayPal merchant account that you want to remove.
3. From the actions menu, click **Remove**.

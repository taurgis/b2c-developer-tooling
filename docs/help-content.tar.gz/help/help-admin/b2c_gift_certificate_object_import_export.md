# Gift Certificate Object Import and Export in B2C Commerce

_Use the giftcertificate.xsd schema file to import gift certificates. This topic applies to B2C Commerce._

| Object Information | Details |
| --- | --- |
| Schema file | giftcertificate.xsd |
| Business Manager import location | ***site* > Merchant Tools > Online Marketing > Import & Export** |
| Granularity | Selected gift certificates. |
| Pipelets | ImportGiftCertificates ExportGiftCertificates  *Granularity:* Passed gift certificates. |

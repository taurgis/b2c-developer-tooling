# JavaScript and Objects in HTML Attributes for B2C Commerce

_For security reasons, only Business Manager users with strong authentication, such as through multi-factor authentication with Account Manager, can include JavaScript and objects embedded with `iframe`, `object`, `applet`, or `embed` tags in the HTML attributes of a database object. This topic applies to B2C Commerce._

A Business Manager user with strong authentication can temporarily allow users without strong authentication to include JavaScript and embed objects in HTML attributes. Click App Launcher _(image: App Launcher)_, and then go to **Administration > Global Preferences > JavaScript in Attributes**, and click **Enable**. For 1 hour, users without strong authentication can include JavaScript and embed objects in HTML attributes.

To authenticate users using multi-factor authentication with Account Manager, enable Unified Authentication with Account Manager in Business Manager at **Administration > Global Preferences > Security**. Also, in Account Manager, assign the user’s account to a role that requires multi-factor authentication.

> **Important:** Separate from the issue of JavaScript and embedded objects in HTML attributes, Salesforce strongly recommends that you implement multi-factor authentication for all Business Manager users.

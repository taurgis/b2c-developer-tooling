# B2C Commerce Videos

_If one picture is worth a thousand words, then a set of moving pictures is surely worth thousands more. We've assembled an assortment of instructional videos to help you learn more about B2C Commerce Business Manager. We continue to add new titles, so check back often._

| Watch | Learn To |
| --- | --- |
| [_(image: Rebuild Search Indexes title screen)_](https://salesforce.vidyard.com/watch/WeAGCMnGAWyTkEqgXJpdWh) [Rebuild Search Indexes](https://salesforce.vidyard.com/watch/WeAGCMnGAWyTkEqgXJpdWh) | Build an index manually Set up scheduled automatic indexes Configure incremental indexing |
| [_(image: Assign Products to Categories title screen)_](https://salesforce.vidyard.com/watch/1ZEcPZ5TPA7JRaUJzWDgdU) [Assign Products to Categories](https://salesforce.vidyard.com/watch/1ZEcPZ5TPA7JRaUJzWDgdU) | Assign multiple products to a category Set up a categorization rule |
| [_(image: Localize Content in Page Designer title screen)_](https://salesforce.vidyard.com/watch/rUNxBuzePGa1cN2n6T385B) [Localize Content in Page Designer](https://salesforce.vidyard.com/watch/rUNxBuzePGa1cN2n6T385B) | Localize components on a Page Designer page Configure localization fallback hierarcy |
| [_(image: Add a Discount to a Promotion title screen)_](https://salesforce.vidyard.com/watch/FBuHxig6rn3rubJB8wYNQb) [Add a Discount to a Promotion](https://salesforce.vidyard.com/watch/FBuHxig6rn3rubJB8wYNQb) | Create a promotion Add a discount to a promotion |
| [_(image: Add a Product to the B2C Commerce Catalog title screen)_](https://salesforce.vidyard.com/watch/wVTfpobCCwmXV1JnJvFe8J) [Add a Product to the B2C Comerce Catalog](https://salesforce.vidyard.com/watch/wVTfpobCCwmXV1JnJvFe8J) | Add a product Assign images to the product Add a price for the product Add an inventory record for the product |

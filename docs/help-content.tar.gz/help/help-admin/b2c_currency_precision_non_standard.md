# Currency Precision in B2C Commerce

_Salesforce B2C Commerce follows an international standard for supported currencies. The following currencies have a different level of precision than the standard._

For more information, see [Changing Currency Precision in B2C Commerce](https://help.salesforce.com/s/articleView?id=005299298&type=1) .

| Currency | Countries | Code | ISO 4217 Precision | B2C Commerce Precision |
| --- | --- | --- | --- | --- |
| Burundi Franc | Burundi | BIF | 0 | 2 |
| CFP Franc | French Polynesia, New Caledonia, Wallis and Futuna | XPF | 0 | 2 |
| CFA Franc BCEAO | Benin, Burkina Faso, Cote D'Ivore, Guinea-Bissau, Mali, The Niger, Senegal, Togo | XOF | 0 | 2 |
| CFA Franc BEAC | Cameroon, The Central African Republic, Chad, The Congo, Equatorial Guinea, Gabon | XAF | 0 | 2 |
| Dong | Vietnam | VND | 0 | 1 |
| Forint | Hungary | XOF | 2 | 0 |
| Guarani | Paraguay | PYG | 0 | 2 |
| Iceland Krona | Iceland | ISK | 0 | 2 |
| Malagasy Ariary | Madagascar | MGA | 2 | 1 |
| New Taiwan Dollar | Taiwan | TWD | 2 | 0 |
| Rwanda Franc | Rwanda | RWF | 0 | 2 |
| Uganda Shilling | Uganda | UGX | 0 | 2 |
| Won | The Republic of Korea | KRW | 0 | 2 |

# User Management with Identity Federation In Account Manager and B2C Commerce

_You can configure the Identity Federation settings of your organization so that Account Manager user accounts are automatically created, provisioned, and linked to the Salesforce Identity of your Salesforce Organization (Salesforce Identity Management (SFIDM))._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

When Just-In-Time User Provisioning is enabled, new users, accounts are automatically provisioned and linked to their Salesforce accounts managed in SFIDM. For existing users not linked to SFIDM their accounts are automatically linked to their Salesforce accounts managed in SFIDM. Both options require that you set Identity Federation to the enforced or allowed setting.

Optionally, you can continue to manually provision user accounts in Account Manager before they’re linked to the existing Identity and Access Management (IAM) account.

## Related Content

- [Identity Federation with Salesforce Identity in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_identity_federation.htm&type=5)
  Identity federation enables users to access multiple applications or systems with a single set of credentials. Account Manager uses identity federation to enhance security and the app login experience.

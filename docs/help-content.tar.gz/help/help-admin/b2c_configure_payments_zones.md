# Configure Payment Zones for B2C Commerce

_Create payment zones to assign payment methods to specific currencies and countries for B2C Commerce. After you create a payment zone, assign it to a merchant account. Then, select the payment methods for the zone._

## Related Content

- [Create a Payment Zone for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_payments_zone.htm&type=5)
  Create a payment zone and assign one or more currencies and countries to it.

- [Assign Payment Zones to a Merchant Account for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_assign_payments_zones_to_a_merchant_account.htm&type=5)
  Assign one or more payment zones to your merchant accounts. The default payment zone, set to all currencies and countries, is assigned to the first merchant account you create. Assign more payment zones to your merchant accounts to further customize which payment methods can be used for which zones.

- [Add Payment Methods to a Payment Zone for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_add_payment_methods_to_a_payments_zone.htm&type=5)
  To configure how shoppers complete purchases, customize payment methods for each payment zone based on country or currency.

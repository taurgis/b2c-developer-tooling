# Register Verification Methods for Multi-Factor Authentication in B2C Commerce

_Multi-factor authentication (MFA) is an extra layer of protection beyond a single password._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

With MFA, you enter multiple pieces of evidence – or factors – to prove your identity. The first factor is your username and password combination (something you know). Additional factors are verification methods that you have in your possession, such as an authenticator app or security key. MFA is required for all Account Manager users and can’t be turned off. The first time you log in, you’re prompted to register a verification method for MFA. The registration process connects the method you choose to your Account Manager account. You must supply a registered verification method each time you log in. Register additional methods at any time from your account information in Account Manager.

> **Note:** We highly recommend registering two or more methods so you have a backup if you forget or lose your primary method. Register different types of methods (such as Salesforce Authenticator and a security key) or two instances of the same method type (such as two security keys or two different third-party time-based one-time password (TOTP) authenticator apps).

## Related Content

- [Connect Salesforce Authenticator (Version 3 or Later) to Your Account for Identity Verification in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_connect_salesforce_authenticator_for_identity_verification.htm&type=5)
  The Salesforce Authenticator mobile app is a fast and easy verification method for multi-factor authentication (MFA) logins. Register the app to connect it to your Account Manager account. To receive and approve push notifications sent to your mobile device, Salesforce Authenticator requires that you secure your mobile device with a security pin or face ID.

- [Verify Your Identity with a TOTP Authenticator App in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_verify_identity_with_totp_auth_app.htm&type=5)
  Register a third-party authenticator app, like Microsoft Authenticator or Google Authenticator, as a verification method for multi-factor authentication (MFA) logins. The app generates a verification code called a time-based one-time password (TOTP).

- [Register a Security Key for WebAuthn Identity Verification in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_register_a_security_key_for_webauthn_identity_verification.htm&type=5)
  Register a Fast Identity Online (FIDO) U2F or WebAuthn (FIDO2) compatible security key as a verification method for multi-factor authentication (MFA) logins. To verify your identity, insert your security key into the appropriate port on your computer or mobile device to complete verification. You can register the same security key with multiple service providers and multiple Salesforce orgs and accounts. You can also register one key per account.

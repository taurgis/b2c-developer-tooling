# Importing Data into and Exporting Data from a B2C Commerce Instance Database

_When you have transferred files to your instance, you are ready to import data into the B2C Commerce database on the instance._

Use the import/export feature to import most types of data used by your site. For site settings, use the Site Import/Export or data replication. For code deployment, use data replication or upload code directly from your local machine via UX Studio.

## Related Content

- [Manually Run Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_manually_running_import_export.htm&type=5)
  Manually run import and export processes. This topic applies to B2C Commerce.

- [Automate Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_automating_import_export.htm&type=5)
  Before you start automation, decide on your file naming convention for import files. We recommend that you use a regular expression to name your import files and include a date signifier. This approach makes it easier to identify if the correct files were transferred to the instance and to archive files. Also decide how you want to archive your files and the naming convention for archived files. This topic applies to B2C Commerce.

- [Creating Import/Export Pipelines in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_import_export_pipelines.htm&type=5)
  In addition to importing a file, you can also use your import/export pipeline to update search indexes, archive files, and copy bad import files to a specific directory. This topic applies to B2C Commerce.

- [XML File Generation from Within B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_xml_file_generation_from_within_demandware.htm&type=5)
  Standard exports use the B2C Commerce-defined XML schema files. B2C Commerce provides a set of schema files that can be used to create the most common export files.

- [Managing Attributes via a Backend System in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_attributes_via_a_backend_system.htm&type=5)
  If you use a backend catalog management system to define attribute data or new product attributes, use catalog import to import new product attribute definitions into B2C Commerce. Also make sure that attributes managed via the backend system can't be edited in Business Manager.

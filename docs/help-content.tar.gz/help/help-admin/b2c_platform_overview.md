# B2C Commerce Concepts and Terminology

_B2C Commerce provides the resources and processing for your ecommerce sites. You create and build your sites in your realm._

A customer realm includes a primary instance group and a secondary instance group.

_(image: Diagram of a B2C Commerce realm with primary and secondary instance groups)_

### Realm

Typically, you have a single realm. The realm contains instances on which to develop, test, and deploy your online storefront. A B2C Commerce instance is an application infrastructure. It includes web servers, application servers, and database servers. You usually have six B2C Commerce instances: three or more sandbox instances for code development, and three instances for site staging, testing, and deployment. A Merchant can control their storefront online merchandising, configuration, and customization options. The instance administrator for the merchant has direct control over password management, user permissions, and stopping or starting instances within their realm.

- Development instance: used for site configuration, data enrichment, and data import.
- Staging instance: used to test your site before deployment.
- Production instance: hosts the live site that customers use.

Single and Multiple-Realm Configurations

In most cases, you have a single realm for developing, staging, and deploying multiple sites with different branding or locales. The people managing the storefront site can be in different locations. Sites can share product catalogs or have different catalogs.

If you have different lines of business or global teams that each have their own processes or business policies, consider maintaining multiple realms. You can also have separate realms if you have distinct organizations with separate back-end integrations, schedules, or other concerns that make it advantageous to let each team manage their sites independently. Sites in the same realm can share the product catalog for product data. Sites in different realms can't share data through the catalog structure. To share data, import it into different realms.

Example: Let's say that you have sites with separate brands in Europe and the Pacific Rim. You can have a realm for the team managing the Pacific Rim sites and another realm for Europe.

_(image: Diagram of single and multiple-realm configurations in B2C Commerce)_

### Primary Instance Group

The primary instance group has three instances, which merchants use to add data, test code, and run live sites. A realm can have only one PIG per realm.

### Secondary Instance Group

The secondary instance group (SIG) contains your sandbox instances. The minimum number of sandboxes in a SIG is 3, and the maximum is 47.

### Cloud

The cloud is the underlying resources used to run your instances and live sites that Salesforce manages. You never interact directly with the cloud, but it’s the foundation that supports your site.

# Automate Import/Export in B2C Commerce

_Before you start automation, decide on your file naming convention for import files. We recommend that you use a regular expression to name your import files and include a date signifier. This approach makes it easier to identify if the correct files were transferred to the instance and to archive files. Also decide how you want to archive your files and the naming convention for archived files. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

When the storefront is live, exporting data is as important as importing, because you want to synchronize between the merchant's database and the B2C Commerce system.

To export a file, you have two options:

- Use an approach that is similar to importing, where you export business objects in the B2C Commerce standard format using pipelets, then translate the data into your format.
- Get the set of business objects through a pipelet and write to your format directly.

1. Create an automatic import feed.

   1. Configure your backend system to produce XML files required by the feed schema.
   2. Create a cartridge for your import export code.
   3. Create a pipeline for the import job.
   4. Create a job and associate it with the pipeline. Schedule and manage jobs through the Business Manager in the **Administration > Operations > Job Schedules** module.
   5. Create a user with the privileges to execute the job.
   6. Use data replication if necessary to transfer the information from the staging instance to the production instance.
2. Create an automatic export feed.

   1. Create a custom pipeline. The pipeline can use the export pipelets to export files with the B2C Commerce schema file definitions or scripts to create custom export files.
   2. Create a job to run the pipeline.
   
      Every date export uses Greenwich Mean Time (GMT)-00 as the time zone.
   3. Create a job on your backend system that automatically produces the import file. Schedule and manage jobs through the Business Manager in the **Administration > Operations > Job** module.
   4. Create your export file.
   5. Run the job.

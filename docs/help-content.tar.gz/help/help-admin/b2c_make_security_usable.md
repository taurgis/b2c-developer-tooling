# Make Security Usable

_A difficult-to-use security feature is one that's turned off. Write security features in a way that makes them easy for users to understand. To help users understand the security decisions they make, give them visibility into and control of their security settings._

Here are some examples.

- Don’t enable a security feature that breaks part of the app. Doing so increases the risk that users don’t enable it.
- End-to-end encryption transparently encrypts all messages as they're sent over the internet. No middle-boxes can read or tamper with these messages. This feature is always on and doesn't interfere with other features, for example, adding new members to a group chat or searching previous messages.

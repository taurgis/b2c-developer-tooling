# Import/Export Site-Specific Attributes in B2C Commerce

_Site-specific product attributes require specific import/export handing, specifically for metadata.xsd and catalog.xsd. This topic applies to B2C Commerce._

If you mark an attribute as *localizable* and *site-specific,* a data error is logged and the attribute is skipped. If you mark an attribute as *site-specific,* but site-specific attributes aren’t allowed for the object type, a data warning is logged, and the attribute is imported with site-specific-flag = *false.*

Define any non-localizable custom product attribute as site-specific.

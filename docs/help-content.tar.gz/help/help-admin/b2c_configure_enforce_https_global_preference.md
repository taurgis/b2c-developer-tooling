# Configure the Enforce HTTPS Global Preference

_Enforce the use of HTTPS for all sites in an instance. When this setting is enabled, URLs generate using the HTTPS protocol, and incoming page requests that use HTTP redirect to HTTPS. HTTP requests to Open Commerce API (OCAPI)'s session bridge aren't accepted. Also, instead of a combination of session cookies and secure tokens, secure session cookies are used, which helps avoid incorrect (false positive) session hijacking detections. Enable the Enforce HTTPS global preference to let browsers send cookies in cross-site contexts. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security**.
2. On the Access Restriction tab, select **Enforce HTTPS**.
3. Click **Apply**.

When you enable the Enforce HTTPS setting globally, you can't configure it at the site level. If you disable the Enforce HTTPS global preference, B2C Commerce uses the previous site-specific settings.

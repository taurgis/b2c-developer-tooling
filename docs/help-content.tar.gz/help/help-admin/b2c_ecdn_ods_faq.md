# eCDN on On-Demand Sandboxes – FAQ

_Find answers to common questions about eCDN on On-Demand Sandbox (ODS) instances, including what's auto-provisioned, the shared zone model, vanity domain migration, and feature parity with production environments._

### Provisioning and setup

**What is automatically provisioned when a new ODS instance is created?**

Starting with the 26.6 release, every new ODS instance automatically receives an eCDN-fronted Default Domain hostname. You don't need to make DNS changes or manage certificates manually. Two shared Cloudflare zones are provisioned per realm — one for storefront traffic and one for Business Manager traffic. Each ODS instance gets a custom hostname registered in both shared zones.

**What are the hostname formats for ODS?**

- **Storefront:** `<instance>.sbx.my.commercecloud.salesforce.com` (for example, `bldp-001.my.commercecloud.salesforce.com`). With the 26.6 default-domain auto-routing, the storefront host for ODS sandboxes changes from `<realm>-<NNN>.dx.commercecloud.salesforce.com` to `<realm>-<NNN>.my.commercecloud.salesforce.com`, including for already-provisioned sandboxes.
- **Business Manager:** `<instance>.dx.commercecloud.salesforce.com`, proxied through the shared BM zone (`ccbm.<realm>-sbx.cc-bm.net`). Business Manager, WebDAV/code upload, jobs, and the Sandbox API remain on the `.dx` hostname.

**Do existing ODS instances get eCDN automatically?**

Yes. With the 26.6 eCDN rollout completed across all ODS clusters, existing ODS sandboxes receive the Default Domain automatically — no re-provision required. Existing vanity domains on ODS aren't migrated and remain on the legacy path.

**What customer actions are required for the 26.6 storefront hostname change?**

With the 26.6 rollout, the storefront default host changes from .dx to .my (including for already-provisioned sandboxes). Update any external integrations pinned to the old .dx storefront host: CORS allowed-origins lists, third-party service whitelists (payment gateways, analytics, security tools), end-to-end test base URLs and automation scripts, and hard-coded storefront references in external applications. The .my certificate is Salesforce-managed and publicly trusted, so no customer TLS reconfiguration is required. Business Manager, WebDAV/code upload, jobs, and the Sandbox API are not affected—they remain on the .dx hostname.

**Where do I see the Default Zone in Business Manager?**

After provisioning, the Default Zone appears in Business Manager under **Administration > Sites > Embedded CDN Settings** as the Default Zone row (for example, `zzpq.sbx.my.commercecloud.salesforce.com`). Use the **Configure Zones** button to manage web application firewall (WAF) rules, MRT routing rules, cache settings, host header overrides, and PCI policies.

### Shared zone model

**What is the shared zone model?**

All ODS instances in a realm share a single storefront zone and a single Business Manager zone. This means WAF rules, MRT routing rules, cache settings, host header overrides, and PCI policies configured on the zone apply to all ODS instances in that realm. Per-instance configuration isolation is out of scope.

**How does the shared zone model affect WAF rules?**

WAF rules are scoped to the zone level, not the instance level. A rule you add or change affects all ODS instances in the realm. Plan rule changes carefully to avoid unintended impact across instances.

**Is there a default Block All firewall rule on ODS zones?**

No. Unlike some PIG production zones, ODS zones don't have a default Block All firewall rule. ODS zones are open by default. Add explicit rules as needed to restrict access.

### Feature parity with production environments

**Are all eCDN features available on ODS?**

Yes, all standard eCDN capabilities are available on ODS Default Domain zones, including edge caching, WAF (OWASP ruleset, eCDN Managed ruleset, custom rules), bot protection, DDoS mitigation, rate limiting, real-time analytics, Log Center metrics (HTTP status codes 502–530), PCI 4.0/Page Shield, IP/ASN/geo blocking, MRT routing rules, image optimization (DIS), and log export (LogPush).

The following features are not yet available or out of scope for ODS:

- **Vanity Domain (custom hostname):** Targeted for the 26.7 ODS release.
- **Per-instance eCDN configuration isolation:** Out of scope. All ODS instances in a realm share the same eCDN configuration.
- **Video optimization:** Not supported. Use an external CMS or partner solution.

### Vanity domain migration

**I have vanity hostnames on ODS CNAMEd to dx.commercecloud.salesforce.com. What do I need to do?**

Take action before the 26.4 rollout. The applicable path depends on your current setup:

- **Scenario 1 — Vanity hostnames with ingress Transport Layer Security (TLS) termination:** An interim manual path is available for 26.5 pilot customers only and requires eCDN team involvement. Contact Salesforce Support.
- **Scenario 2 — Vanity hostname CNAMEd to dx.commercecloud.salesforce.com with no ODS cert:** The migration path is not yet defined and requires a spike assessment. Coordinate with your Salesforce account team before the rollout date.

For step-by-step guidance, see [Create a Zone in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_zone.htm).

**When will full self-service vanity hostname support be available for ODS?**

Salesforce plans full self-service vanity hostname support for ODS in the 26.7 release.

### Certificates

**Who manages certificates for ODS eCDN?**

Salesforce manages all certificates for ODS Default Domain zones. Wildcard certificates for `*.sbx.my.commercecloud.salesforce.com` (storefront) and `*.dx.commercecloud.salesforce.com` (Business Manager) are provisioned and renewed automatically. No annual certificate renewal is required.

# Reset a User Account in B2C Commerce

_Account administrators can use Account Manager to reset a user's account. This operation is useful if the user forgets their password or if you want to unlink an Account Manager account from a Salesforce account. When you reset a user's account, you put the account in the same state it was in when it was initially created. The user must reactivate the account._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** If a user is logged in and you reset their account, their User session is automatically invalidated. To continue their session, the user must log in again.

1. Log into Account Manager.
2. Click **User**.

   The Users page opens, showing a list of accounts.
3. Click **Reset** next to the user whose account you want to reset.

   A dialog box opens, asking you to confirm that you want to reset the user's account. If you click **Cancel**, the reset operation is canceled, and the user's account isn't modified.
4. Click **OK**.

   Account Manager resets the user's account. If the account is linked to a Salesforce account, Account Manager cancels the link. Account Manager sends a message to the user’s email address. This email message contains an activation URL, which serves as a starting point for the user to activate the account. Account Manager also shows, in the **Users** page, a text message next to the user's account. This text message indicates that the user's account was successfully reset; it also includes the activation URL sent to the user's email address.
   
   if a user is re-activated, they are required to register a verification method for multi-factor authentication (MFA) with Account Manager once, to complete the linking.

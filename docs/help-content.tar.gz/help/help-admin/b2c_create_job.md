# Create a Job in B2C Commerce

_When you create a job, you configure at least one flow, and select which steps to execute in each flow. Use out-of-the-box system job steps that don't require any coding. If there isn't a system job step available to do what you want, have a developer create a custom job step. You can also schedule when the job executes, specify resources to lock during job execution, and configure email notifications and error handling._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select**Administration > Operations > Jobs**.
2. Click **New Job**.
3. Enter an ID and description.
4. Click **Create**.
5. (Optional) Schedule the job to run on a specific date or on a recurring basis.

   Scheduled jobs are not supported on sandboxes instances.
   
   1. Click **Schedule and History**.
   2. Click **Enabled**.
   3. Under Active, select **Once** or **recurring interval**, and specify a date or range of dates and times.
   
      > **Note:** The Business Manager job scheduler supports precision only to the minute. While seconds are visible and editable in the interface, modifying them has no effect on the actual schedule.
   4. For recurring jobs, under Run Time, enter the number of times to run the job and at what interval.
   5. If necessary, select one or more days under **Run only on these days**.
   
   A job doesn't start if a previous execution of the same job is still running, so it's important to understand how long a job takes to execute before scheduling it. It's also important to schedule jobs so that multiple jobs don't try to acquire a lock on the same object at the same time. Typically, you can run as many as 15 jobs simultaneously.
6. (Optional) To prevent modifying a resource while the job is operating on it, click **Resources**, click **Select**, and select the resource type and value.
7. Add at least one flow:

   1. Click **Job Steps**.
   2. To add sets of sibling flows, click _(image: Icon for adding a new sibling flow.)_
   3. For each set of sibling flows, specify either parallel or sequential processing. _(image: Icon for selecting parallel or sequential processing for a set of sibling flows.)_
   4. To add another sequential flow, click _(image: Plus symbol icon for adding a new sequential flow.)_ at the bottom of a flow.
   5. Select a scope for the flow.
   
      - **Organization**: Flow executes for the instance.
      - **All Storefront Sites**: Flow executes on all storefront sites available at the time the job executes. Flow doesn’t execute on the Business Manager site or on sites with a to-be-deleted status.
      - **Specific Sites**: Flow executes only on the storefront sites you select.
      - **Site Parameter:** Flow executes on the sites you pass to it using the Open Commerce API (OCAPI) Data API. You can't execute the job from Business Manager, and you can't schedule the job to run automatically. The Run Now button and scheduling options in Business Manager are disabled. If you select this option, a SiteScope parameter with an empty value is added to the job. Using the OCAPI Data API, specify one or more specific sites or all storefront sites for SiteScope.
8. Add steps to the flows:

   Some job steps, such as CreateSitemap, can execute only in the context of a site. Other job steps, such as ExecuteDataReplication, can execute only in the context of the organization. If you try to assign a job step to a flow that has a scope the step doesn't support, the step shows an error.
   
   1. On the Job Steps tab, select the flow where you want to add a step.
   2. Click **Configure a step**, and select a step.
   3. Configure the step parameters.
   
      Required parameters are marked with a red asterisk. For some parameters, hover your mouse over the parameter to get information about what to enter.
   4. Select whether this job step always executes when a job is restarted, even if the step was already completed.
   5. To configure the rules for what happens when a job step exits, in **Exit Status Rules**, click **Add Rule**.
   
      Job step exit status codes indicate whether a job step has executed succesfully. Typically, exit code ERROR indicates that the job step has failed. Exit code OK indicates success. By default, the exit code ERROR maps to the Stop Job action. All other exit codes map to the Continue to Next Step action by default.
   6. For each exit status code and * in the **On** field, select an **Action**.
   
      * is a wildcard that indicates any exit status code without a rule.
      
      - **Stop Job**: No more job steps are executed. The entire job execution has failed. If the step is part of a parallel flow and other steps are still executing in parallel to the failed step, the job execution fails when the parallel steps finish executing.
      - **Stop Flow**: Subsequent job steps in the same flow are skipped and execution continues with the next flow.
      - **Continue with Next Step**: If there are more steps in the same flow, execution continues with the next step in the flow. If there aren't any more steps in the same flow, execution continues with the next step of the next flow.
      - **Continue with *<step>* **: Jump to the named job step in the same flow.
   7. Click **Assign**.
9. To configure error handling for the job:

   1. Select **Failure Handling**.
   2. Select a failure rule. The failure rule is invoked after a job finishes with an ERROR status.
   
      - **Continue As Scheduled**: Job executes at next scheduled time.
      - **Stop On Error**: Job schedule disabled to prevent future executions.
      - **Retry**: Job restarted on error. For this option, configure the number of retries to be attempted and the interval between retries.
10. To send email notifications about the job status:

   1. Click **Notification**.
   2. Select at least one event that trigger a notification.
   3. Select **Enabled**.
   4. Enter email addresses for the email sender and recipients.
   5. (Optional) Select **Long Runtime Detection** snd specify the run time.

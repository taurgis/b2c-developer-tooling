# Limit Storefront Order Access

_Unauthorized access to storefront orders happens when someone accesses an order through a storefront session using a different customer ID than the one used to create it. This makes it possible for unauthorized users to view the order’s details._

To enhance the security of your storefront and prevent unauthorized access to orders, Salesforce recommends that you enable two specific preferences:

- Limit Storefront Order Access = Yes
- Allowlist = Storefront controllers and hooks allowed access to storefront orders

Business Manager alerts identify storefront controllers and hooks that can access storefront orders but aren't on the allowlist. Users with access to the Order Preferences module see the alerts and can review whether any of the controllers and hooks are required. You can copy and paste controllers and hooks that need access from the alert into the allowlist.

If you enable the preferences, Salesforce automatically blocks all sources not included on the allowlist for storefront order access. Salesforce recommends that you remove any other sources of storefront order access from the server to avoid unauthorized execution. To keep access to orders secure, maintain a concise allowlist of storefront controllers and implement ‌security checks in the custom code. For example, verification for a guest order lookup ‌can include this information to validate the access request:

- Order number
- Email address
- Shipping information

See Also:

- [Limit Storefront Order Allowlist FAQ](https://help.salesforce.com/s/articleView?id=cc.b2c_allowlist_faq.htm)

## Related Content

- [Set the Order Allowlist](https://help.salesforce.com/s/articleView?id=cc.b2c_set_order_allowlist.htm&type=5)
  To improve the security and manageability of order access within your storefront, Salesforce recommends enabling the AllowList feature within the Limit Storefront Order Access setting. This feature is useful if you haven’t yet implemented any restrictions on Storefront Order Access. After activating this feature, specify which controllers are permitted to access order information and execute order-related functions.

- [Limit Storefront Order Allowlist FAQ](https://help.salesforce.com/s/articleView?id=cc.b2c_allowlist_faq.htm&type=5)
  Unauthorized access to storefront orders happens when an order is accessed through a storefront session using a different customer ID than the one it was created with. This makes it possible for unauthorized users to view the order’s details.

# Tax Table Object Import/Export in B2C Commerce

_Use the tax.xsd schema file to import tax rates. This topic applies to B2C Commerce._

For links to import and export schema files, see B2C Commerce Import and Export Schemas.

For links to import and export schema files, see [B2C Commerce Import and Export Schemas](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/xsd/).

*Granularity:* all tax classes, tax jurisdictions, and tax rates.

### Business Manager Import Location

**Ordering > Import & Export**

### Pipelets

ImportTaxTable

ExportTaxTable

*Granularity:* all tax classes, tax jurisdictions, and tax rates.

# Create cross-site request forgery (CSRF) Allowlists for B2C Commerce

_Configure how your site handles CSRF allowlists._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security** and select the CSFR Settings tab.

   Configure two types of CSRF allowlists: allowlists for pairs of pipelines and start nodes, and allowlists for user agents.
2. To allowlist a pipeline and start node, enter the names of the pipeline and start node in the Add Pipeline/Start Node to Allowlist fields, and click **Add Pipeline/Startnode**.

   Repeat this step to allow additional pipeline/startnode pairs.
3. To allowlist a user agent, select an instance type from the Instance Type dropdown, enter the name of the user agent in the Add UserAgent to Allowlist field, and click **Add UserAgent**.

   Repeat this step to allowlist additional user agents.
4. Click **Apply**.

# Modify eCDN OWASP WAFv2 Settings

_When responding to a potential web application threat, eCDN web application firewall (WAF) looks at each incoming request, assigns the request a threat score, and responds appropriately. Each incoming request that triggers an OWASP rule increases the overall threat score. Some rules impact the score more than others._

WAF uses these action modes in response to a threat detected by OWASP. The default for the OWASP WAFv2 Managed Ruleset is set as enabled.

- Set paranoia level (PL)–The managed ruleset assigns a specific Pl (PL1 default, PL2, PL3, or PL4) to each rule. Higher paranoia levels offer enhanced protection but can result in WAF blocking more legitimate traffic due to false positives. All rules associated with paranoia levels up to the configured paranoia level are enabled.
- Define score Anomaly score threshold - Define the score threshold. The available thresholds are:
   
   - Low (60 and higher)
   - Medium (40 and higher – default)
   - High (25 and higher)
   - Setting a Low threshold implies having a higher threshold value, typically 60 or above. For the managed ruleset to initiate the configured action with this setting, a higher number of rules aligns with the current request. The cumulative scores of the matching rules determine the request's threat score.
- Select the action to perform–WAF executes the action when the calculated threat score exceeds the score threshold. The available actions are:
   
   - Block
   - Default
   - Managed challenge
   - JA challenge
   - Log
   - Legacy captcha

_(image: WAFv2 Managed Ruleset Settings)_

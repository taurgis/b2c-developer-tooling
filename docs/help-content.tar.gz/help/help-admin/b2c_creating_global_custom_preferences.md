# Create Global Custom Preferences for B2C Commerce

_In Salesforce B2C Commerce, you can create global custom preferences, and then view and edit them. Custom preferences enable organization developers to make properties of the system modules configurable in Business Manager._

|  |
| --- |
| Available in: **B2C Commerce** |

They can:

- Define a preference type
- Define a preference group
- Group preference types into preference groups
- Set the value of a preference for an organization
- Read the value of a preference from a custom application (for example, a pipeline or B2C Commerce script)

One way to achieve higher flexibility when implementing customized functionality for a system is to make certain features and properties configurable. These features allow for easy adaptation of the system functionality to changing requirements later.

Create custom preferences to make your settings configurable. Global custom preferences are defined in the context of the `OrganizationPreference` system object.

Because these objects are defined as custom preference types, you can add attributes and values.

> **Note:** You need write permission to configure global custom preferences. If you have `read-only` permission, you can view the settings, but you can't change them. This change also applies to changes via B2C Commerce API calls.

You can also get and set custom preferences programmatically.

> **Note:** The list of preferences and groups appear in the order in which you configured them in the system object definition.

1. To create an attribute grouping and corresponding set of attribute definitions, click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > System Object Types.**

   1. Select **OrganizationPreferences**.
   2. Click the **Attribute Definition** tab.
   3. Click **New** and define custom (global or site) attributes:
   
      Enter or select these values:
      
      - ID: `processingDays`
      - Display Name: `Sample custom preference`
      - Help Text: `This is the number of days to process an order`
      - Value Type: `Enum of Strings`
   4. Click **Apply**.
   5. Now select the following:
   
      - Mandatory: the field is selected or contains text.
      - Externally Managed: The field is populated externally.
      - Select Multiple: (Applies only for Enum of Strings.) The user can select multiple choices,which appear as a list of elements. Standard keyboard elements, such as **Ctrl** on Windows or **Command** on a Mac, are required to select more than one element.
         
         > **Note:** customizable options vary based on the value types selected previously.
   6. Click **Apply**.
   7. Enter these Value | Display Value definitions and click **Apply** after each entry, as follows:
   
      - `5 | orderProcessing (make this the default)`
      - `6 | shipDays`
      - `11 | totalDays`
2. To assign attributes to an attribute group:

   1. Click **<<Back** and click the **Attribute Grouping** tab.
   2. Enter the following:
   
      ID: `processTime`
      
      Name: `totalProcessTime`
   3. Select the language and click **Add**.
   4. At the processTime row, click **Edit**.
   5. Click **...**, select the **processingDays** attribute, and click **Select**.
3. To setset global custom preferences in Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Custom Preferences**.

   1. On the Global Custom Preferences Groups page, select an ID or name or click the **Edit** button at the right of a preference group row.
   2. On the Global Custom Preferences page, select the Instance Type.
   3. Select the preference value.
   4. Click **Apply**.

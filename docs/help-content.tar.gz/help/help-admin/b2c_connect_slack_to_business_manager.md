# Connect a Slack Workspace to Business Manager

_Send alerts and notifications directly to Slack channels, when you connect your workspaces to Business Manager._

|  |
| --- |
| Available in: **B2C Commerce** |

[b2c_slack_bot_token.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_slack_bot_token.htm&type=5).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select**Administration > Operations > Notification Settings**.
2. On the Slack tab, click **Connect to Slack Workspace**.
3. To start connecting your workspace, click **Next**.
4. Enter your workspace’s name and your Slack Bot token. Then click **Connect Workspace**.
5. Select Slack channels to receive notifications and click **Add**.
6. To add more channels from this workspace, click **Add Channels**.
7. To add another workspace, click **Connect Another Slack Workspace**.

## Related Content

- [Get a Slack Token for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_slack_bot_token.htm&type=5)
  To connect Slack to Business Manager, a Slack administrator acquires a Slack bot token, also known as a Bot User OAuth Token, for your workspace. A Slack admin completes these steps before connecting the workspace to Business Manager.

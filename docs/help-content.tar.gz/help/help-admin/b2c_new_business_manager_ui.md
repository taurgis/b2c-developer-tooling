# B2C Commerce Business Manager

_Use Business Manager to manage all aspects of your digital commerce operations. Business Manager provides merchandisers, admins, and business users a unified interface to manage products, customers, orders, and promotions._

Starting with Salesforce B2C Commerce Version 26.5, the default user interface is Salesforce Cosmos Design. The Cosmos UI includes interactive circular motifs, improved fonts and icons, inviting cues, and higher contrast colors. Cosmos also incorporates the App Switcher and provides customizable navigation and contextual insights. If you’re using an earlier version of the Business Manager UI, you can update your UI to Cosmos or keep your existing version.

### B2C Commerce Business Manager UI FAQs

- Are existing Business Manager cartridges compatible with the Cosmos UI?
   
   Yes. All Business Manager cartridges are compatible with the Cosmos UI.
- Can I switch to an earlier UI style?
   
   Yes. To switch to an earlier UI style, in Business Manager, select My **Profile Settings  > | Preferences > | Preferred UI Style**.
- Is the Modern Cosmos UI built on CRM Core App and Lightning Web Runtime (LWR)?
   
   No. B2C Commerce uses a unified design language to update the Business Manager UI. While there are common design elements and UI components with Salesforce CRM Core App and LWR, the modern Cosmos UI isn’t built on CRM Core App and LWR.
- Does the new homepage dashboard replace B2C Commerce Reports & Dashboards?
   
   No. The new Merchant Tools and Administration dashboards primarily focus on Business Manager related information (product catalog status, search index status, errors, and quota violations). Reports & Dashboards continue to capture and display business and technical metrics.
- How do I report problems?
   
   Contact Salesforce Customer Support to report functional issues with the Business Manager UI.
- Can I request enhancements or features?
   
   Yes. Request feature enhancements through the [IdeaExchange](https://ideas.salesforce.com/s/).

# Shopper Registered Event

_The system fires a shopper registered event when a new customer profile is successfully created and committed. This event contains core customer information needed by external systems. Unlike replication events, which operate at the organization level, the shopper registered event is site-specific, so you can register and route it independently per site._

**Available in:** B2C Commerce release 26.7 and later.

### Event ID

### HTTP headers

The shopper registered event uses the standard Commerce Cloud platform headers documented in [Common HTTP Headers for B2C Commerce Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_common_headers.htm&type=5), with `x-sf-cc-event-id` set to `sf.cc.shopper.registered`.

### JSON payload structure

### Example: full shopper registered event

```
{
"customerId": "abc123-uuid-def456",
"registrationDate": "2026-06-15T10:30:00Z",
"loginId": "john.doe@example.com",
"customerNo": "00000001",
"email": "john.doe@example.com",
"firstName": "John",
"lastName": "Doe",
"phoneMobile": "+1-555-0100",
"sites": ["RefArch", "SiteGenesis"]
}
```

### Example: minimal shopper registered event

```
{
"customerId": "minimal-uuid-123",
"registrationDate": "2026-06-15T10:30:00Z",
"loginId": "john.doe@example.com",
"customerNo": "00000001",
"sites": ["RefArch", "SiteGenesis"]
}
```

### Shopper registered implementation notes

- The event is fired asynchronously after successful customer creation and transaction commit.
- Optional fields are only included if they have non-blank values.
- Site IDs are normalized by removing the `Sites-` prefix and `-Site` suffix (for example, `Sites-RefArch-Site` becomes `RefArch`).
- The event is site-specific, so you can register different connectors for different sites.
- The event is controlled by a feature toggle that's enabled by default.
- If event serialization or firing fails, the customer creation process still succeeds.

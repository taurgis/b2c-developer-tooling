# Storefront Toolkit

_The tools in the Storefront Toolkit help developers and merchants get information about storefront content and performance. To access the Storefront Toolkit tools, select the site to view and then click **Toolkit** at the top of the navigation bar in Business Manager. The storefront opens with the Storefront Toolkit icons visible in the upper right corner of the page. This topic applies to B2C Commerce._

> **Important:** The deprecated Storefront Toolkit is no longer supported and can pose security risks. we now disable the deprecated Storefront Toolkit by default for new sites and imported sites. For existing sites, the behavior remains unchanged, but we recommend transitioning to the new Storefront Toolkit for enhanced functionality and support. To keep your site secure and up-to-date with the latest features and improvements, disable it. To disable the deprecated Storefront Toolkit in Business Manager, click App Launcher _(image: App Launcher)_, and then select **Apps selector > Site > Site Preferences > Deprecated Storefront Toolkit**. Set Enable Deprecated Storefront Toolkit to **No**.

## Related Content

- [Storefront Toolkit Tools](https://help.salesforce.com/s/articleView?id=cc.b2c_storefront_toolkit_tools.htm&type=5)
  The Storefront Toolkit provides six tools. This topic applies to B2C Commerce.

- [Storefront Toolkit Tips and Limitations](https://help.salesforce.com/s/articleView?id=cc.b2c_storefront_toolkit_tips.htm&type=5)
  For best results, configure your system for optimal Storefront Toolkit performance and make sure you’re aware of toolkit limitations. This topic applies to B2C Commerce

- [Identify Templates, Controllers, and Pipelines with the Page Information Tool](https://help.salesforce.com/s/articleView?id=cc.b2c_using_the_page_information_tool.htm&type=5)
  To identify the templates, controllers, and pipelines that create page components, use the Page Information Tool. This topic applies to B2C Commerce.

- [Identify Content to Edit with the Content Information Tool](https://help.salesforce.com/s/articleView?id=cc.b2c_using_the_content_information_tool.htm&type=5)
  To determine the source of content assets in the storefront and get a link to edit the content in Business Manager, use the Content Information Tool. The Content Information Tool doesn’t support Page Designer pages.

- [Examine Search Results Using the Search Information Tool in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_search_tool.htm&type=5)
  The Search Information Tool provides information about how customer queries are processed, including information about hypernyms, compound words, synonyms, negative search terms, and stemming. The tool shows the sorting rule used to determine search results, the sorting criteria within the rule, and the sorting criteria values for each search result. The tool also shows if refinements are used to navigate to the search results and the text relevance for the search result. This topic applies to B2C Commerce.

- [Get Cache Status Using the Cache Information Tool in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_using_the_cache_information_tool.htm&type=5)
  To get information about cached and uncached components on a page, use the Cache Information Tool. Cache is disabled for Storefront Toolkit users, but the Cache Information tool shows you caching information about components as if you’re viewing the storefront without the toolkit. Use this information to determine the cost of caching portions of a page. The Cache Information Tool shows caching information for pipeline calls or controllers for the page itself and remote includes. The Cache Information Tool doesn't show static content caching, so caching information for third parties doesn't appear. Local includes aren't cacheable, so information about local includes doesn't appear.

- [Examine Server Calls Using the Request Log in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_using_the_request_log.htm&type=5)
  The Request Log shows log entries related to the most recent server call and any server calls made while the tool is open. You can also view log entries for AJAX calls or other script calls. The Request Log tool shows exception information from the server and the custom logging in real time. If you use this tool to debug a script, use custom logging in your script as long as you configure the custom log settings in Business Manager.

- [Preview a Site Using the Site Preview Tool in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_using_the_site_preview_tool.htm&type=5)
  Use the Site Preview Tool to view the storefront as it appears for a certain date or time. Choose to view the storefront as it appears for certain customer groups, or with certain source code. To preview an A/B test on a storefront, enter the A/B test and A/B test segment values.

- [Test Promotions Using the Promotions Tracing Tool in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_sftk_test_promotions.htm&type=5)
  Use the promotions tracing tool to test promotions before publishing them to the storefront. You can see which promotions are applicable for a particular cart. If a promotion isn’t applied to a cart, see the reasons why.

- [Troubleshoot the Storefront Toolkit in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshooting_storefront_toolkit.htm&type=5)
  Troubleshoot some common issues with the Storefront Toolkit. This topic applies to B2C Commerce.

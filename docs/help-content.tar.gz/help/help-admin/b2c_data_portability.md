# Data Portability: Give Shoppers Their Data When They Want It in B2C Commerce

_When your customers request it, prepare and pack up the data you’ve received from them to work toward complying with various data protection and privacy regulations. We give you examples of common customer requests and things to consider. That way, you can determine how best to work toward complying with the regulations that apply to your company. This topic applies to B2C Commerce._

Export shopper-related data when shoppers request it, so that you can work toward complying with various data protection and privacy regulations. Data subjects have the right to ask for their personal data and can request to obtain their data in a structured, commonly used, and machine-readable format so that they can transmit their own personal data to another company. We give you examples of common shopper requests and things to consider when you evaluate your compliance with the regulations that apply to you. For instance, a shopper wants to know what information a merchant has about them, they can request a copy of their personal information.

> **Note:** As new data protection and privacy solutions are launched, B2C Commerce will provide specific documentation to help merchants understand how these new features can be used to help with compliance. This will cover existing tools and also extend to new release items. This page will be updated as more data portability functionality is made available. Check back for updates in future 2018 releases!

Many data protection and privacy regulations can require that when your shoppers request it, prepare and pack up the data you’ve received from them to work toward complying with various data protection and privacy regulations. We’ve listed a few of the regulations that are important to many companies collecting and processing their shoppers’ data.

- General Data Protection Regulation (GDPR)
- Personal Information Protection Act (PIPA), Japan
- Privacy Act, Australia
- Personal Information Protection and Electronic Documents Act (PIPEDA), Canada

If you have shoppers who want to take the data that you’ve received from them, review these common requests. We’ve provided links to the procedures related to those requests.

| Product | Common Shopper Request | Actions to Consider | Things to Consider |
| --- | --- | --- | --- |
| Salesforce B2C Commerce | I want to download all of my data from your site. | [Read about a sample data download implementation in SGJC (SiteGenesis JavaScript Controllers).](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/LegacyDeveloperDocumentation.pdf) | Determine what data the shopper is entitled to collect, how you want to format the data, and how you want to provide this capability to the shopper. |
| B2C Commerce | I want a copy of my personal data that you are storing, but you don't provide a self-service option. | [Export a snapshot of the shopper's data](https://help.salesforce.com/s/articleView?id=cc.b2c_customer_snapshots.htm&type=5). | Snapshots are in a technical format (JSON, XML) and can include several different types of data. Consider what you will share and how you will provide it. Determine what data the shopper is entitled to collect. |

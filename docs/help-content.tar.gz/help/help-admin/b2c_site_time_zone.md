# Site Time Zone for B2C Commerce

_Use Business Manager to set the time zone for interactions with users, per site._

|  |
| --- |
| Available in: **B2C Commerce** |

For example, this setting affects any functionality defined with time periods, such as promotions.

The *site* time zone for new sites created in a Salesforce B2C Commerce instance is `UTC.` Site timezone is a mandatory setting when creating a site. The site timezone is automatically set to *UTC* when creating a site via Site Import and Export with no time zone specified.

> **Note:** Existing sites are not affected.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select**Adminstrator****Site****Manage Sites > site.**
2. Select the `Site Time Zone` you want.
3. Click **Apply**.

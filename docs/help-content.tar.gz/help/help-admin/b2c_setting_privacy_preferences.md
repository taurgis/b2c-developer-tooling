# Set Privacy Preferences for B2C Commerce

_Setting Privacy Preferences  When shoppers visit a Salesforce B2C Commerce storefront, connected systems can collect and process their behavior and personal data to enhance the shopper experience. However, some shoppers can decide that they don’t want the merchant to collect their personal information._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Attention:** For guidance on setting DNT for headless implementations, see [Manage Shopper Tracking Preferences](https://developer.salesforce.com/docs/commerce/commerce-api/guide/slas-tracking-preferences.html).

In Business Manager, configure the default setting for your tracking-related privacy preferences. When a new session is created, the default value is used, unless explicitly changed for a shopper.

> **Note:** The default privacy setting is disabled, with a tracking preference value of true, indicating to not collect data. However, for merchants (or sites) that existed before the 18.3 release, the tracking preference is enabled. If you’re using resources that require tracking, enabling this preference provides backward compatibility.

Because custom code can read and set this preference, change the value for each shopper. For example, consent can be stored permanently within the shopper’s profile. In this case, update the preference for each session according to the user’s profile settings when the shopper logs in and out.

The default value, or the customer-specific value, is passed through the system controlling any of the storefront’s tracking-related actions.

Sometimes you can implement your own solution to update tracking consent. How you implement your solution depends on whether you ask the shopper for tracking consent, and how this decision is stored. Modify tracking consent in Open Commerce API (OCAPI) by setting HTTP Headers (see the OCAPI HTTP Headers topic). Or, use the `Session` Script API. To determine the value of the tracking preference, call the `dw.system.Session.isTrackingAllowed()` method. To set the value of the preference, call the `dw.system.Session.setTrackingAllowed()` method.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Privacy.**
2. Select the customer-tracking default action for new storefront sessions.

   - Disabled―Tracking is disabled by default and can be enabled per session via custom code.
   - Enabled―Tracking is enabled by default and can be disabled per session via custom code.
3. Select a Clickstream honors session DNT setting.

   A shopper's session holds a clickstream object which contains the last 50 top-level requests (for example, pipeline calls) of the shopper. This feature is used in SiteGenesis to figure out the last products that the shopper has visited to present some history for convenience. There’s a script API to get the clickstream entries from the current session.
   
   > **Note:** This setting is only related to the clickstream API `dw.web.Clickstream`, and doesn’t control any other Commerce Cloud clickstream functionality.
   
   - Yes – Clickstream honors the storefront do-not-track (DNT) session status.
      
      If session DNT=true, no clickstream events are collected.
      
      If session DNT=false, clickstream events are collected.
   - No – Clickstream events are collected regardless of the sessions DNT status.
4. Click **Apply**.

# Creating Data Files for Import in B2C Commerce

_When the data structure and scope is understood and documented, map how to translate existing data into the B2C Commerce format. Also, map how to export the data from the B2C Commerce environment back into the customer's environment._

Complete these tasks:

- Set up the B2C Commerce site
- Create an import file specification
- Define a file transfer, create, and import process

### Import File Specification

- Use the B2C Commerce schema as a starting point for building your file specification.
- To see a sample export file, export the file from the Reference Application.

### Transfer and Import Process

Identify the number of feeds required. For each data feed, determine:

- How files are transferred from the backend system
   
   - The file transfer mechanism
   - The frequency (consider impact to page caching performance)
- Where data is imported to
   
   You typically import data to staging, but if you import small datasets frequently, you can import them to both staging and production.
- Which import model works with your backend systems and satisfy your merchant's requirements (for example, full, incremental, update, or replace)?

Consider how this process impacts and relates to other processes, such as staging and indexing. The goal is to build a repeatable process that you can use to transform a merchant data file into the B2C Commerce XML file format. Run the process via a schedule or on-demand via the Business Manager.
